from collections.abc import MutableMapping
import pandas as pd
import datetime
from variables import FLAGS, MARKETS, PRE_ODDS_MAP, IN_PLAY_ODDS_MAP, STATUS, FLAGS
from collections import defaultdict


def flatten(d, parent_key='', sep='_'):
    items = []
    for k, v in d.items():
        new_key = parent_key + sep + k if parent_key else k
        if isinstance(v, MutableMapping):
            items.extend(flatten(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


class FixtureFormatter:

    def __init__(self, is_live=False):
        self.is_live = is_live
        pass

    def __fixture_info(self, fixture):
        fixture_info = dict()

        fixture_info['id'] = fixture['id']
        fixture_info['league_id'] = fixture['league_id']

        fixture_info['season_id'] = fixture['season_id']
        fixture_info['stage_id'] = fixture['stage_id']
        fixture_info['round_id'] = fixture['round_id']
        fixture_info['group_id'] = fixture['group_id']
        fixture_info['aggregate_id'] = fixture['aggregate_id']
        fixture_info['venue_id'] = fixture['venue_id']
        fixture_info['referee_id'] = fixture['referee_id']
        fixture_info['home_id'] = fixture['localteam_id']
        fixture_info['away_id'] = fixture['visitorteam_id']
        fixture_info['winner_id'] = fixture['winner_team_id']
        if "localTeam" in fixture and "visitorTeam" in fixture:
            fixture_info['home_name'] = fixture['localTeam']['data']['name']
            fixture_info['home_logo'] = fixture['localTeam']['data']['logo_path']
            fixture_info['away_name'] = fixture['visitorTeam']['data']['name']
            fixture_info['away_logo'] = fixture['visitorTeam']['data']['logo_path']
            fixture_info['fixture_name'] = '%s v %s' % (
                fixture_info['home_name'], fixture_info['away_name'])
        if "league" in fixture:
            league = fixture['league']['data']
            fixture_info['league_name'] = league["name"]
            country = league["country"]["data"]
            fixture_info['country_id'] = league["country_id"]
            fixture_info['country_name'] = country['name']
            fixture_info['iso'] = country['extra']["iso2"].lower(
            ) if country.get("extra") else None
            fixture_info['flag_emoji'] = FLAGS.get(fixture_info['iso'], None)
        fixture_info['home_position'] = fixture['standings']['localteam_position']
        fixture_info['away_position'] = fixture['standings']['visitorteam_position']

        fixture_info['home_formation'] = fixture['formations']['localteam_formation']
        fixture_info['away_formation'] = fixture['formations']['visitorteam_formation']
        fixture_info['weather'] = fixture['weather_report']
        fixture_info['status'] = fixture['time']['status']
        fixture_info['status_words'] = STATUS.get(
            fixture['time']['status'], fixture['time']['status'])
        fixture_info['minute'] = fixture['time']['minute']
        fixture_info['extra_minute'] = fixture['time']['extra_minute']
        fixture_info['second'] = fixture['time']['second']
        fixture_info['added_time'] = fixture['time']['added_time']
        fixture_info['injury_time'] = fixture['time']['injury_time']
        if fixture['time']['status'] == "HT":
            fixture_info["is_ht"] = True
        elif fixture['time']['status'] in ["FT", "FT_PEN"]:
            fixture_info["is_ft"] = True

        fixture_info["is_live"] = fixture['time']['status'] in [
            "LIVE", "HT", "PEN_LIVE", "BREAK", "ET"]

        starting_at = fixture['time']['starting_at']
        date_time_format = '%Y-%m-%d %H:%M:%S'
        date_format = '%Y-%m-%d'
        fixture_info['date_time'] = datetime.datetime.strptime(
            starting_at["date_time"], date_time_format)
        fixture_info['date'] = datetime.datetime.strptime(
            starting_at["date"], date_format)
        fixture_info['time'] = starting_at['time']
        fixture_info['timestamp'] = starting_at['timestamp']

        return fixture_info

    @staticmethod
    def __format_goals(fixture, important):
        home_id = fixture["localteam_id"]
        away_id = fixture["visitorteam_id"]
        if "goals" not in fixture:
            return None
        goals = fixture["goals"]["data"]
        if goals:
            df = pd.DataFrame(goals)
        else:
            df = pd.DataFrame(columns=['minute', 'team_id'])
        df["team_id"] = df["team_id"].astype(int)
        df_home = df[df['team_id'] == home_id]
        df_away = df[df['team_id'] == away_id]
        df_1h = df[df['minute'] <= 45]
        df_2h = df[df['minute'] > 45]
        df_home_1h = df_1h.merge(df_home)
        df_home_2h = df_2h.merge(df_home)
        df_away_1h = df_1h.merge(df_away)
        df_away_2h = df_2h.merge(df_away)
        goal_timings_all = df['minute'].tolist()
        goal_timings_home = df_home['minute'].tolist()
        goal_timings_away = df_away['minute'].tolist()
        goal_timings_mean = round(df['minute'].mean(), 2)
        home_goals = important.get("home_goals") or len(df_home)
        away_goals = important.get("away_goals") or len(df_away)

        home_goals_1h = len(df_home_1h)
        away_goals_1h = len(df_away_1h)
        home_goals_2h = len(df_home_2h)
        away_goals_2h = len(df_away_2h)

        ft_score = fixture["scores"]["ft_score"]
        ht_score = fixture["scores"]["ht_score"]
        if ft_score:
            try:
                home_goals, away_goals = map(int, ft_score.split("-"))
            except:
                pass
        if ht_score:
            try:
                home_goals_1h, away_goals_1h = map(int, ht_score.split("-"))
                home_goals_2h, away_goals_2h = (
                    home_goals - home_goals_1h),  (away_goals - away_goals_1h),
            except Exception as e:
                print(e)
                pass

        no_home_goals = home_goals == 0
        no_away_goals = away_goals == 0

        goals = home_goals + away_goals
        goals_1h = None if not ht_score else home_goals_1h + away_goals_1h
        goals_2h = None if not ht_score else home_goals_2h + away_goals_2h

        most_goals_1h = None if not ht_score else goals_1h > goals_2h
        most_goals_2h = None if not ht_score else goals_2h > goals_1h
        no_goals = goals == 0
        no_goals_1h = None if not ht_score else goals_1h == 0
        no_goals_2h = None if not ht_score else goals_2h == 0

        btts = (home_goals and away_goals) > 0
        btts_1h = None if not ht_score else (
            home_goals_1h and away_goals_1h) > 0
        btts_2h = None if not ht_score else (
            home_goals_2h and away_goals_2h) > 0
        btts_no = not btts
        btts_1h_btts_2h = None if not ht_score else btts_1h and btts_2h
        overs = dict()

        for i in range(0, 6):
            overs[f"o{i}5_goals"] = goals > i

        for i in range(0, 6):
            overs[f"u{i}5_goals"] = goals <= i
        if ht_score:
            for i in range(2):
                overs[f"o{i}5_1h_goals"] = goals_1h > i
                overs[f"o{i}5_2h_goals"] = goals_2h > i
        if ht_score:
            for i in range(2):
                overs[f"u{i}5_1h_goals"] = goals_1h > i
                overs[f"u{i}5_2h_goals"] = goals_2h <= i

        for i in range(3):
            overs[f"o{i}5_home_goals"] = home_goals > i
            overs[f"o{i}5_away_goals"] = away_goals > i

        for i in range(3):
            overs[f"u{i}5_home_goals"] = home_goals <= i
            overs[f"u{i}5_away_goals"] = away_goals <= i
        if ht_score:
            for i in range(2):
                overs[f"o{i}5_1h_home_goals"] = home_goals_1h > i
                overs[f"o{i}5_2h_home_goals"] = home_goals_2h > i
                overs[f"o{i}5_1h_away_goals"] = away_goals_1h > i
                overs[f"o{i}5_2h_away_goals"] = away_goals_2h > i

        if ht_score:
            for i in range(2):
                overs[f"u{i}5_1h_home_goals"] = home_goals_1h <= i
                overs[f"u{i}5_2h_home_goals"] = home_goals_2h <= i
                overs[f"u{i}5_1h_away_goals"] = away_goals_1h <= i
                overs[f"u{i}5_2h_away_goals"] = away_goals_2h <= i

        btts_or_o25 = btts or overs["o25_goals"]
        btts_o25 = btts and overs["o25_goals"]
        home_goal_difference = home_goals - away_goals
        away_goal_difference = away_goals - home_goals
        home_fts = not home_goals
        away_fts = not away_goals
        home_clean_sheets = not away_goals
        away_clean_sheets = not home_goals
        home_scored_first = len(df_home) and df.iloc[0]["team_id"] == home_id
        away_scored_first = len(df_away) and df.iloc[0]["team_id"] == away_id
        home_win = home_goals > away_goals
        away_win = away_goals > home_goals
        draw = home_goals == away_goals
        home_win_o25 = home_win and overs["o25_goals"]
        draw_o25 = draw and overs["o25_goals"]
        away_win_o25 = away_win and overs["o25_goals"]

        home_win_btts = home_win and btts
        draw_btts = draw and btts
        away_win_btts = away_win and btts

        home_win_or_draw = home_win or draw
        home_win_or_away_win = home_win or away_win
        away_win_or_draw = away_win or draw

        home_points = 3 if home_win else (1 if draw else 0)
        away_points = 3 if away_win else (1 if draw else 0)
        draw_ht = None if not ht_score else home_goals_1h == away_goals_1h
        home_win_ht = None if not ht_score else home_goals_1h > away_goals_1h
        away_win_ht = None if not ht_score else home_goals_1h < away_goals_1h

        home_win_ht_home_win = None if not ht_score else home_win_ht and home_win
        home_win_ht_draw = None if not ht_score else home_win_ht and draw
        home_win_ht_away_win = None if not ht_score else home_win_ht and away_win

        draw_ht_home_win = None if not ht_score else draw_ht and home_win
        draw_ht_draw = None if not ht_score else draw_ht and draw
        draw_ht_away_win = None if not ht_score else draw_ht and away_win

        away_win_ht_home_win = None if not ht_score else away_win_ht and home_win
        away_win_ht_draw = None if not ht_score else away_win_ht and draw
        away_win_ht_away_win = None if not ht_score else away_win_ht and away_win

        ht_score = fixture['scores']['ht_score']
        ft_score = fixture['scores']['ft_score']
        et_score = fixture['scores']['et_score']
        ps_score = fixture['scores']['ps_score']
        home_goals = fixture['scores']['localteam_score']
        away_goals = fixture['scores']['visitorteam_score']
        goals_between_85_90 = not df[(
            df["minute"] >= 85) & (df["minute"] <= 90)].empty
        goals_between_75_90 = not df[(
            df["minute"] >= 75) & (df["minute"] <= 90)].empty
        goals_between_35_45 = not df[(
            df["minute"] >= 35) & (df["minute"] <= 45)].empty
        goals_between_80_90 = not df[(
            df["minute"] >= 80) & (df["minute"] <= 90)].empty
        goals_between_40_45 = not df[(
            df["minute"] >= 40) & (df["minute"] <= 45)].empty
        goals_between_0_15 = not df[(df["minute"] >= 0) & (
            df["minute"] <= 15)].empty
        goals_between_0_10 = not df[(df["minute"] >= 0) & (
            df["minute"] <= 10)].empty
        goals_between_0_15_home = not df_home[(
            df_home["minute"] >= 0) & (df_home["minute"] <= 15)].empty
        goals_between_0_15_away = not df_away[(
            df_away["minute"] >= 0) & (df_away["minute"] <= 15)].empty
        goals_after_70 = not df[(df["minute"] > 70)].empty
        home_goals_after_70 = not df_home[(df_home["minute"] > 70)].empty
        away_goals_after_70 = not df_away[(df_away["minute"] > 70)].empty
        first_total_goal = goal_timings_all[0] if goal_timings_all else None
        first_home_goal = goal_timings_home[0] if goal_timings_home else None
        first_away_goal = goal_timings_away[0] if goal_timings_away else None

        return {
            'goal_timings_all': goal_timings_all,
            'goal_timings_home': goal_timings_home,
            'goal_timings_away': goal_timings_away,
            'home_goals': home_goals,
            'away_goals': away_goals,
            'total_goals': goals,
            'goals_1h': goals_1h,
            'goals_2h': goals_2h,
            'no_goals': no_goals,
            'no_goals_1h': no_goals_1h,
            'no_goals_2h': no_goals_2h,
            'home_goals_1h': home_goals_1h,
            'away_goals_1h': away_goals_1h,
            'home_goals_2h': home_goals_2h,
            'away_goals_2h': away_goals_2h,
            'no_home_goals': no_home_goals,
            'no_away_goals': no_away_goals,
            'btts': btts,
            'btts_1h': btts_1h,
            'btts_2h': btts_2h,
            'btts_or_o25': btts_or_o25,
            'btts_o25': btts_o25,
            'home_goal_difference': home_goal_difference,
            'away_goal_difference': away_goal_difference,
            'home_fts': home_fts,
            'away_fts': away_fts,
            'home_clean_sheets': home_clean_sheets,
            'away_clean_sheets': away_clean_sheets,
            'home_scored_first': home_scored_first,
            'away_scored_first': away_scored_first,
            'home_win': home_win,
            'away_win': away_win,
            'draw': draw,
            'home_points': home_points,
            'away_points': away_points,
            'draw_ht': draw_ht,
            'home_win_ht': home_win_ht,
            'away_win_ht': away_win_ht,
            'ht_score': ht_score,
            'ft_score': ft_score,
            'et_score': et_score,
            'ps_score': ps_score,
            'home_goals': home_goals,
            'away_goals': away_goals,
            'goals_between_85_90': goals_between_85_90,
            'goals_between_75_90': goals_between_75_90,
            'goals_between_35_45': goals_between_35_45,
            'goals_between_80_90': goals_between_80_90,
            'goals_between_40_45': goals_between_40_45,
            'goals_between_0_15': goals_between_0_15,
            'goals_between_0_10': goals_between_0_10,
            'goals_between_0_15_home': goals_between_0_15_home,
            'goals_between_0_15_away': goals_between_0_15_away,
            'goals_after_70': goals_after_70,
            'home_goals_after_70': home_goals_after_70,
            'away_goals_after_70': away_goals_after_70,
            'first_total_goal': first_total_goal,
            'first_home_goal': first_home_goal,
            'first_away_goal': first_away_goal,
            'goal_timings_mean': goal_timings_mean,
            'most_goals_1h': most_goals_1h,
            'most_goals_2h': most_goals_2h,
            'btts_no': btts_no,
            'btts_1h_btts_2h': btts_1h_btts_2h,
            'home_win_o25': home_win_o25,
            'draw_o25': draw_o25,
            'away_win_o25': away_win_o25,
            'home_win_btts': home_win_btts,
            'draw_btts': draw_btts,
            'away_win_btts': away_win_btts,
            'home_win_or_draw': home_win_or_draw,
            'home_win_or_away_win': home_win_or_away_win,
            'away_win_or_draw': away_win_or_draw,
            'home_win_ht_home_win': home_win_ht_home_win,
            'home_win_ht_draw': home_win_ht_draw,
            'home_win_ht_away_win': home_win_ht_away_win,
            'draw_ht_home_win': draw_ht_home_win,
            'draw_ht_draw': draw_ht_draw,
            'draw_ht_away_win': draw_ht_away_win,
            'away_win_ht_home_win': away_win_ht_home_win,
            'away_win_ht_draw': away_win_ht_draw,
            'away_win_ht_away_win': away_win_ht_away_win,
            **overs
        }

    @staticmethod
    def __format_probability(fixture):
        probability = dict()
        hmap = {
            "home_win_probability": "home",
            "draw_probability": "draw",
            "away_win_probability": "away",
            "btts_probability": "btts",
            "o25_goals_probability": "over_2_5",
            "u25_goals_probability": "under_2_5",
            "o35_goals_probability": "over_3_5",
            "u35_goals_probability": "under_3_5",
            "o05_home_goals_probability": "HT_over_0_5",
            "uo5_home_goals_probability": "HT_under_0_5",
            "o05_away_goals_probability": "AT_over_0_5",
            "uo5_away_goals_probability": "AT_under_0_5",
            "o15_home_goals_probability": "HT_over_1_5",
            "u15_home_goals_probability": "HT_under_1_5",
            "o15_away_goals_probability": "AT_over_1_5",
            "u15_away_goals_probability": "AT_under_1_5",
        }
        try:
            predictions = fixture['probability']['data']['predictions']
            probability = {
                key: predictions[value] for key, value in hmap.items()
            }
            return probability
        except:
            return None

    @staticmethod
    def __format_corners(fixture, important):
        home_id = fixture["localteam_id"]
        away_id = fixture["visitorteam_id"]
        corners = fixture["corners"]["data"]
        if corners:
            df = pd.DataFrame(corners)
        else:
            df = pd.DataFrame(columns=['minute', 'team_id', 'comment'])
        df = df[~df["comment"].str.startswith("Race to")]
        df = df[df['team_id'].notnull()]
        df["team_id"] = df["team_id"].astype(int)
        df_home = df[df['team_id'] == home_id]
        df_away = df[df['team_id'] == away_id]

        df_1h = df[df['minute'] <= 45]
        df_2h = df[df['minute'] > 45]
        df_home_1h = df_1h.merge(df_home)
        df_home_2h = df_2h.merge(df_home)
        df_away_1h = df_1h.merge(df_away)
        df_away_2h = df_2h.merge(df_away)
        corner_timings_all = df['minute'].tolist()
        corner_timings_home = df_home['minute'].tolist()
        corner_timings_away = df_away['minute'].tolist()
        corner_timings_mean = round(df['minute'].mean(), 2)
        home_corners = important.get("home_corners") or len(df_home)
        away_corners = important.get("away_corners") or len(df_away)
        corners = home_corners + away_corners
        corners_1h = len(df_1h)
        corners_2h = len(df_2h)
        no_corners = corners == 0

        home_corners_1h = len(df_home_1h)
        away_corners_1h = len(df_away_1h)
        home_corners_2h = len(df_home_2h)
        away_corners_2h = len(df_away_2h)
        if fixture["scores"]["ft_score"]:
            ft_corner = f"{home_corners}-{away_corners}"
            
        if fixture["scores"]["ht_score"]:
            ht_corner = f"{home_corners_1h}-{away_corners_1h}"

        most_corners_1h = corners_1h > corners_2h
        most_corners_2h = corners_2h > corners_1h
        most_corners_no = corners_2h == corners_1h

        overs = dict()
        for i in range(5, 13):
            overs[f"o{i}5_corners"] = corners > i

        for i in range(6):
            overs[f"o{i}5_1h_corners"] = corners_1h > i
            overs[f"o{i}5_2h_corners"] = corners_2h > i

        for i in range(2, 8):
            overs[f"o{i}5_home_corners"] = home_corners > i
            overs[f"o{i}5_away_corners"] = away_corners > i

        for i in range(1, 5):
            overs[f"o{i}5_1h_home_corners"] = home_corners_1h > i
            overs[f"o{i}5_2h_home_corners"] = home_corners_2h > i
            overs[f"o{i}5_1h_away_corners"] = away_corners_1h > i
            overs[f"o{i}5_2h_away_corners"] = away_corners_2h > i

        corners_between_85_90 = not df[(
            df["minute"] >= 85) & (df["minute"] <= 90)].empty
        corners_between_75_90 = not df[(
            df["minute"] >= 75) & (df["minute"] <= 90)].empty
        corners_between_35_45 = not df[(
            df["minute"] >= 35) & (df["minute"] <= 45)].empty
        corners_between_80_90 = not df[(
            df["minute"] >= 80) & (df["minute"] <= 90)].empty
        corners_between_40_45 = not df[(
            df["minute"] >= 40) & (df["minute"] <= 45)].empty
        corners_between_0_15 = not df[(
            df["minute"] >= 0) & (df["minute"] <= 15)].empty
        corners_between_0_10 = not df[(
            df["minute"] >= 0) & (df["minute"] <= 10)].empty

        corners_between_0_10_home = not df_home[(
            df_home["minute"] >= 0) & (df_home["minute"] <= 10)].empty
        corners_between_0_10_away = not df_away[(
            df_away["minute"] >= 0) & (df_away["minute"] <= 10)].empty

        first_total_corner = corner_timings_all[0] if corner_timings_all else None
        first_home_corner = corner_timings_home[0] if corner_timings_home else None
        first_away_corner = corner_timings_away[0] if corner_timings_away else None

        return {
            'corner_timings_all': corner_timings_all,
            'corner_timings_home': corner_timings_home,
            'corner_timings_away': corner_timings_away,
            'home_corners': home_corners,
            'away_corners': away_corners,
            'ht_corner': ht_corner,
            'ft_corner': ft_corner,
            'total_corners': corners,
            'corners_1h': corners_1h,
            'corners_2h': corners_2h,
            'no_corners': no_corners,
            'home_corners_1h': home_corners_1h,
            'away_corners_1h': away_corners_1h,
            'home_corners_2h': home_corners_2h,
            'away_corners_2h': away_corners_2h,
            'home_corners': home_corners,
            'away_corners': away_corners,
            'corners_between_85_90': corners_between_85_90,
            'corners_between_75_90': corners_between_75_90,
            'corners_between_35_45': corners_between_35_45,
            'corners_between_80_90': corners_between_80_90,
            'corners_between_40_45': corners_between_40_45,
            'corners_between_0_15': corners_between_0_15,
            'corners_between_0_10': corners_between_0_10,
            'corners_between_0_10_home': corners_between_0_10_home,
            'corners_between_0_10_away': corners_between_0_10_away,

            'first_total_corner': first_total_corner,
            'first_home_corner': first_home_corner,
            'first_away_corner': first_away_corner,
            'corner_timings_mean': corner_timings_mean,
            'most_corners_1h': most_corners_1h,
            'most_corners_2h': most_corners_2h,
            'most_corners_no': most_corners_no,
            **overs
        }

    @staticmethod
    def __format_cards(fixture, important):
        home_id = fixture["localteam_id"]
        away_id = fixture["visitorteam_id"]
        cards = fixture["cards"]["data"]
        if cards:
            df = pd.DataFrame(cards)
        else:
            df = pd.DataFrame(columns=['minute', 'team_id', 'type'])
        df["team_id"] = df["team_id"].astype(int)
        df_home = df[df['team_id'] == home_id]
        df_away = df[df['team_id'] == away_id]

        df_1h = df[df['minute'] <= 45]
        df_2h = df[df['minute'] > 45]
        df_home_1h = df_1h.merge(df_home)
        df_home_2h = df_2h.merge(df_home)
        df_away_1h = df_1h.merge(df_away)
        df_away_2h = df_2h.merge(df_away)

        home_yellow_cards = important.get("home_yellow_cards") or len(
            df_home[df_home["type"] == "yellowcard"])
        home_yellow_red_cards = important.get("home_yellow_red_cards") or len(
            df_home[df_home["type"] == "yellowredcard"])
        home_red_cards = important.get("home_red_cards") or len(
            df_home[df_home["type"] == "redcard"])
        away_yellow_cards = important.get("away_yellow_cards") or len(
            df_away[df_away["type"] == "yellowcard"])
        away_red_cards = important.get("away_red_cards") or len(
            df_away[df_away["type"] == "redcard"])
        away_yellow_red_cards = important.get("away_yellow_red_cards") or len(
            df_away[df_away["type"] == "yellowredcard"])
        home_cards = home_yellow_cards + home_red_cards * 2 - home_yellow_red_cards
        away_cards = away_yellow_cards + away_red_cards * 2 - away_yellow_red_cards

        cards = home_cards + away_cards
        cards_1h = len(df_1h)
        cards_2h = len(df_2h)
        no_cards = cards == 0

        home_cards_1h = len(df_home_1h)
        away_cards_1h = len(df_away_1h)
        home_cards_2h = len(df_home_2h)
        away_cards_2h = len(df_away_2h)

        overs = dict()

        for i in range(2, 7):
            overs[f"o{i}5_cards"] = cards > i

        for i in range(3):
            overs[f"o{i}5_1h_cards"] = cards_1h > i
            overs[f"o{i}5_2h_cards"] = cards_2h > i

        for i in range(4):
            overs[f"o{i}5_home_cards"] = home_cards > i
            overs[f"o{i}5_away_cards"] = away_cards > i

        for i in range(3):
            overs[f"o{i}5_home_yellow_cards"] = home_yellow_cards > i
            overs[f"o{i}5_away_yellow_cards"] = away_yellow_cards > i
            overs[f"o{i}5_home_red_cards"] = home_red_cards > i
            overs[f"o{i}5_away_red_cards"] = away_red_cards > i

        for i in range(2):
            overs[f"o{i}5_1h_home_cards"] = home_cards_1h > i
            overs[f"o{i}5_2h_home_cards"] = home_cards_2h > i
            overs[f"o{i}5_1h_away_cards"] = away_cards_1h > i
            overs[f"o{i}5_2h_away_cards"] = away_cards_2h > i

        return {
            'home_yellow_cards': home_yellow_cards,
            'home_red_cards': home_red_cards,
            'away_yellow_cards': away_yellow_cards,
            'away_red_cards': away_red_cards,
            'home_cards': home_cards,
            'away_cards': away_cards,
            'total_cards': cards,
            'cards_1h': cards_1h,
            'cards_2h': cards_2h,
            'no_cards': no_cards,
            'home_cards_1h': home_cards_1h,
            'away_cards_1h': away_cards_1h,
            'home_cards_2h': home_cards_2h,
            'away_cards_2h': away_cards_2h,
            'home_cards': home_cards,
            'away_cards': away_cards,

            **overs
        }

    def __format_live_odd(self, fixture):
        try:
            inplayOdds = fixture['inplayOdds']["data"]
            formatted_odds = {
                'season_id': fixture['season_id'],
                'fixture_id': fixture['id'],
                'home_id': fixture['localteam_id'],
                'away_id': fixture['visitorteam_id'],
                'type': 'liveodds'
            }

            data = defaultdict(dict)

            for market in inplayOdds:
                marker_id = str(market['market_id'])
                name = MARKETS.get(marker_id, marker_id)
                name = name.replace('Alternative ', '')

                if name == 'Double Chance':
                    data[name] = {
                        'Home or Draw': market['values'][0]['value'],
                        'Draw or Away': market['values'][1]['value'],
                        'Home or Away': market['values'][2]['value']
                    }
                else:
                    for odd in market['values']:
                        team = odd.get('team')
                        value = odd.get('value')
                        info = odd.get('info')
                        substrings = ["over", "under", "exactly"]
                        description = (odd["description"] or "").lower()
                        label = team or description or info
                        if (not team) and description and (description in substrings):
                            label = info
                        data[name][label] = value

                for key in IN_PLAY_ODDS_MAP:
                    odd = IN_PLAY_ODDS_MAP[key]
                    market = odd["market"]
                    info = odd["info"]

                    if data.get(market):
                        val = data[market].get(info)
                        if val != None:
                            formatted_odds[key] = float(val)
                formatted_odds["home"] = {
                    "ft_result":  formatted_odds.get("home_win"),
                    "ht_result":  formatted_odds.get("home_win_ht"),
                    "dnb":  formatted_odds.get("dnb_home")
                }
                formatted_odds["away"] = {
                    "ft_result":  formatted_odds.get("away_win"),
                    "ht_result":  formatted_odds.get("away_win_ht"),
                    "dnb":  formatted_odds.get("dnb_away")
                }
                if self.is_live:
                    underdog = None
                    underdog_playing_home = None
                    favorite = None
                    favorite_playing_away = None
                    favorite_playing_home = None
                    underdog_playing_away = None

                    home_win = formatted_odds.get("home_win", 0)
                    away_win = formatted_odds.get("away_win", 0)
                    if home_win > away_win:
                        underdog = "home"
                        underdog_playing_home = "home"
                        favorite = "away"
                        favorite_playing_away = "away"
                    elif home_win < away_win:
                        underdog = "away"
                        underdog_playing_away = "away"
                        favorite = "home"
                        favorite_playing_home = "home"
                    self.underdog = underdog
                    self.underdog_playing_home = underdog_playing_home
                    self.favorite = favorite
                    self.favorite_playing_away = favorite_playing_away
                    self.underdog_playing_away = underdog_playing_away
                    self.favorite_playing_home = favorite_playing_home

            return formatted_odds
        except Exception as e:
            print(e)
            pass

        return None

    def __format_peak_odd(self, fixture):
        peak_odd = self.__format_live_odd(fixture=fixture)
        if peak_odd:
            peak_odd['type'] = 'peakodds'
            return peak_odd

    def __format_pre_odd_re(self, fixture: dict):
        _result = {
            "season_id": fixture['season_id'],
            "fixture_id": fixture['id'],
            "home_id": fixture['localteam_id'],
            "away_id": fixture['visitorteam_id'],
            "type": "preodds"
        }

        data = dict()
        pre_odds = fixture['odds']['data'] if fixture['odds']['data'] else []
        if not pre_odds:
            return None
        for market in pre_odds:
            name = market['name']
            name = name.replace("Alternative ", "")

            if name not in data:
                data[name] = dict()

            try:
                bet365 = [x for x in market['bookmaker']
                          ['data'] if x['name'] == 'bet365'][0]
            except:
                bet365 = None

            if bet365:
                # TODO: 406
                if name == "Double Chance":
                    try:
                        data[name] = {
                            "Home or Draw": bet365["odds"]["data"][0]["value"],
                            "Draw or Away": bet365["odds"]["data"][1]["value"],
                            "Home or Away": bet365["odds"]["data"][2]["value"],
                        }
                    except:
                        pass
                else:
                    for odd in bet365["odds"]["data"]:
                        label = odd.get('label')
                        value = odd.get('value')
                        total = odd.get('total')
                        extra = odd.get('extra')
                        probability = odd.get('probability')

                        if total:
                            label += ' ' + total

                        if not label:
                            label = extra or probability

                        data[name][label] = value
        import json

        for key in PRE_ODDS_MAP:
            market = PRE_ODDS_MAP[key]['market']
            info = PRE_ODDS_MAP[key]['info']

            if market in data and info in data[market]:
                val = data[market][info]
                if val != None:
                    _result[key] = float(val)

        return _result

    @staticmethod
    def __format_stat(fixture, team_id):
        stats = fixture["stats"]["data"]
        if stats:
            df = pd.DataFrame(map(flatten, stats))
        else:
            df = pd.DataFrame(columns=['team_id'])
        df["team_id"] = df["team_id"].astype(int)
        df = df[df['team_id'] == team_id]

        hmap = {
            "possession": "possessiontime",
            "passes": "passes_total",
            "shots_on_target": "shots_ongoal",
            "shots_off_target": "shots_offgoal",
            "shots": "shots_total",
            "shots_inside_box": "shots_insidebox",
            "shots_outside_box": "shots_outsidebox",
            "attacks": "attacks_attacks",
            "dangerous_attacks": "attacks_dangerous_attacks"
        }
        if df.empty:
            return {}
        stat = df.iloc[0]
        stat = stat.to_dict()

        for key, value in hmap.items():
            stat[key] = stat.pop(value, None)

        return stat

    def __format_stats(self, fixture):
        stats = dict()
        stats["home"] = self.__format_stat(
            fixture, fixture['localteam_id'])

        stats["away"] = self.__format_stat(
            fixture, fixture['visitorteam_id'])

        if stats["home"]:
            stats["home"].update({
                "league_position": fixture['standings']['localteam_position'],

            })
        if stats["away"]:
            stats["away"].update({
                "league_position": fixture['standings']['visitorteam_position'],

            })

        winning_team = None
        losing_team = None
        home_goals = stats["home"].get("goals", 0)
        away_goals = stats["away"].get("goals", 0)
        if home_goals > away_goals:
            winning_team = "home"
            losing_team = "away"
        elif home_goals < away_goals:
            winning_team = "away"
            losing_team = "home"
        self.winning_team = winning_team
        self.losing_team = losing_team
        # stats["winning_team"] = stats.get(winning_team)
        # stats["losing_team"] = stats.get(losing_team)

        return stats

    def __format_favorite_underdog_winning_losing(self, data):
        formatted = dict()
        teams = ["winning_team", "losing_team", "underdog",
                 "underdog_playing_home",
                 "favorite",
                 "favorite_playing_away",
                 "underdog_playing_away",
                 "favorite_playing_home"]
        instance = self.__dict__
        # print(instance)
        for team in teams:
            # print(data.get(instance[team]), "TTETTET")
            formatted[team] = data.get(instance.get(team))

        # print("HAHAHAH", formatted)
        # if data.get("live_odds"):
        #     for team in teams:
        #         pre_odds[team] = data["live_odds"].get(instance[team])
        # if data.get("pre_odds"):
        #     for team in teams:
        #         live_odds[team] = data["pre_odds"].get(instance[team])
        return formatted

    @staticmethod
    def __format_important_stat(df, team):
        items = dict()
        if not df.empty:
            stat = df.iloc[0]
            corners = stat['corners'] if stat['corners'] else 0
            offsides = stat['offsides'] if stat['offsides'] else 0
            goals = stat['goals'] if stat['goals'] else 0
            yellow_cards = stat['yellowcards'] if stat['yellowcards'] else 0
            yellow_red_cards = stat['yellowredcards'] if stat['yellowredcards'] else 0
            # yellow_cards += yellow_red_cards
            red_cards = stat['redcards'] if stat['redcards'] else 0
            cards = yellow_cards + red_cards
            items.update({
                f"{team}_corners": corners,
                f"{team}_offsides": offsides,
                f"{team}_goals": goals,
                f"{team}_yellow_cards": yellow_cards,
                f"{team}_yellow_red_cards": yellow_red_cards,
                f"{team}_red_cards": red_cards,
                f"{team}_corners": corners,
                f"{team}_cards": cards
            })
        else:
            return {
                f"{team}_corners": None,
                f"{team}_offsides": None,
                f"{team}_goals": None,
                f"{team}_yellow_cards": None,
                f"{team}_yellow_red_cards": None,
                f"{team}_red_cards": None,
                f"{team}_corners": None,
                f"{team}_cards": None
            }

        return items

    def __format_important_stats(self, fixture):
        home_id = fixture["localteam_id"]
        away_id = fixture["visitorteam_id"]
        if not "stats" in fixture:
            return {}
        stats = fixture["stats"]["data"]
        if stats:
            df = pd.DataFrame(map(flatten, stats))
        else:
            df = pd.DataFrame(columns=['team_id'])

        df["team_id"] = df["team_id"].astype(int)
        df_home = df[df['team_id'] == home_id]
        df_away = df[df['team_id'] == away_id]
        both_items = dict()
        home_items = self.__format_important_stat(df_home, "home")
        away_items = self.__format_important_stat(df_away, "away")
        both_items.update(home_items)
        both_items.update(away_items)
        if (not df_away.empty) and (not df_home.empty):
            both_items["offsides"] = home_items["home_offsides"] + \
                away_items["away_offsides"]
        else:
            both_items["offsides"] = None
        return both_items

    def format(self, fixture):
        # data = dict()
        important = self.__format_important_stats(fixture)
        data = self.__fixture_info(fixture=fixture)

        goals = fixture.get('goals')
        corners = fixture.get('corners')
        cards = fixture.get('cards')
        events = fixture.get('events')

        if corners:
            corners = corners["data"]
            data.update({
                'corners_json': corners})
            if not self.is_live:
                corners_data = self.__format_corners(fixture, important)

        if goals:
            goals = goals["data"]
            data.update({
                'goals_json': goals})
            if not self.is_live:
                goals_data = self.__format_goals(fixture, important)

        if cards:
            cards = cards["data"]
            data.update({
                'cards_json': cards})
            if not self.is_live:
                cards_data = self.__format_cards(fixture, important)

        if events:
            events = events["data"]
            data.update({
                'events_json': events})

        if "probability" in fixture:
            probability = self.__format_probability(fixture)
            data.update({
                'probability': probability})

        if "inplayOdds" in fixture:
            live_odds = self.__format_live_odd(fixture)

        if "odds" in fixture:
            pre_odds = self.__format_pre_odd_re(fixture)

        if "stats" in fixture:
            stats = self.__format_stats(fixture)

        if "inplayOdds" in fixture:
            if live_odds:
                live_odds.update(
                    self.__format_favorite_underdog_winning_losing(live_odds))
                data.update({
                    'live_odds': live_odds})

        if "odds" in fixture:
            if pre_odds:
                pre_odds.update(
                    self.__format_favorite_underdog_winning_losing(pre_odds))
                data.update({
                    'pre_odds': pre_odds})

        if "stats" in fixture:
            if stats:
                stats.update(
                    self.__format_favorite_underdog_winning_losing(stats))
                data.update({
                    'stats': stats})

        keys = fixture.keys()
        if not self.is_live and "goals" in keys and "corners" in keys and "cards" in keys and "stats" in keys:
            result = {
                **goals_data,
                **corners_data,
                **cards_data,
                'fixture_id': fixture['id']
                # **important
            }
            data.update({
                'result': result
            })

            if fixture["time"]["status"] in ["FT", "FT_PEN"]:
                data.update({
                    'result_updated': True
                })
        data['fixture_id'] = fixture['id']

        response = {
            "$set": data,
        }
        if "inplayOdds" in fixture:
            peak_odds = self.__format_peak_odd(fixture)
            response["$max"] = flatten({"peak_odds": peak_odds}, sep=".")

        return response
