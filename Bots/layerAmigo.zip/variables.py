MONGO_URL = "mongodb+srv://footyamigo:1gFH3YZB42lKKOTG@cluster0.aapbr.mongodb.net/footyamigo"
MARKETS = {
    "1": "3Way Result",
    "10": "Home/Away",
    "12": "Over/Under",
    "28": "Asian Handicap",
    "29": "Asian Handicap Cards",
    "30": "Asian Total Cards",
    "31": "First Card Received",
    "32": "Time Of First Card",
    "33": "Team Cards",
    "34": "Corner Match Bet",
    "35": "Corner Handicap",
    "36": "Time Of First Corner",
    "37": "3Way Result 1st Half",
    "38": "Goals Over/Under 2nd Half",
    "39": "Team Corners",
    "47": "Over/Under 2nd Half",
    "63": "Double Chance",
    "69": "Team To Score First",
    "75": "Team To Score Last",
    "80": "3Way Result 2nd Half",
    "83": "Handicap Result",
    "13343": "Team Clean Sheet",
    "28075": "Fulltime Result",
    "28076": "To Win 2nd Half",
    "28077": "Match Goals",
    "28080": "3-Way Handicap",
    "28082": "Draw No Bet",
    "28083": "Last Team to Score 2way",
    "28085": "Goals Odd/Even",
    "28086": "Away Goals",
    "28088": "Home Goals",
    "28089": "Final Score",
    "28091": "Both Teams to Score",
    "28093": "Away Clean Sheet",
    "28096": "6th Goal",
    "28097": "Home to Score in 2nd Half",
    "28098": "Away to Score in 2nd Half",
    "28099": "Both Teams to Score in 2nd Half",
    "28100": "Away Exact Goals",
    "28101": "Home Exact Goals",
    "28182": "Last Team to Score",
    "28189": "Home Clean Sheet",
    "31355": "Half Time Result",
    "31359": "First Half Goals",
    "31369": "Half Time/Full Time",
    "31379": "Both Teams to Score in 1st Half",
    "31386": "Half Time Correct Score",
    "31387": "1st Half 3-Way Handicap",
    "32043": "1X2 Rest 1st Half",
    "367139": "Extra Time Result",
    "461545": "Extra Time Goals",
    "975903": "Goals Over/Under 1st Half",
    "975905": "HT/FT Double",
    "975909": "Correct Score",
    "975916": "Correct Score 1st Half",
    "975925": "Asian Handicap First Half",
    "975926": "Double Chance - 1st Half",
    "975930": "Odd/Even",
    "975932": "Odd/Even 1st Half",
    "976096": "Clean Sheet - Home",
    "976105": "Both Teams To Score",
    "976144": "Highest Scoring Half",
    "976193": "Win Both Halves",
    "976198": "Total - Home",
    "976204": "Total - Away",
    "976209": "Handicap Result 1st Half",
    "976226": "Both Teams To Score - 1st Half",
    "976230": "Both Teams To Score - 2nd Half",
    "976236": "Win To Nil",
    "976241": "Exact Goals Number",
    "976265": "To Win Either Half",
    "976270": "Home Team Exact Goals Number",
    "976286": "Away Team Exact Goals Number",
    "976298": "2nd Half Exact Goals Number",
    "976316": "Results/Both Teams To Score",
    "976334": "Result/Total Goals",
    "976348": "Home Team Score a Goal",
    "976360": "Away Team Score a Goal",
    "976373": "First 10 min Winner",
    "976384": "Corners Over Under",
    "976389": "1st Half Exact Goals Number",
    "977179": "Corners 1x2",
    "977329": "Correct Score 2nd Half",
    "2306278": "To Qualify",
    "8594683": "Clean Sheet - Away",
    "14234050": "Win to Nil - Away",
    "14234105": "Double Chance - 2nd Half",
    "14234147": "Home win both halves",
    "14234155": "Away win both halves",
    "22581781": "Away Exact Goals",
    "136696391": "Draw No Bet",
    "136703809": "To Win the Trophy",
    "136703812": "Extra Time 1st Half Result",
    "136703813": "Alternative Match Goals",
    "136703814": "1st Goal - Extra Time",
    "136703815": "Extra Time 1st Half Goals",
    "136703817": "Extra Time Corners",
    "136703818": "Total Corners",
    "136703819": "Extra Time Asian Corners",
    "136703820": "Extra Time 1st Half Corners",
    "136703821": "2-Way Corners",
    "136703822": "Extra Time 1st Half Asian Corners",
    "136703823": "1st Half Corners",
    "136703824": "Extra Time Asian Handicap (0-0)",
    "136703825": "Alternative Total Corners",
    "136703826": "Extra Time Goal Line (0-0)",
    "136703827": "Game Won In Extra Time",
    "136703828": "Extra Time Double Result",
    "136703829": "Game Won After Penalties",
    "136703830": "Asian Handicap (1-1)",
    "136703832": "Alternative Asian Handicap (2-2)",
    "136703834": "Goal Line (3-0)",
    "136703836": "Alternative Goal Line (0-0)",
    "136703838": "1st Half Asian Handicap (0-0)",
    "136703842": "1st Half Goal Line",
    "136703846": "Asian Corners",
    "136703850": "Corners Race",
    "136703852": "Race to 5 Corners",
    "136703854": "Race to 7 Corners",
    "136703856": "Race to 9 Corners",
    "136703858": "3rd Corner",
    "136703860": "Last Corner",
    "136703863": "Result / Both Teams To Score",
    "136703866": "Home to Score in Both Halves",
    "136703868": "Away to Score in Both Halves",
    "136703870": "Ten Minute Goals - 80:00 - End",
    "136703871": "Ten Minute Corners - 80:00 - End",
    "136703872": "50 mins Result",
    "136703873": "60 mins Result",
    "136703874": "70 mins Result",
    "136703875": "80 mins Result",
    "136703876": "Time of 2nd Goal",
    "136703877": "Time of 3rd Goal - Away",
    "136703878": "Time of 2nd Goal - Away",
    "136703879": "20 mins Result",
    "136703880": "30 mins Result",
    "136703881": "40 mins Result",
    "136704020": "To Win Shootout",
    "136704050": "Goalscorers",
    "136704051": "To Score at Any Time",
    "136704053": "Multi Scorers",
    "136704055": "To Score a Hat Trick",
    "136704058": "Away Penalty Shootout",
    "136704059": "Home Penalty Shootout",
    "136704060": "Penalties Converted in Shootout Over/Under",
    "136704061": "Penalty Shootout to Go to Sudden Death",
    "136704062": "Total Penalties Taken in Shootout",
    "136704063": "Asian Handicap - Penalties converted in Shootout (5-6)",
    "136704064": "Goal Line - Penalties converted in shootout (5-6)",
    "136704065": "Away Penalties Converted in Shootout",
    "136704066": "Home Penalties Converted in Shootout",
    "136704067": "Last Penalty in Shootout Score/Miss",
    "136704069": "Alternative Asian Handicap (0-0)",
    "136704071": "Alternative Asian Handicap (0-1)",
    "136704072": "Alternative Goal Line (1-0)",
    "136704074": "Away - 1st Penalty",
    "136704075": "Team to Take Last Penalty in Shootout",
    "136704078": "Home - 1st Penalty",
    "136704079": "Match Time Result",
    "136704091": "Corner Handicap",
    "136704092": "Most Corners",
    "136704093": "5th Goal Method",
    "136704116": "Alternative Goal Line (1-1)",
    "136704119": "Time of 9th Goal",
    "136704127": "Time of 3rd Goal",
    "136704128": "Time of 6th Goal - Away",
    "136704146": "Time of 8th Goal",
    "136704147": "Time of 8th Goal - Away",
    "136704148": "Time of 1st Goal - Away",
    "136704149": "Time of 6th Goal",
    "136704150": "Time of 5th Goal - Away",
    "136704151": "Time of 1st Goal - Away",
    "136704212": "Method of Qualification",
    "136704243": "Ten Minute Cards - 80:00 - End",
    "136704265": "Time of 4th Goal",
    "136704329": "Number of Cards",
    "136704403": "Time of 7th Goal",
    "136704468": "Next Minute (80:00 - 80:59)",
    "136704522": "Time of 5th Goal",
    "136704524": "Time of 1st Goal - Away",
    "136704525": "Player Shots on Target",
    "136704526": "Player Shots",
    "136704528": "Player Assists",
    "136704529": "Match Shots on Target",
    "136704532": "Team Shots on Target",
    "136704537": "Match Shots",
    "136704540": "Team Shots",
    "136704546": "Match Offsides",
    "136704549": "Team Offsides",
    "136704558": "Next Set Piece 85:00 - 89:59",
    "136704561": "Ten Minute Goal Kicks - 80:00 - End",
    "136704563": "Ten Minute Free Kicks - 80:00 - End",
    "136704566": "Ten Minute Throws - 80:00 - End",
    "136705699": "To Finish 3rd",
    "136706055": "Home Odd/Even",
    "136706056": "Away Odd/Even",
    "136706307": "2nd Half Corners",
    "136706545": "Player to be Booked",
    "136706546": "Player to be Sent Off",
    "136706558": "2nd Half Goals",
    "136706561": "Goal Line (1-0)",
    "136830669": "Alternative 1st Half Handicap Result",
    "136830688": "Winning Margin",
    "136830703": "To Score In Both Halves By Teams",
    "136830705": "Total Goals/Both Teams To Score",
    "136830707": "Goal Line",
    "136830709": "Goal Line 1H",
    "136830811": "Own Goal",
    "136830892": "Corners Asian Handicap",
    "136830894": "Home Corners Over/Under",
    "136830897": "Away Corners Over/Under",
    "137918013": "Draw No Bet",
    "137918016": "HT/FT",
    "137918017": "Home Team Highest Scoring Half",
    "137918019": "Away Team Highest Scoring Half",
    "137918020": "Odd/Even 2nd Half",
    "137918021": "1st Half Asian Corners",
    "137918022": "Alternative Total Goals",
    "137918023": "Teams To Score A Goal",
    "137918024": "Total Goal Minutes",
    "137918025": "1st Goal Method",
    "137918026": "Early Goal",
    "137918027": "Late Goal",
    "137918028": "Time Of 1st Goal Brackets",
    "137918029": "Time Of 1st Team Goal",
    "137918032": "To Score A Penalty",
    "137918033": "1st Half Handicap",
    "137918034": "Method Of Victory",
    "137918035": "Game Decided In Extra Time",
    "137918036": "Game Decided After Penalties",
    "137918037": "Alternative Handicap Result",
    "137918038": "To Miss A Penalty",
    "1256989855": "1st Goal",
    "1256989857": "Goal Line (0-0)",
    "1256989859": "2nd Corner",
    "1256989860": "Alternative Asian Handicap",
    "1256989862": "Time of Goal - Away",
    "1256989864": "Alternative Goal Line",
    "1256989865": "Alternative 1st Half Asian Handicap",
    "1256989866": "Alternative 1st Half Goal Line",
    "1256989867": "Time of Goal ",
    "1256989868": "1st Penalty - Home",
    "1256989869": "Ten Minute Cards",
    "1256989870": "Ten Minute Throws",
    "1256989871": "Ten Minute Corners",
    "1256989872": "Ten Minute Free Kicks",
    "1256989873": "Ten Minute Goal Kicks",
    "1256989875": "Ten Minute Goals",
    "1256989876": "Next Set Piece",
    "1256989877": "Next Minute Penalty Awarded",
    "1256989878": "Next Minute Card",
    "1256989880": "Next Minute Throw In",
    "1256989881": "Next Minute Free Kick",
    "1256989882": "Next Minute Goal Kick",
    "1256989883": "Next Minute Corner",
    "1256989884": "Next Minute Goal",
    "1257101766": "Exact 1st Half Goals",
    "1257116774": "Halftime Result/Total Goals",
    "1257116775": "Halftime Result/Both Teams To Score",
    "1265634158": "Team Total Goals",
    "1265634160": "Goalscorer",
    "1265634161": "Multi Scorers",
    "1265634162": "Team Goalscorer",
    "1265634165": "4th Goal",
    "1265634166": "Card Handicap",
    "1265634167": "Alternative Card Handicap",
    "1265634170": "Team Performances",
    "1265634173": "6th Corner",
    "1265634174": "2nd Goal",
    "1265634175": "Goal Line (1-2)",
    "1265634176": "4th Corner",
    "1265634177": "8th Corner",
    "1265634178": "5th Goal",
    "1265634179": "7th Corner",
    "1265634180": "9th Corner",
    "1265634181": "10th Corner",
    "1265634182": "5th Corner",
    "1265634183": "Goal Line (0-0)",
    "1265634184": "Goal Line (0-1)",
    "1265634187": "Alternative Goal Line (0-1)",
    "1265634188": "Ten Minute Goals - 40:00 - 49:59",
    "1265634190": "3rd Goal Method ",
    "1265634191": "4th Goal Method",
    "1265634192": "Asian Handicap (1-1)",
    "1265634193": "14th Corner",
    "1265634195": "Goal Line (2-0)",
    "1265634196": "Ten Minute Goals - 70:00 - 79:59",
    "1265634198": "Asian Handicap (0-4)",
    "1265634199": "Ten Minute Corners - 70:00 - 79:59 ",
    "1265634200": "Alternative Asian Handicap (1-1)",
    "1265634201": "11th Corner",
    "1265634202": "Asian Handicap (1-0)",
    "1265634204": "To Score In Half",
    "1265634205": "First Match Corner",
    "1265634207": "Last Match Corner",
    "1265634208": "Multicorners",
    "1265634210": "Asian Total Corners",
    "1265634211": "Corners 2-Way",
    "1265634212": "Player Tackles",
    "1265634214": "Match Tackles",
    "1265634215": "A Red Card in the Match",
    "1265634216": "A Penalty in the Match",
    "1265634218": "Time of 4th Goal - Away",
    "1265634221": "First Corner",
    "1265634222": "10 Over/Under",
    "1265634223": "Total Corners (1st Half)",
    "1265634224": "Both Teams to Score 1st Half - 2nd Half",
    "1265634870": "Asian Handicap (2-0)",
    "1265634871": "Asian Handicap (3-0)",
    "1265634872": "Goal Line (1-1)",
    "1265634873": "Goal Line (4-0)",
    "1265634874": "Asian Handicap (1-2)",
    "1265634876": "Asian Handicap (4-0)",
    "1265634877": "Asian Handicap (1-3)",
    "1265634878": "Goal Line (1-3)",
    "1265634879": "Asian Handicap (5-0)",
    "1265634880": "Goal Line (5-0)",
    "1265634881": "3rd Goal",
    "1265634882": "Asian Handicap (2-2)",
    "1265634883": "Goal Line (2-2)",
    "1265634884": "Asian Handicap (0-2)",
    "1265634885": "Goal Line (0-2)",
    "1265634886": "Asian Handicap (0-3)",
    "1265634887": "Goal Line (0-3)",
    "1265634888": "Goal Line (2-1)",
    "1265634889": "Asian Handicap (3-1)",
    "1265634890": "Goal Line (3-1)",
    "1265634891": "Asian Handicap (3-2)",
    "1265634892": "Goal Line (3-2)",
    "1265634893": "Asian Handicap (4-1)",
    "1265634894": "Goal Line (4-1)",
    "1265634895": "12th Corner",
    "1265634896": "13th Corner",
    "1265634897": "15th Corner",
    "1265634898": "1st Half Asian Handicap (0-1)",
    "1265634899": "1st Half Goal Line (0-1)",
    "1265634900": "1st Half Asian Handicap (0-2)",
    "1265634901": "1st Half Asian Handicap (0-2)",
    "1265634902": "1st Half Goal Line (0-2)",
    "1265634903": "1st Half Goal Line (0-2)",
    "1265634904": "Asian Handicap (0-4)",
    "1265634905": "Goal Line (0-4)",
    "1265634906": "Asian Handicap (1-4)",
    "1265634907": "Goal Line (1-4)",
    "1265634908": "Goal Line (0-5)",
    "1265634909": "7th Goal",
    "1265634910": "Asian Handicap (1-5)",
    "1265634911": "Goal Line (1-5)",
    "1265634912": "Asian Handicap (2-3)",
    "1265634913": "Goal Line (2-3)",
    "1265634914": "Ten Minute Goals - 00:00 - 09:59",
    "1265634915": "Ten Minute Goals - 00:00 - 09:59",
    "1265634916": "Ten Minute Corners - 00:00 - 09:59",
    "1265634917": "Ten Minute Corners - 00:00 - 09:59",
    "1265634918": "1st Half Goal Line (1-0)",
    "1265634919": "Ten Minute Goals - 10:00 - 19:59",
    "1265634920": "Ten Minute Corners - 10:00 - 19:59",
    "1265634921": "1st Half Asian Handicap (1-1)",
    "1265634922": "1st Half Goal Line (1-1)",
    "1265634923": "Ten Minute Goals - 20:00 - 29:59",
    "1265634924": "Ten Minute Corners - 20:00 - 29:59",
    "1265634925": "Ten Minute Goals - 30:00 - 39:59",
    "1265634926": "Ten Minute Corners - 30:00 - 39:59",
    "1265634927": "Ten Minute Corners - 40:00 - 49:59",
    "1265634928": "Ten Minute Goals - 50:00 - 59:59",
    "1265634929": "Ten Minute Corners - 50:00 - 59:59",
    "1265634930": "Ten Minute Goals - 60:00 - 69:59",
    "1265634931": "Ten Minute Corners - 60:00 - 69:59",
    "1265634932": "Alternative Goal Line (2-0)",
    "1265634933": "1st Half Asian Handicap (2-0)",
    "1265634934": "1st Half Goal Line (2-0)",
    "1265634935": "Asian Handicap (4-2)",
    "1265634936": "Asian Handicap (4-2)",
    "1265634937": "Asian Handicap (4-2)",
    "1265634938": "Goal Line (4-2)",
    "1265634939": "Alternative Asian Handicap (2-1)",
    "1265634940": "Alternative Asian Handicap (2-1)",
    "1265634941": "Alternative Goal Line (2-1)",
    "1265634942": "Alternative Goal Line (2-1)",
    "1265634943": "Asian Handicap (2-4)",
    "1265634944": "Goal Line (2-4)",
    "1265634945": "8th Goal",
    "1265634946": "Asian Handicap (2-5)",
    "1265634947": "Goal Line (2-5)",
    "1265634948": "Asian Handicap (5-1)",
    "1265634949": "Goal Line (5-1)",
    "1265634950": "Alternative Asian Handicap (3-1)",
    "1265634951": "Alternative Goal Line (3-1)",
    "1265634952": "Alternative Asian Handicap (3-0)",
    "1265634953": "Alternative Goal Line (3-0)",
    "1265634954": "2nd Goal Method",
    "1265634955": "Alternative Asian Handicap (0-2)",
    "1265634956": "Alternative Asian Handicap (0-2)",
    "1265634957": "Alternative Goal Line (0-2)",
    "1265634958": "Asian Handicap (3-3)",
    "1265634959": "Goal Line (3-3)",
    "1265634960": "Alternative Asian Handicap (1-2)",
    "1265634961": "Alternative Goal Line (1-2)",
    "1265634962": "1st Half Asian Handicap (0-3)",
    "1265634963": "1st Half Goal Line (0-3)",
    "1265634964": "Asian Handicap (6-0)",
    "1265634965": "Goal Line (6-0)",
    "1265634966": "1st Half Asian Handicap (1-2)",
    "1265634967": "1st Half Goal Line (1-2)",
    "1265634968": "Ten Minute Cards - 00:00 - 09:59",
    "1265634969": "Alternative Asian Handicap (0-3)",
    "1265634970": "Alternative Goal Line (0-3)",
    "1265634971": "Ten Minute Cards - 10:00 - 19:59",
    "1265634972": "1st Half Asian Handicap (0-4)",
    "1265634973": "1st Half Goal Line (0-4)",
    "1265634974": "Alternative Asian Handicap (0-4)",
    "1265634975": "Alternative Goal Line (0-4)",
    "1265634976": "1st Half Asian Handicap (2-1)",
    "1265634977": "1st Half Goal Line (2-1)",
    "1265634978": "Ten Minute Cards - 20:00 - 29:59",
    "1265634979": "Alternative Goal Line (2-2)",
    "1265634980": "Ten Minute Cards - 30:00 - 39:59",
    "1265634981": "Ten Minute Cards - 30:00 - 39:59",
    "1265634982": "Ten Minute Cards - 40:00 - 49:59",
    "1265634983": "Ten Minute Cards - 50:00 - 59:59",
    "1265634984": "16th  Corner",
    "1265634985": "Asian Handicap (0-6)",
    "1265634986": "Goal Line (0-6)",
    "1265634987": "Alternative Asian Handicap (0-5)",
    "1265634988": "Alternative Goal Line (0-5)",
    "1265634989": "Asian Handicap (0-7)",
    "1265634990": "Goal Line (0-7)",
    "1265634991": "Ten Minute Cards - 60:00 - 69:59",
    "1265634992": "Ten Minute Cards - 70:00 - 79:59",
    "1265634993": "1st Half Asian Handicap (3-0)",
    "1265634994": "1st Half Goal Line (3-0)",
    "1265634995": "Asian Handicap - Penalties converted in Shootout (0-0)",
    "1265634996": "Goal Line - Penalties converted in shootout (0-0)",
    "1265634997": "Asian Handicap - Penalties converted in Shootout (1-0)",
    "1265634998": "Goal Line - Penalties converted in shootout (1-0)",
    "1265634999": "Asian Handicap - Penalties converted in Shootout (2-0)",
    "1265635000": "Goal Line - Penalties converted in shootout (2-0)",
    "1265635001": "Asian Handicap - Penalties converted in Shootout (2-1)",
    "1265635002": "Goal Line - Penalties converted in shootout (2-1)",
    "1265635003": "Asian Handicap - Penalties converted in Shootout (3-1)",
    "1265635004": "Goal Line - Penalties converted in shootout (3-1)",
    "1265635005": "Asian Handicap - Penalties converted in Shootout (3-2)",
    "1265635006": "Goal Line - Penalties converted in shootout (3-2)",
    "1265635007": "1st Half Asian Handicap (2-2)",
    "1265635008": "1st Half Goal Line (2-2)",
    "1265635009": "Asian Handicap - Penalties converted in Shootout (4-2)",
    "1265635010": "Goal Line - Penalties converted in shootout (4-2)",
    "1265635011": "Alternative Asian Handicap (4-0)",
    "1265635012": "Alternative Asian Handicap (4-0)",
    "1265635013": "Alternative Goal Line (4-0)",
    "1265635014": "Alternative Goal Line (4-0)",
    "1265635015": "1st Half Asian Handicap (4-0)",
    "1265635016": "1st Half Asian Handicap (4-0)",
    "1265635017": "1st Half Goal Line (4-0)",
    "1265635018": "1st Half Goal Line (4-0)",
    "1265635019": "Asian Handicap - Penalties converted in Shootout (4-3)",
    "1265635020": "Goal Line - Penalties converted in shootout (4-3)",
    "1265635021": "Alternative Asian Handicap (5-0)",
    "1265635022": "Alternative Goal Line (5-0)",
    "1265635023": "1st Half Asian Handicap (5-0)",
    "1265635024": "1st Half Goal Line (5-0)",
    "1265635025": "17th Corner",
    "1265635026": "18th Corner",
    "1265635027": "Asian Handicap (3-4)",
    "1265635028": "Goal Line (3-4)",
    "1265635029": "2nd Goal - Extra Time",
    "1265635030": "Extra Time Asian Handicap (1-0)",
    "1265635031": "Asian Handicap - Penalties converted in Shootout (0-1)",
    "1265635032": "Goal Line - Penalties converted in shootout (0-1)",
    "1265635033": "Asian Handicap - Penalties converted in Shootout (1-1)",
    "1265635034": "Goal Line - Penalties converted in shootout (1-1)",
    "1265635035": "Asian Handicap - Penalties converted in Shootout (1-2)",
    "1265635036": "Goal Line - Penalties converted in shootout (1-2)",
    "1265635037": "Asian Handicap - Penalties converted in Shootout (2-2)",
    "1265635038": "Goal Line - Penalties converted in shootout (2-2)",
    "1265635039": "Asian Handicap - Penalties converted in Shootout (2-3)",
    "1265635040": "Goal Line - Penalties converted in shootout (2-3)",
    "1265635041": "Asian Handicap - Penalties converted in Shootout (3-3)",
    "1265635042": "Goal Line - Penalties converted in shootout (3-3)",
    "1265635043": "Asian Handicap - Penalties converted in Shootout (3-4)",
    "1265635044": "Goal Line - Penalties converted in shootout (3-4)",
    "1265635045": "Asian Handicap - Penalties converted in Shootout (4-4)",
    "1265635046": "Goal Line - Penalties converted in shootout (4-4)",
    "1265635047": "Asian Handicap - Penalties converted in Shootout (4-5)",
    "1265635048": "Goal Line - Penalties converted in shootout (4-5)",
    "1265635049": "Asian Handicap - Penalties converted in Shootout (5-5)",
    "1265635050": "Goal Line - Penalties converted in shootout (5-5)",
    "1265635051": "Asian Handicap - Penalties converted in Shootout (6-6)",
    "1265635052": "Goal Line - Penalties converted in shootout (6-6)",
    "1265635053": "Asian Handicap - Penalties converted in Shootout (6-7)",
    "1265635054": "Goal Line - Penalties converted in shootout (6-7)",
    "1265635055": "Alternative Asian Handicap (2-3)",
    "1265635056": "Alternative Goal Line (2-3)",
    "1265635057": "Asian Handicap (1-6)",
    "1265635058": "Goal Line (1-6)",
    "1265635059": "Asian Handicap (4-3)",
    "1265635060": "Goal Line (4-3)",
    "1265635061": "9th Goal",
    "1265635062": "Asian Handicap (5-3)",
    "1265635063": "Goal Line (5-3)",
    "1265635064": "Alternative Asian Handicap (3-3)",
    "1265635065": "Alternative Goal Line (3-3)",
    "1265635066": "Asian Handicap (6-1)",
    "1265635067": "Asian Handicap (6-1)",
    "1265635068": "Goal Line (6-1)",
    "1265635069": "Goal Line (6-1)",
    "1265635070": "Asian Handicap (6-2)",
    "1265635071": "Goal Line (6-2)",
    "1265635072": "Alternative Asian Handicap (3-2)",
    "1265635073": "Alternative Goal Line (3-2)",
    "1265635074": "Alternative Asian Handicap (1-3)",
    "1265635075": "Alternative Goal Line (1-3)",
    "1265635076": "1st Half Asian Handicap (1-3)",
    "1265635077": "1st Half Goal Line (1-3)",
    "1265635078": "Alternative Asian Handicap (4-1)",
    "1265635079": "Alternative Asian Handicap (4-1)",
    "1265635080": "Alternative Goal Line (4-1)",
    "1265635081": "1st Half Asian Handicap (2-3)",
    "1265635082": "1st Half Asian Handicap (2-3)",
    "1265635083": "1st Half Goal Line (2-3)",
    "1265635084": "1st Half Asian Handicap (3-1)",
    "1265635085": "1st Half Goal Line (3-1)",
    "1265635086": "1st Half Asian Handicap (4-1)",
    "1265635087": "1st Half Goal Line (4-1)",
    "1265635088": "Alternative Asian Handicap (4-2)",
    "1265635089": "Alternative Goal Line (4-2)",
    "1265635090": "1st Half Asian Handicap (4-2)",
    "1265635091": "1st Half Goal Line (4-2)",
    "1265635092": "Alternative Asian Handicap (1-4)",
    "1265635093": "Alternative Goal Line (1-4)",
    "1265635094": "Alternative Asian Handicap (1-5)",
    "1265635095": "Alternative Goal Line (1-5)",
    "1265635096": "Alternative Asian Handicap (2-5)",
    "1265635097": "Alternative Goal Line (2-5)",
    "1265635098": "Asian Handicap (2-6)",
    "1265635099": "Alternative Asian Handicap (2-6)",
    "1265635100": "Goal Line (2-6)",
    "1265635101": "Alternative Goal Line (2-6)",
    "1265635102": "10th Goal",
    "1265635103": "Asian Handicap (2-7)",
    "1265635104": "Alternative Asian Handicap (2-7)",
    "1265635105": "Goal Line (2-7)",
    "1265635106": "Alternative Goal Line (2-7)",
    "1265635107": "Alternative Asian Handicap (3-4)",
    "1265635108": "Alternative Goal Line (3-4)",
    "1265635109": "Asian Handicap (4-4)",
    "1265635110": "Alternative Asian Handicap (4-4)",
    "1265635111": "Goal Line (4-4)",
    "1265635112": "Alternative Goal Line (4-4)",
    "1265635113": "Asian Handicap (5-2)",
    "1265635114": "Alternative Asian Handicap (5-2)",
    "1265635115": "Goal Line (5-2)",
    "1265635116": "Alternative Goal Line (5-2)",
    "1265635117": "Alternative Asian Handicap (6-2)",
    "1265635118": "Alternative Goal Line (6-2)",
    "1265635119": "Asian Handicap (6-3)",
    "1265635120": "Goal Line (6-3)",
    "1265635121": "Alternative Asian Handicap (6-0)",
    "1265635122": "Alternative Goal Line (6-0)",
    "1265635123": "Alternative Asian Handicap (2-4)",
    "1265635124": "Alternative Goal Line (2-4)",
    "1265635125": "1st Half Asian Handicap (3-2)",
    "1265635126": "1st Half Asian Handicap (3-2)",
    "1265635127": "1st Half Goal Line (3-2)",
    "1265635128": "1st Half Goal Line (3-2)",
    "1265635129": "Asian Handicap (7-0)",
    "1265635130": "Goal Line (7-0)",
    "1265635131": "Alternative Asian Handicap (4-3)",
    "1265635132": "Alternative Goal Line (4-3)",
    "1265635133": "Asian Handicap (7-1)",
    "1265635134": "Goal Line (7-1)",
    "1265635135": "Asian Handicap (8-1)",
    "1265635136": "Goal Line (8-1)",
    "1265635137": "11th Goal",
    "1265635138": "11th Goal",
    "1265635139": "Asian Handicap (9-1)",
    "1265635140": "Goal Line (9-1)",
    "1265635141": "Alternative Asian Handicap (5-1)",
    "1265635142": "Alternative Goal Line (5-1)",
    "1265635143": "Asian Handicap (3-5)",
    "1265635144": "Asian Handicap (3-5)",
    "1265635145": "Goal Line (3-5)",
    "1265635146": "Away - 2nd Penalty",
    "1265635147": "Alternative Asian Handicap (7-0)",
    "1265635148": "Alternative Goal Line (7-0)",
    "1265635149": "Home - 2nd Penalty",
    "1265635150": "Home - 3rd Penalty",
    "1265635151": "Asian Handicap (8-0)",
    "1265635152": "Goal Line (8-0)",
    "1265635153": "Alternative Asian Handicap (5-3)",
    "1265635154": "Alternative Goal Line (5-3)",
    "1265635155": "Next Minute (10:00 - 10:59)",
    "1265635156": "Next Minute (10:00 - 10:59)",
    "1265635157": "Next Minute (12:00 - 12:59)",
    "1265635158": "Next Minute (11:00 - 11:59)",
    "1265635159": "Next Minute (13:00 - 13:59)",
    "1265635160": "Next Minute (14:00 - 14:59)",
    "1265635161": "Next Minute (15:00 - 15:59)",
    "1265635162": "Next Minute (16:00 - 16:59)",
    "1265635163": "Next Minute (17:00 - 17:59)",
    "1265635164": "Next Minute (18:00 - 18:59)",
    "1265635165": "Next Minute (19:00 - 19:59)",
    "1265635166": "Next Minute (20:00 - 20:59)",
    "1265635167": "Next Minute (21:00 - 21:59)",
    "1265635168": "Next Minute (22:00 - 22:59)",
    "1265635169": "Next Minute (23:00 - 23:59)",
    "1265635170": "Next Minute (24:00 - 24:59)",
    "1265635171": "Next Minute (25:00 - 25:59)",
    "1265635172": "Next Minute (26:00 - 26:59)",
    "1265635173": "Next Minute (27:00 - 27:59)",
    "1265635174": "Next Minute (28:00 - 28:59)",
    "1265635175": "Next Minute (29:00 - 29:59)",
    "1265635176": "Next Minute (30:00 - 30:59)",
    "1265635177": "Next Minute (30:00 - 30:59)",
    "1265635178": "Next Minute (31:00 - 31:59)",
    "1265635179": "Next Minute (32:00 - 32:59)",
    "1265635180": "Next Minute (33:00 - 33:59)",
    "1265635181": "Next Minute (34:00 - 34:59)",
    "1265635182": "Next Minute (35:00 - 35:59)",
    "1265635183": "Next Minute (35:00 - 35:59)",
    "1265635184": "Next Minute (36:00 - 36:59)",
    "1265635185": "Next Minute (37:00 - 37:59)",
    "1265635186": "Next Minute (38:00 - 38:59)",
    "1265635187": "Next Minute (39:00 - 39:59)",
    "1265635188": "Next Minute (40:00 - 40:59)",
    "1265635189": "Next Minute (41:00 - 41:59)",
    "1265635190": "Next Minute (42:00 - 42:59)",
    "1265635191": "Next Minute (43:00 - 43:59)",
    "1265635192": "Next Minute (44:00 - 44:59)",
    "1265635193": "Next Minute (45:00 - 45:59)",
    "1265635194": "Next Minute (46:00 - 46:59)",
    "1265635195": "Next Minute (47:00 - 47:59)",
    "1265635196": "Next Minute (48:00 - 48:59)",
    "1265635197": "Next Minute (49:00 - 49:59)",
    "1265635198": "Next Minute (50:00 - 50:59)",
    "1265635199": "Next Minute (51:00 - 51:59)",
    "1265635200": "Next Minute (52:00 - 52:59)",
    "1265635201": "Next Minute (53:00 - 53:59)",
    "1265635202": "Next Minute (54:00 - 54:59)",
    "1265635203": "Next Minute (55:00 - 55:59)",
    "1265635204": "Next Minute (56:00 - 56:59)",
    "1265635205": "Next Minute (57:00 - 57:59)",
    "1265635206": "Next Minute (58:00 - 58:59)",
    "1265635207": "Next Minute (59:00 - 59:59)",
    "1265635208": "Next Minute (60:00 - 60:59)",
    "1265635209": "Next Minute (61:00 - 61:59)",
    "1265635210": "Next Minute (62:00 - 62:59)",
    "1265635211": "Next Minute (63:00 - 63:59)",
    "1265635212": "Next Minute (64:00 - 64:59)",
    "1265635213": "Next Minute (65:00 - 65:59)",
    "1265635214": "Next Minute (66:00 - 66:59)",
    "1265635215": "Next Minute (67:00 - 67:59)",
    "1265635216": "Next Minute (68:00 - 68:59)",
    "1265635217": "Next Minute (69:00 - 69:59)",
    "1265635218": "Next Minute (70:00 - 70:59)",
    "1265635219": "Next Minute (71:00 - 71:59)",
    "1265635220": "Next Minute (72:00 - 72:59)",
    "1265635221": "Next Minute (73:00 - 73:59)",
    "1265635222": "Next Minute (73:00 - 73:59)",
    "1265635223": "Next Minute (74:00 - 74:59)",
    "1265635224": "Next Minute (75:00 - 75:59)",
    "1265635225": "Next Minute (75:00 - 75:59)",
    "1265635226": "Next Minute (76:00 - 76:59)",
    "1265635227": "Next Minute (77:00 - 77:59)",
    "1265635228": "Next Minute (78:00 - 78:59)",
    "1265635229": "Next Minute (79:00 - 79:59)",
    "1265635230": "Asian Handicap - Penalties converted in Shootout (3-0)",
    "1265635231": "Goal Line - Penalties converted in shootout (3-0)",
    "1265635232": "1st Half Asian Handicap (5-1)",
    "1265635233": "1st Half Goal Line (5-1)",
    "1265635234": "6th Goal Method",
    "1265635235": "7th Goal Method",
    "1265635236": "Next Minute (00:00 - 00:59)",
    "1265635237": "Next Set Piece 00:00 - 04:59",
    "1265635238": "Ten Minute Goal Kicks - 00:00 - 09:59",
    "1265635239": "Ten Minute Free Kicks - 00:00 - 09:59",
    "1265635240": "Ten Minute Throws - 00:00 - 09:59",
    "1265635241": "Next Minute (01:00 - 01:59)",
    "1265635242": "Next Set Piece 01:00 - 05:59",
    "1265635243": "Ten Minute Goal Kicks - 10:00 - 19:59",
    "1265635244": "Ten Minute Free Kicks - 10:00 - 19:59",
    "1265635245": "Ten Minute Throws - 10:00 - 19:59",
    "1265635246": "Next Minute (02:00 - 02:59)",
    "1265635247": "Next Set Piece 02:00 - 06:59",
    "1265635248": "Next Minute (03:00 - 03:59)",
    "1265635249": "Next Set Piece 03:00 - 07:59",
    "1265635250": "Next Minute (04:00 - 04:59)",
    "1265635251": "Next Set Piece 04:00 - 08:59",
    "1265635252": "Next Minute (05:00 - 05:59)",
    "1265635253": "Next Set Piece 05:00 - 09:59",
    "1265635254": "Next Minute (06:00 - 06:59)",
    "1265635255": "Next Set Piece 06:00 - 10:59",
    "1265635256": "Next Minute (07:00 - 07:59)",
    "1265635257": "Next Set Piece 07:00 - 11:59",
    "1265635258": "Next Minute (08:00 - 08:59)",
    "1265635259": "Next Set Piece 08:00 - 12:59",
    "1265635260": "Next Minute (09:00 - 09:59)",
    "1265635261": "Next Set Piece 09:00 - 13:59",
    "1265635262": "Next Set Piece 10:00 - 14:59",
    "1265635263": "Next Set Piece 11:00 - 15:59",
    "1265635264": "Ten Minute Goal Kicks - 20:00 - 29:59",
    "1265635265": "Ten Minute Free Kicks - 20:00 - 29:59",
    "1265635266": "Ten Minute Throws - 20:00 - 29:59",
    "1265635267": "Next Set Piece 12:00 - 16:59",
    "1265635268": "Next Set Piece 12:00 - 16:59",
    "1265635269": "Next Set Piece 13:00 - 17:59",
    "1265635270": "Next Set Piece 14:00 - 18:59",
    "1265635271": "Next Set Piece 15:00 - 19:59",
    "1265635272": "Next Set Piece 16:00 - 20:59",
    "1265635273": "Next Set Piece 17:00 - 21:59",
    "1265635274": "Next Set Piece 18:00 - 22:59",
    "1265635275": "Next Set Piece 19:00 - 23:59",
    "1265635276": "Next Set Piece 20:00 - 24:59",
    "1265635277": "Next Set Piece 21:00 - 25:59",
    "1265635278": "Ten Minute Goal Kicks - 30:00 - 39:59",
    "1265635279": "Ten Minute Free Kicks - 30:00 - 39:59",
    "1265635280": "Ten Minute Throws - 30:00 - 39:59",
    "1265635281": "Next Set Piece 22:00 - 26:59",
    "1265635282": "Next Set Piece 23:00 - 27:59",
    "1265635283": "Next Set Piece 24:00 - 28:59",
    "1265635284": "Next Set Piece 25:00 - 29:59",
    "1265635285": "Next Set Piece 26:00 - 30:59",
    "1265635286": "Next Set Piece 27:00 - 31:59",
    "1265635287": "Next Set Piece 28:00 - 32:59",
    "1265635288": "Next Set Piece 29:00 - 33:59",
    "1265635289": "Next Set Piece 30:00 - 34:59",
    "1265635290": "Next Set Piece 31:00 - 35:59",
    "1265635291": "Ten Minute Goal Kicks - 40:00 - 49:59",
    "1265635292": "Ten Minute Free Kicks - 40:00 - 49:59",
    "1265635293": "Ten Minute Throws - 40:00 - 49:59",
    "1265635294": "Alternative Asian Handicap (6-1)",
    "1265635295": "Alternative Goal Line (6-1)",
    "1265635296": "Next Set Piece 32:00 - 36:59",
    "1265635297": "Next Set Piece 33:00 - 37:59",
    "1265635298": "Next Set Piece 34:00 - 38:59",
    "1265635299": "Next Set Piece 35:00 - 39:59",
    "1265635300": "Next Set Piece 36:00 - 40:59",
    "1265635301": "Next Set Piece 37:00 - 41:59",
    "1265635302": "Next Set Piece 38:00 - 42:59",
    "1265635303": "Next Set Piece 39:00 - 43:59",
    "1265635304": "Next Set Piece 40:00 - 44:59",
    "1265635305": "Ten Minute Goal Kicks - 50:00 - 59:59",
    "1265635306": "Ten Minute Free Kicks - 50:00 - 59:59",
    "1265635307": "Ten Minute Throws - 50:00 - 59:59",
    "1265635308": "Next Set Piece 45:00 - 49:59",
    "1265635309": "Next Set Piece 46:00 - 50:59",
    "1265635310": "Next Set Piece 47:00 - 51:59",
    "1265635311": "Next Set Piece 48:00 - 52:59",
    "1265635312": "Next Set Piece 49:00 - 53:59",
    "1265635313": "Next Set Piece 50:00 - 54:59",
    "1265635314": "Next Set Piece 51:00 - 55:59",
    "1265635315": "Ten Minute Goal Kicks - 60:00 - 69:59",
    "1265635316": "Ten Minute Free Kicks - 60:00 - 69:59",
    "1265635317": "Ten Minute Throws - 60:00 - 69:59",
    "1265635318": "Next Set Piece 52:00 - 56:59",
    "1265635319": "Next Set Piece 53:00 - 57:59",
    "1265635320": "Next Set Piece 54:00 - 58:59",
    "1265635321": "Next Set Piece 55:00 - 59:59",
    "1265635322": "Next Set Piece 56:00 - 60:59",
    "1265635323": "Next Set Piece 57:00 - 61:59",
    "1265635324": "Next Set Piece 58:00 - 62:59",
    "1265635325": "Next Set Piece 59:00 - 63:59",
    "1265635326": "Next Set Piece 60:00 - 64:59",
    "1265635327": "Next Set Piece 61:00 - 65:59",
    "1265635328": "Ten Minute Goal Kicks - 70:00 - 79:59",
    "1265635329": "Ten Minute Free Kicks - 70:00 - 79:59",
    "1265635330": "Ten Minute Throws - 70:00 - 79:59",
    "1265635331": "Next Set Piece 62:00 - 66:59",
    "1265635332": "Next Set Piece 63:00 - 67:59",
    "1265635333": "Next Set Piece 64:00 - 68:59",
    "1265635334": "Next Set Piece 65:00 - 69:59",
    "1265635335": "Next Set Piece 66:00 - 70:59",
    "1265635336": "Next Set Piece 67:00 - 71:59",
    "1265635337": "Next Set Piece 68:00 - 72:59",
    "1265635338": "Next Set Piece 69:00 - 73:59",
    "1265635339": "Next Set Piece 70:00 - 74:59",
    "1265635340": "Next Set Piece 71:00 - 75:59",
    "1265635341": "Next Set Piece 72:00 - 76:59",
    "1265635342": "Next Set Piece 73:00 - 77:59",
    "1265635343": "Next Set Piece 74:00 - 78:59",
    "1265635344": "Next Set Piece 75:00 - 79:59",
    "1265635345": "Next Set Piece 76:00 - 80:59",
    "1265635346": "Next Set Piece 77:00 - 81:59",
    "1265635347": "Next Set Piece 78:00 - 82:59",
    "1265635348": "Next Set Piece 79:00 - 83:59",
    "1265635349": "Next Set Piece 80:00 - 84:59",
    "1265635350": "Next Minute (81:00 - 81:59)",
    "1265635351": "Next Set Piece 81:00 - 85:59",
    "1265635352": "Next Minute (82:00 - 82:59)",
    "1265635353": "Next Set Piece 82:00 - 86:59",
    "1265635354": "Next Minute (83:00 - 83:59)",
    "1265635355": "Next Set Piece 83:00 - 87:59",
    "1265635356": "Next Minute (84:00 - 84:59)",
    "1265635357": "Next Set Piece 84:00 - 88:59",
    "1265635358": "Next Minute (85:00 - 85:59)",
    "1265635359": "Next Minute (86:00 - 86:59)",
    "1265635360": "Next Minute (87:00 - 87:59)",
    "1265635361": "Next Minute (88:00 - 88:59)",
    "1265635362": "Extra Time Asian Handicap (0-1)",
    "1265635363": "Extra Time Goal Line (0-1)",
    "1265635364": "3rd Goal - Extra Time",
    "1265635365": "Extra Time Asian Handicap (1-1)",
    "1265635366": "Extra Time Goal Line (1-1)",
    "1265635367": "Asian Handicap - Penalties converted in Shootout (1-3)",
    "1265635368": "Goal Line - Penalties converted in shootout (1-3)",
    "1265635369": "Asian Handicap - Penalties converted in Shootout (2-4)",
    "1265635370": "Goal Line - Penalties converted in shootout (2-4)",
    "1265635371": "19th Corner",
    "1265635372": "20th Corner",
    "1265635373": "20th Corner",
    "1265635374": "21st Corner",
    "1265635375": "21st Corner",
    "1265635376": "22nd Corner",
    "1265635377": "23rd Corner",
    "1265635378": "Asian Handicap (0-8)",
    "1265635379": "Goal Line (0-8)",
    "1265635380": "Asian Handicap (0-9)",
    "1265635381": "Goal Line (0-9)",
    "1265635382": "Asian Handicap (0-10)",
    "1265635383": "Goal Line (0-10)",
    "1265635384": "12th Goal",
    "1265635385": "Asian Handicap (0-11)",
    "1265635386": "Goal Line (0-11)",
    "1265635387": "13th Goal",
    "1265635388": "Asian Handicap (0-12)",
    "1265635389": "Goal Line (0-12)",
    "1265635390": "1st Half Asian Handicap (3-3)",
    "1265635391": "1st Half Goal Line (3-3)",
    "1265635392": "14th Goal",
    "1265635393": "Asian Handicap (0-13)",
    "1265635394": "Goal Line (0-13)",
    "1265635395": "1st Half Asian Handicap (4-3)",
    "1265635396": "1st Half Goal Line (4-3)",
    "1265635397": "Asian Handicap (9-0)",
    "1265635398": "Goal Line (9-0)",
    "1265635399": "Alternative Asian Handicap (6-3)",
    "1265635400": "Alternative Asian Handicap (6-3)",
    "1265635401": "Alternative Goal Line (6-3)",
    "1265635402": "Asian Handicap (6-4)",
    "1265635403": "Asian Handicap (6-4)",
    "1265635404": "Alternative Asian Handicap (6-4)",
    "1265635405": "Goal Line (6-4)",
    "1265635406": "Alternative Goal Line (6-4)",
    "1265635407": "Alternative Goal Line (6-4)",
    "1265635408": "Asian Handicap (6-5)",
    "1265635409": "Alternative Asian Handicap (6-5)",
    "1265635410": "Goal Line (6-5)",
    "1265635411": "Alternative Goal Line (6-5)",
    "1265635412": "Asian Handicap (7-5)",
    "1265635413": "Alternative Asian Handicap (7-5)",
    "1265635414": "Goal Line (7-5)",
    "1265635415": "Alternative Goal Line (7-5)",
    "1265635416": "Asian Handicap (8-5)",
    "1265635417": "Alternative Asian Handicap (8-5)",
    "1265635418": "Goal Line (8-5)",
    "1265635419": "Alternative Goal Line (8-5)",
    "1265635420": "15th Goal",
    "1265635421": "Asian Handicap (8-6)",
    "1265635422": "Asian Handicap (8-6)",
    "1265635423": "Goal Line (8-6)",
    "1265635424": "Asian Handicap (4-5)",
    "1265635425": "Goal Line (4-5)",
    "1265635426": "Asian Handicap (5-5)",
    "1265635427": "Asian Handicap (5-5)",
    "1265635428": "Goal Line (5-5)",
    "1265635429": "Extra Time Goal Line (1-0)",
    "1265635430": "1st Half Asian Handicap (1-4)",
    "1265635431": "1st Half Asian Handicap (1-4)",
    "1265635432": "1st Half Goal Line (1-4)",
    "1265635433": "1st Half Goal Line (1-4)",
    "1265635434": "Next Minute (89:00 - 89:59)",
    "1265635435": "1st Half Asian Handicap (2-4)",
    "1265635436": "1st Half Goal Line (2-4)",
    "1265635437": "Asian Handicap (1-7)",
    "1265635438": "Goal Line (1-7)",
    "1265635439": "Asian Handicap (1-8)",
    "1265635440": "Asian Handicap (1-8)",
    "1265635441": "Goal Line (1-8)",
    "1265635442": "Asian Handicap (1-9)",
    "1265635443": "Goal Line (1-9)",
    "1265635444": "Asian Handicap (1-10)",
    "1265635445": "Asian Handicap (1-10)",
    "1265635446": "Goal Line (1-10)",
    "1265635447": "Asian Handicap (4-6)",
    "1265635448": "Goal Line (4-6)",
    "1265635449": "Asian Handicap (4-7)",
    "1265635450": "Goal Line (4-7)",
    "1265635451": "Asian Handicap - Penalties converted in Shootout (5-4)",
    "1265635452": "Goal Line - Penalties converted in shootout (5-4)",
    "1265635453": "Asian Handicap - Penalties converted in Shootout (6-5)",
    "1265635454": "Goal Line - Penalties converted in shootout (6-5)",
    "1265635455": "Asian Handicap - Penalties converted in Shootout (7-6)",
    "1265635456": "Goal Line - Penalties converted in shootout (7-6)",
    "1265635457": "8th Goal Method",
    "1265635458": "8th Goal Method",
    "1265635459": "Alternative Asian Handicap (1-6)",
    "1265635460": "Alternative Goal Line (1-6)",
    "1265635461": "Alternative Asian Handicap (3-5)",
    "1265635462": "Alternative Goal Line (3-5)",
    "1265635463": "Time of 7th Goal - Away",
    "1265635464": "Alternative Asian Handicap (8-0)",
    "1265635465": "Alternative Goal Line (8-0)",
    "1265635466": "Time of 9th Goal - Away",
    "1265635467": "Alternative Asian Handicap (9-0)",
    "1265635468": "Alternative Goal Line (9-0)",
    "1265635469": "1st Half Asian Handicap (0-5)",
    "1265635470": "1st Half Goal Line (0-5)",
    "1265635471": "1st Half Asian Handicap (0-6)",
    "1265635472": "1st Half Goal Line (0-6)",
    "1265635473": "Alternative Asian Handicap (0-6)",
    "1265635474": "Alternative Goal Line (0-6)",
    "1265635475": "Asian Handicap (7-3)",
    "1265635476": "Alternative Asian Handicap (7-3)",
    "1265635477": "Goal Line (7-3)",
    "1265635478": "Alternative Goal Line (7-3)",
    "1265635479": "Asian Handicap (8-3)",
    "1265635480": "Alternative Asian Handicap (8-3)",
    "1265635481": "Goal Line (8-3)",
    "1265635482": "Alternative Goal Line (8-3)",
    "1265635483": "Asian Handicap (8-4)",
    "1265635484": "Goal Line (8-4)",
    "1265635485": "Asian Handicap (3-6)",
    "1265635486": "Goal Line (3-6)",
    "1265635487": "Asian Handicap - Penalties converted in Shootout (0-2)",
    "1265635488": "Goal Line - Penalties converted in shootout (0-2)",
    "1265635489": "Asian Handicap - Penalties converted in Shootout (0-3)",
    "1265635490": "Goal Line - Penalties converted in shootout (0-3)",
    "1265635491": "Asian Handicap (7-2)",
    "1265635492": "Goal Line (7-2)",
    "1265635493": "Extra Time Goalscorers",
    "1265635494": "Extra Time Asian Handicap (0-2)",
    "1265635495": "Extra Time Goal Line (0-2)",
    "1265635496": "4th Goal - Extra Time",
    "1265635497": "Asian Handicap (3-7)",
    "1265635498": "Goal Line (3-7)",
    "1265635499": "Alternative Asian Handicap (7-1)",
    "1265635500": "Alternative Goal Line (7-1)",
    "1265635501": "Alternative Asian Handicap (8-1)",
    "1265635502": "Alternative Goal Line (8-1)",
    "1265635503": "Alternative Goal Line (8-1)",
    "1265635504": "Alternative Asian Handicap (9-1)",
    "1265635505": "Alternative Asian Handicap (9-1)",
    "1265635506": "Alternative Goal Line (9-1)",
    "1265635507": "1st Half Asian Handicap (6-0)",
    "1265635508": "1st Half Asian Handicap (6-0)",
    "1265635509": "1st Half Goal Line (6-0)",
    "1265635510": "1st Half Goal Line (6-0)",
    "1265635511": "1st Half Asian Handicap (7-0)",
    "1265635512": "1st Half Goal Line (7-0)",
    "1265635513": "1st Half Asian Handicap (8-0)",
    "1265635514": "1st Half Goal Line (8-0)",
    "1265635515": "Asian Handicap (10-0)",
    "1265635516": "Goal Line (10-0)",
    "1265635517": "Asian Handicap (11-0)",
    "1265635518": "Asian Handicap (11-0)",
    "1265635519": "Goal Line (11-0)",
    "1265635520": "Goal Line (11-0)",
    "1265635521": "Asian Handicap (12-0)",
    "1265635522": "Goal Line (12-0)",
    "1265635523": "Goal Line (12-0)",
    "1265635524": "Alternative Asian Handicap (3-6)",
    "1265635525": "Alternative Goal Line (3-6)",
    "1265635526": "1st Half Asian Handicap (1-5)",
    "1265635527": "1st Half Goal Line (1-5)",
    "1265635528": "1st Half Asian Handicap (1-6)",
    "1265635529": "1st Half Goal Line (1-6)",
    "1265635530": "Asian Handicap (5-4)",
    "1265635531": "Asian Handicap (5-4)",
    "1265635532": "Alternative Asian Handicap (5-4)",
    "1265635533": "Goal Line (5-4)",
    "1265635534": "Goal Line (5-4)",
    "1265635535": "Alternative Goal Line (5-4)",
    "1265635536": "Alternative Goal Line (5-4)",
    "1265635537": "Alternative Goal Line (5-4)",
    "1265635538": "Alternative Asian Handicap (1-7)",
    "1265635539": "Alternative Goal Line (1-7)",
    "1265635540": "Alternative Asian Handicap (1-8)",
    "1265635541": "Alternative Goal Line (1-8)",
    "1265635542": "Time of 10th Goal",
    "1265635543": "Alternative Asian Handicap (1-9)",
    "1265635544": "Alternative Goal Line (1-9)",
    "1265635545": "Time of 11th Goal",
    "1265635546": "Alternative Asian Handicap (10-0)",
    "1265635547": "Alternative Asian Handicap (10-0)",
    "1265635548": "Alternative Goal Line (10-0)",
    "1265635549": "Alternative Asian Handicap (7-2)",
    "1265635550": "Alternative Goal Line (7-2)",
    "1265635551": "Asian Handicap (8-2)",
    "1265635552": "Alternative Asian Handicap (8-2)",
    "1265635553": "Goal Line (8-2)",
    "1265635554": "Alternative Goal Line (8-2)",
    "1265635555": "Alternative Asian Handicap (4-5)",
    "1265635556": "Alternative Goal Line (4-5)",
    "1265635557": "Alternative Asian Handicap (4-6)",
    "1265635558": "Alternative Goal Line (4-6)",
    "1265635559": "Extra Time Asian Handicap (2-0)",
    "1265635560": "Asian Handicap (2-8)",
    "1265635561": "Goal Line (2-8)",
    "1265635562": "24th Corner",
    "1265635563": "25th Corner",
    "1265635564": "Asian Handicap (5-6)",
    "1265635565": "Asian Handicap (5-6)",
    "1265635566": "Goal Line (5-6)",
    "1265635567": "Asian Handicap (9-2)",
    "1265635568": "Alternative Asian Handicap (9-2)",
    "1265635569": "Goal Line (9-2)",
    "1265635570": "Alternative Goal Line (9-2)",
    "1265635571": "Asian Handicap (10-2)",
    "1265635572": "Alternative Asian Handicap (10-2)",
    "1265635573": "Goal Line (10-2)",
    "1265635574": "Alternative Goal Line (10-2)",
    "1265635575": "Asian Handicap (11-2)",
    "1265635576": "Asian Handicap (11-2)",
    "1265635577": "Alternative Asian Handicap (11-2)",
    "1265635578": "Alternative Asian Handicap (11-2)",
    "1265635579": "Goal Line (11-2)",
    "1265635580": "Alternative Goal Line (11-2)",
    "1265635581": "Alternative Asian Handicap (0-7)",
    "1265635582": "Alternative Goal Line (0-7)",
    "1265635583": "Away - 3rd Penalty",
    "1265635584": "Alternative Asian Handicap (0-8)",
    "1265635585": "Alternative Goal Line (0-8)",
    "1265635586": "Extra Time Asian Handicap (1-2)",
    "1265635587": "Time of 1st Goal - Home",
    "1265635588": "Time of 2nd Goal - Home",
    "1265635589": "Time of 3rd Goal - Home",
    "1265635590": "Time of 4th Goal - Home",
    "1265635591": "Time of 5th Goal - Home",
    "1265635592": "Time of 6th Goal - Home",
    "1265635593": "Extra Time Asian Handicap (2-1)",
    "1265635594": "Extra Time Goal Line (2-1)",
    "1265635595": "Extra Time Asian Handicap (3-0)",
    "1265635596": "Extra Time Goal Line (2-0)",
    "1265635597": "Extra Time Goal Line (3-0)",
    "1265635598": "Time of 7th Goal - Home",
    "1265635599": "Aarhus Homead Exact Goals",
    "1265635600": "Aarhus Homead Goals",
    "1265635601": "Asian Handicap (12-1)",
    "1265635602": "Asian Handicap (12-1)",
    "1265635603": "Goal Line (12-1)",
    "1265635604": "Match Corners",
    "1265635605": "Corners",
    "1265635606": "Next 10 Minutes (60:00 - 69:59)",
    "1265635607": "Shootout Correct Score",
    "1265635608": "Next 10 Minutes (30:00 - 39:59)",
    "1265635609": "Next 10 Minutes (40:00 - 49:59)",
    "1265635610": "Next 10 Minutes (70:00 - 79:59)",
    "1265635611": "Next 10 Minutes (00:00 - 09:59)",
    "1265635612": "Next 10 Minutes (50:00 - 59:59)",
    "1265635613": "Next 10 Minutes (80:00 - End)",
    "1265635614": "Next 10 Minutes (10:00 - 19:59)",
    "1265635615": "Next 10 Minutes (20:00 - 29:59)",
    "1265635616": "Asian Handicap - Penalties converted in Shootout (7-7)",
    "1265635617": "Goal Line - Penalties Converted in Shootout (7-7)",
    "1265635618": "Asian Handicap - Penalties converted in Shootout (7-8)",
    "1265635619": "Goal Line - Penalties Converted in Shootout (7-8)",
    "1265635620": "Asian Handicap - Penalties converted in Shootout (8-8)",
    "1265635621": "Goal Line - Penalties Converted in Shootout (8-8)",
    "1265635622": "Asian Handicap - Penalties converted in Shootout (8-9)",
    "1265635623": "Goal Line - Penalties Converted in Shootout (8-9)",
    "1265635624": "Asian Handicap - Penalties converted in Shootout (9-9)",
    "1265635625": "Goal Line - Penalties Converted in Shootout (9-9)",
    "1265635626": "Asian Handicap - Penalties converted in Shootout (9-10)",
    "1265635627": "Goal Line - Penalties Converted in Shootout (9-10)",
    "1265635628": "Asian Handicap - Penalties converted in Shootout (10-10)",
    "1265635629": "Goal Line - Penalties Converted in Shootout (10-10)",
    "1265635630": "Asian Handicap - Penalties converted in Shootout (10-11)",
    "1265635631": "Goal Line - Penalties Converted in Shootout (10-11)",
    "1265635632": "Home - 4th Penalty",
    "1265635633": "Asian Handicap (13-0)",
    "1265635634": "Goal Line (13-0)",
    "1265635635": "Asian Handicap (14-0)",
    "1265635636": "Goal Line (14-0)",
    "1265635637": "16th  Goal",
    "1265635638": "Asian Handicap (15-0)",
    "1265635639": "Goal Line (15-0)",
    "1265635640": "17th Goal",
    "1265635641": "Asian Handicap (16-0)",
    "1265635642": "Goal Line (16-0)",
    "1265635643": "18th Goal",
    "1265635644": "Asian Handicap (17-0)",
    "1265635645": "Goal Line (17-0)",
    "1265635646": "19th Goal",
    "1265635647": "Al-Ahli Home Exact Goals",
    "1265635648": "Al-Ahli Home Goals",
    "1265635649": "1st Half Asian Handicap (3-4)",
    "1265635650": "1st Half Goal Line (3-4)",
    "1265635651": "1st Half Asian Handicap (6-1)",
    "1265635652": "1st Half Goal Line (6-1)",
    "1265635653": "Asian Handicap (10-1)",
    "1265635654": "Asian Handicap (10-1)",
    "1265635655": "Goal Line (10-1)",
    "1265635656": "Asian Handicap (7-4)",
    "1265635657": "Goal Line (7-4)",
    "1265635658": "1st Half Asian Handicap (0-7)",
    "1265635659": "1st Half Goal Line (0-7)",
    "1265635660": "5th Goal - Extra Time",
    "1265635661": "Time of 8th Goal - Home",
    "1265635662": "Time of 9th Goal - Home",
    "1265635663": "Extra Time Asian Handicap (4-0)",
    "1265635664": "Extra Time Goal Line (4-0)",
    "1265635665": "6th Goal - Extra Time",
    "1265635666": "Extra Time Asian Handicap (5-0)",
    "1265635667": "Extra Time Goal Line (5-0)",
    "1265635668": "9th Goal Method",
    "1265635669": "10th Goal Method",
    "1265635670": "10th Goal Method",
    "1265635671": "Away - 4th Penalty",
    "1265635672": "Asian Handicap - Penalties converted in Shootout (8-7)",
    "1265635673": "Goal Line - Penalties Converted in Shootout (8-7)",
    "1265635674": "Asian Handicap - Penalties converted in Shootout (9-8)",
    "1265635675": "Goal Line - Penalties Converted in Shootout (9-8)",
    "1265635676": "Asian Handicap - Penalties converted in Shootout (10-9)",
    "1265635677": "Goal Line - Penalties Converted in Shootout (10-9)",
    "1265635678": "1st Half Asian Handicap (7-1)",
    "1265635679": "1st Half Goal Line (7-1)",
    "1265635680": "Extra Time Player to be Booked",
    "1265635681": "Player Passes",
    "1265635682": "Asian Handicap (2-10)",
    "1265635683": "Goal Line (2-10)",
    "1265635684": "Asian Handicap (2-11)",
    "1265635685": "Goal Line (2-11)",
    "1265635686": "Asian Handicap (2-12)",
    "1265635687": "Goal Line (2-12)",
    "1265635688": "Asian Handicap (2-13)",
    "1265635689": "Goal Line (2-13)",
    "1265635690": "Asian Handicap (2-14)",
    "1265635691": "Goal Line (2-14)",
    "1265635692": "Home United Exact Goals",
    "1265635693": "Home United Goals",
    "1265635694": "Home United - 1st Penalty",
    "1265635695": "1st Half 1st Goal",
    "1265635696": "Extra Time Goal Line (1-2)",
    "1265635697": "Exact Match Goals",
    "1265635698": "Exact 2nd Half Goals",
    "1265635699": "Next Goal",
    "1265635700": "Asian Handicap ([SCORE])",
    "1265635701": "Goal Line ([SCORE])",
    "1265635702": "Asian Handicap - Penalties converted in Shootout (11-10)",
    "1265635703": "Goal Line - Penalties Converted in Shootout (11-10)",
    "1265635704": "Asian Handicap - Penalties converted in Shootout (11-11)",
    "1265635705": "Goal Line - Penalties Converted in Shootout (11-11)",
    "1265635706": "Asian Handicap - Penalties converted in Shootout (12-11)",
    "1265635707": "Goal Line - Penalties Converted in Shootout (12-11)",
    "1265635708": "Asian Handicap - Penalties converted in Shootout (12-12)",
    "1265635709": "Goal Line - Penalties Converted in Shootout (12-12)",
    "1265635710": "Asian Handicap - Penalties converted in Shootout (13-12)",
    "1265635711": "Goal Line - Penalties Converted in Shootout (13-12)",
    "1265635712": "Asian Handicap - Penalties converted in Shootout (13-13)",
    "1265635713": "Goal Line - Penalties Converted in Shootout (13-13)",
    "1265635714": "Asian Handicap - Penalties converted in Shootout (14-13)",
    "1265635715": "Goal Line - Penalties Converted in Shootout (14-13)",
    "1265635716": "Asian Handicap - Penalties converted in Shootout (14-14)",
    "1265635717": "Goal Line - Penalties Converted in Shootout (14-14)",
    "1265635718": "1st Half Asian Handicap (4-4)",
    "1265635719": "1st Half Goal Line (4-4)",
    "1265635720": "Extra Time Asian Handicap (2-2)",
    "1265635721": "Extra Time Goal Line (2-2)",
    "1265635722": "Asian Handicap - Penalties converted in Shootout (15-14)",
    "1265635723": "Goal Line - Penalties Converted in Shootout (15-14)",
    "1265635724": "Asian Handicap (1-12)",
    "1265635725": "Goal Line (1-12)",
    "1265635726": "Asian Handicap (1-11)",
    "1265635727": "Goal Line (1-11)",
    "1265635728": "Time of 10th Goal - Away",
    "1265635729": "Time of 11th Goal - Away",
    "1265635730": "Time of 12th Goal",
    "1265635731": "Time of 12th Goal - Away",
    "1265635732": "Extra Time Asian Handicap (0-3)",
    "1265635733": "Extra Time Goal Line (0-3)",
    "1265635734": "Extra Time Asian Handicap (0-4)",
    "1265635735": "Extra Time Goal Line (0-4)",
    "1265635736": "1st Half Asian Handicap (5-2)",
    "1265635737": "1st Half Goal Line (5-2)",
    "1265635738": "Asian Handicap (7-6)",
    "1265635739": "Goal Line (7-6)",
    "1265635740": "Extra Time Asian Handicap (1-3)",
    "1265635741": "Extra Time Goal Line (1-3)",
    "1265635742": "Extra Time Asian Handicap (3-1)",
    "1265635743": "Extra Time Goal Line (3-1)",
    "1265635744": "Extra Time Asian Handicap (4-1)",
    "1265635745": "Extra Time Goal Line (4-1)",
    "1265635746": "3rd Goalscorer ",
    "1265635747": "Asian Handicap (13-1)",
    "1265635748": "Goal Line (13-1)",
    "1265635749": "Asian Handicap (3-8)",
    "1265635750": "Goal Line (3-8)",
    "1265635751": "Mumbai City Homels",
    "1265635752": "Mumbai City Homels",
    "1265635753": "Al Shabab Home Exact Goals",
    "1265635754": "Al Shabab Home Exact Goals",
    "1265635755": "Al Shabab Home Goals",
    "1265635756": "Al Shabab Home Goals",
    "1265635757": "Al Shabab Home Penalty Shootout",
    "1265635758": "Al Shabab Home Penalties Converted in Shootout",
    "1265635759": "Torre Home Exact Goals",
    "1265635760": "Torre Home Goals",
    "1265635761": "Chennaiyin Homels",
    "1265635762": "1st Half Asian Handicap (2-5)",
    "1265635763": "1st Half Goal Line (2-5)",
    "1265635764": "Jamshedpur Homels",
    "1265635765": "Young Home Exact Goals",
    "1265635766": "Young Home Goals",
    "1265635767": "7th Goal - Extra Time",
    "1265635768": "8th Goal - Extra Time",
    "1265635769": "1st Player Booked",
    "1265635770": "Al-Najma Home Exact Goals",
    "1265635771": "Al-Najma Home Goals",
    "1265635772": "Asian Handicap (1-13)",
    "1265635773": "Goal Line (1-13)",
    "1265635774": "Asian Handicap (1-14)",
    "1265635775": "Goal Line (1-14)",
    "1265635776": "Number of Goals in Match",
    "1265635777": "Odisha Homels",
    "1265635778": "Asian Handicap (11-1)",
    "1265635779": "Goal Line (11-1)",
    "1265635780": "Hyderabad Homels",
    "1265635781": "Time of 10th Goal - Home",
    "1265635782": "Asian Handicap (9-3)",
    "1265635783": "Goal Line (9-3)",
    "1265635784": "Asian Handicap (10-3)",
    "1265635785": "Goal Line (10-3)",
    "1265635786": "Asian Handicap - Penalties converted in Shootout (11-12)",
    "1265635787": "Goal Line - Penalties Converted in Shootout (11-12)",
    "1265635788": "Asian Handicap - Penalties converted in Shootout (12-13)",
    "1265635789": "Goal Line - Penalties Converted in Shootout (12-13)",
    "1265635790": "Asian Handicap (2-9)",
    "1265635791": "Goal Line (2-9)",
    "1265635792": "Home Largo Exact Goals",
    "1265635793": "Home Largo Goals",
    "1265635794": "Time of 1st Goal - Home Largo",
    "1265635795": "Time of 2nd Goal - Home Largo",
    "1265635796": "Puertos Home Exact Goals",
    "1265635797": "Puertos Home Goals",
    "1265635798": "Cove Home Exact Goals",
    "1265635799": "Cove Home Goals",
    "1265635800": "Time of 1st Goal - Cove Home",
    "1265635801": "1st Half Asian Handicap (5-3)",
    "1265635802": "1st Half Goal Line (5-3)",
    "1265635803": "Asian Handicap (4-8)",
    "1265635804": "Goal Line (4-8)",
    "1265635805": "Athletico Homeense Exact Goals",
    "1265635806": "Athletico Homeense Goals",
    "1265635807": "Asian Handicap (0-14)",
    "1265635808": "Goal Line (0-14)",
    "1265635809": "Home Tårnby Exact Goals",
    "1265635810": "Home Tårnby Goals",
    "1265635811": "Asian Handicap (11-3)",
    "1265635812": "Goal Line (11-3)",
    "1265635813": "Asian Handicap (11-4)",
    "1265635814": "Goal Line (11-4)",
    "1265635815": "Team To Kick Off",
    "1265635816": "Time of 11th Goal - Home",
    "1265635817": "To Win Outright"
}

PRE_ODDS_MAP = {
    "home_win": {
        "key": "home_win",
        "description": "1X2 [Home Win]",
        "market": "3Way Result",
        "info": "1"
    },
    "draw": {
        "key": "draw",
        "description": "1X2 [Draw]",
        "market": "3Way Result",
        "info": "X"
    },
    "away_win": {
        "key": "away_win",
        "description": "1X2 [Away Win]",
        "market": "3Way Result",
        "info": "2"
    },
    "home_win_ht": {
        "key": "home_win_ht",
        "description": "Half Time Result [Home Win]",
        "market": "3Way Result 1st Half",
        "info": "1"
    },
    "draw_ht": {
        "key": "draw_ht",
        "description": "Half Time Result [Draw]",
        "market": "3Way Result 1st Half",
        "info": "X"
    },
    "away_win_ht": {
        "key": "away_win_ht",
        "description": "Half Time Result [Away Win]",
        "market": "3Way Result 1st Half",
        "info": "2"
    },
    "home_win_or_draw": {
        "key": "home_win_or_draw",
        "description": "Double Chance [Home Draw]",
        "market": "Double Chance",
        "info": "Home or Draw"
    },
    "away_win_or_draw": {
        "key": "away_win_or_draw",
        "description": "Double Chance [Draw Away]",
        "market": "Double Chance",
        "info": "Draw or Away"
    },
    "home_win_or_away_win": {
        "key": "home_win_or_away_win",
        "description": "Double Chance [Home Away]",
        "market": "Double Chance",
        "info": "Home or Away"
    },
    "dnb_home": {
        "key": "dnb_home",
        "description": "Draw No Bet [Home]",
        "market": "Draw No Bet",
        "info": "1"
    },
    "dnb_away": {
        "key": "dnb_away",
        "description": "Draw No Bet [Away]",
        "market": "Draw No Bet",
        "info": "2"
    },
    "o05_goals": {
        "key": "o05_goals",
        "description": "Match Goals Over 0.5",
        "market": "Total Goals",
        "info": "Over 0.5"
    },
    "u05_goals": {
        "key": "u05_goals",
        "description": "Match Goals Under 0.5",
        "market": "Total Goals",
        "info": "Under 0.5"
    },
    "o15_goals": {
        "key": "o15_goals",
        "description": "Match Goals Over 1.5",
        "market": "Total Goals",
        "info": "Over 1.5"
    },
    "u15_goals": {
        "key": "u15_goals",
        "description": "Match Goals Under 1.5",
        "market": "Total Goals",
        "info": "Under 1.5"
    },
    "o25_goals": {
        "key": "o25_goals",
        "description": "Match Goals Over 2.5",
        "market": "Total Goals",
        "info": "Over 2.5"
    },
    "u25_goals": {
        "key": "u25_goals",
        "description": "Match Goals Under 2.5",
        "market": "Total Goals",
        "info": "Under 2.5"
    },
    "o35_goals": {
        "key": "o35_goals",
        "description": "Match Goals Over 3.5",
        "market": "Total Goals",
        "info": "Over 3.5"
    },
    "u35_goals": {
        "key": "u35_goals",
        "description": "Match Goals Under 3.5",
        "market": "Total Goals",
        "info": "Under 3.5"
    },
    "o45_goals": {
        "key": "o45_goals",
        "description": "Match Goals Over 4.5",
        "market": "Total Goals",
        "info": "Over 4.5"
    },
    "u45_goals": {
        "key": "u45_goals",
        "description": "Match Goals Under 4.5",
        "market": "Total Goals",
        "info": "Under 4.5"
    },
    "o55_goals": {
        "key": "o55_goals",
        "description": "Match Goals Over 5.5",
        "market": "Total Goals",
        "info": "Over 5.5"
    },
    "u55_goals": {
        "key": "u55_goals",
        "description": "Match Goals Under 5.5",
        "market": "Total Goals",
        "info": "Under 5.5"
    },
    "o65_goals": {
        "key": "o65_goals",
        "description": "Match Goals Over 6.5",
        "market": "Total Goals",
        "info": "Over 6.5"
    },
    "u65_goals": {
        "key": "u65_goals",
        "description": "Match Goals Under 6.5",
        "market": "Total Goals",
        "info": "Under 6.5"
    },
    "o75_goals": {
        "key": "o75_goals",
        "description": "Match Goals Over 7.5",
        "market": "Total Goals",
        "info": "Over 7.5"
    },
    "u75_goals": {
        "key": "u75_goals",
        "description": "Match Goals Under 7.5",
        "market": "Total Goals",
        "info": "Under 7.5"
    },
    "o05_goals_1h": {
        "key": "o05_goals_1h",
        "description": "1st Half Goals Over 0.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over 0.5"
    },
    "u05_goals_1h": {
        "key": "u05_goals_1h",
        "description": "1st Half Goals Under 0.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under 0.5"
    },
    "o15_goals_1h": {
        "key": "o15_goals_1h",
        "description": "1st Half Goals Over 1.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over 1.5"
    },
    "u15_goals_1h": {
        "key": "u15_goals_1h",
        "description": "1st Half Goals Under 1.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under 1.5"
    },
    "o25_goals_1h": {
        "key": "o25_goals_1h",
        "description": "1st Half Goals Over 2.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over 2.5"
    },
    "u25_goals_1h": {
        "key": "u25_goals_1h",
        "description": "1st Half Goals Under 2.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under 2.5"
    },
    "o35_goals_1h": {
        "key": "o35_goals_1h",
        "description": "1st Half Goals Over 3.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over 3.5"
    },
    "u35_goals_1h": {
        "key": "u35_goals_1h",
        "description": "1st Half Goals Under 3.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under 3.5"
    },
    "o45_goals_1h": {
        "key": "o45_goals_1h",
        "description": "1st Half Goals Over 4.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over 4.5"
    },
    "u45_goals_1h": {
        "key": "u45_goals_1h",
        "description": "1st Half Goals Under 4.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under 4.5"
    },
    "o55_goals_1h": {
        "key": "o55_goals_1h",
        "description": "1st Half Goals Over 5.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over 5.5"
    },
    "u55_goals_1h": {
        "key": "u55_goals_1h",
        "description": "1st Half Goals Under 5.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under 5.5"
    },
    "btts": {
        "key": "btts",
        "description": "Both Teams to Score (Yes)",
        "market": "Both Teams To Score",
        "info": "Yes"
    },
    "btts_no": {
        "key": "btts_no",
        "description": "Both Teams to Score (No)",
        "market": "Both Teams To Score",
        "info": "No"
    },
    "btts_1h": {
        "key": "btts_1h",
        "description": "Both Teams to Score in 1st Half (Yes)",
        "market": "Both Teams To Score - 1st Half",
        "info": "Yes"
    },
    "btts_1h_no": {
        "key": "btts_1h_no",
        "description": "Both Teams to Score in 1st Half (No)",
        "market": "Both Teams To Score - 1st Half",
        "info": "No"
    },
    "btts_2h": {
        "key": "btts_2h",
        "description": "Both Teams to Score in 2nd Half (Yes)",
        "market": "Both Teams To Score - 2nd Half",
        "info": "Yes"
    },
    "btts_2h_no": {
        "key": "btts_2h_no",
        "description": "Both Teams to Score in 2nd Half (No)",
        "market": "Both Teams To Score - 2nd Half",
        "info": "No"
    },
    "o75_asian_corners": {
        "key": "o75_asian_corners",
        "description": "Over 7.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 7.5"
    },
    "u75_asian_corners": {
        "key": "u75_asian_corners",
        "description": "Under 7.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 7.5"
    },
    "o8_asian_corners": {
        "key": "o8_asian_corners",
        "description": "Over 8 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 8"
    },
    "u8_asian_corners": {
        "key": "u8_asian_corners",
        "description": "Under 8 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 8"
    },
    "o85_asian_corners": {
        "key": "o85_asian_corners",
        "description": "Over 8.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 8.5"
    },
    "u85_asian_corners": {
        "key": "u85_asian_corners",
        "description": "Under 8.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 8.5"
    },
    "o9_asian_corners": {
        "key": "o9_asian_corners",
        "description": "Over 9 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 9"
    },
    "u9_asian_corners": {
        "key": "u9_asian_corners",
        "description": "Under 9 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 9"
    },
    "o95_asian_corners": {
        "key": "o95_asian_corners",
        "description": "Over 9.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 9.5"
    },
    "u95_asian_corners": {
        "key": "u95_asian_corners",
        "description": "Under 9.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 9.5"
    },
    "o10_asian_corners": {
        "key": "o10_asian_corners",
        "description": "Over 10 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 10"
    },
    "u10_asian_corners": {
        "key": "u10_asian_corners",
        "description": "Under 10 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 10"
    },
    "o105_asian_corners": {
        "key": "o105_asian_corners",
        "description": "Over 10.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 10.5"
    },
    "u105_asian_corners": {
        "key": "u105_asian_corners",
        "description": "Under 10.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 10.5"
    },
    "o11_asian_corners": {
        "key": "o11_asian_corners",
        "description": "Over 11 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 11"
    },
    "u11_asian_corners": {
        "key": "u11_asian_corners",
        "description": "Under 11 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 11"
    },
    "o115_asian_corners": {
        "key": "o115_asian_corners",
        "description": "Over 11.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 11.5"
    },
    "u115_asian_corners": {
        "key": "u115_asian_corners",
        "description": "Under 11.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 11.5"
    },
    "o12_asian_corners": {
        "key": "o12_asian_corners",
        "description": "Over 12 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 12"
    },
    "u12_asian_corners": {
        "key": "u12_asian_corners",
        "description": "Under 12 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 12"
    },
    "o125_asian_corners": {
        "key": "o125_asian_corners",
        "description": "Over 12.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Over 12.5"
    },
    "u125_asian_corners": {
        "key": "u125_asian_corners",
        "description": "Under 12.5 Asian Corners",
        "market": "Asian Total Corners",
        "info": "Under 12.5"
    },
    "o3_asian_corners_1h": {
        "key": "o3_asian_corners_1h",
        "description": "Over 3 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over 3"
    },
    "u3_asian_corners_1h": {
        "key": "u3_asian_corners_1h",
        "description": "Under 3 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under 3"
    },
    "o35_asian_corners_1h": {
        "key": "o35_asian_corners_1h",
        "description": "Over 3.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over 3.5"
    },
    "u35_asian_corners_1h": {
        "key": "u35_asian_corners_1h",
        "description": "Under 3.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under 3.5"
    },
    "o4_asian_corners_1h": {
        "key": "o4_asian_corners_1h",
        "description": "Over 4 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over 4"
    },
    "u4_asian_corners_1h": {
        "key": "u4_asian_corners_1h",
        "description": "Under 4 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under 4"
    },
    "o45_asian_corners_1h": {
        "key": "o45_asian_corners_1h",
        "description": "Over 4.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over 4.5"
    },
    "u45_asian_corners_1h": {
        "key": "u45_asian_corners_1h",
        "description": "Under 4.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under 4.5"
    },
    "o5_asian_corners_1h": {
        "key": "o5_asian_corners_1h",
        "description": "Over 5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over 5"
    },
    "u5_asian_corners_1h": {
        "key": "u5_asian_corners_1h",
        "description": "Under 5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under 5"
    },
    "o55_asian_corners_1h": {
        "key": "o55_asian_corners_1h",
        "description": "Over 5.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over 5.5"
    },
    "u55_asian_corners_1h": {
        "key": "u55_asian_corners_1h",
        "description": "Under 5.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under 5.5"
    },
    "o6_asian_corners_1h": {
        "key": "o6_asian_corners_1h",
        "description": "Over 6 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over 6"
    },
    "u6_asian_corners_1h": {
        "key": "u6_asian_corners_1h",
        "description": "Under 6 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under 6"
    },
    "o15_goal_line": {
        "key": "o15_goal_line",
        "description": "Over 1.5 Goal Line",
        "market": "Goal Line",
        "info": "Over 1.5"
    },
    "u15_goal_line": {
        "key": "u15_goal_line",
        "description": "Under 1.5 Goal Line",
        "market": "Goal Line",
        "info": "Under 1.5"
    },
    "o20_goal_line": {
        "key": "o2_goal_line",
        "description": "Over 2.0 Goal Line",
        "market": "Goal Line",
        "info": "Over 2.0"
    },
    "u20_goal_line": {
        "key": "u2_goal_line",
        "description": "Under 2.0 Goal Line",
        "market": "Goal Line",
        "info": "Under 2.0"
    },
    "o25_goal_line": {
        "key": "o25_goal_line",
        "description": "Over 2.5 Goal Line",
        "market": "Goal Line",
        "info": "Over 2.5"
    },
    "u25_goal_line": {
        "key": "u25_goal_line",
        "description": "Under 2.5 Goal Line",
        "market": "Goal Line",
        "info": "Under 2.5"
    },
    "o05_goal_line_1h": {
        "key": "o05_goal_line_1h",
        "description": "Over 0.5 Goal Line (1st Half)",
        "market": "1st Half Goal Line",
        "info": "Over 0.5"
    },
    "u05_goal_line_1h": {
        "key": "u05_goal_line_1h",
        "description": "Under 0.5 Goal Line (1st Half)",
        "market": "1st Half Goal Line",
        "info": "Under 0.5"
    },
    "o10_goal_line_1h": {
        "key": "o10_goal_line_1h",
        "description": "Over 1.0 Goal Line (1st Half)",
        "market": "1st Half Goal Line",
        "info": "Over 1.5"
    },
    "u10_goal_line_1h": {
        "key": "u10_goal_line_1h",
        "description": "Under 1.0 Goal Line (1st Half)",
        "market": "1st Half Goal Line",
        "info": "Under 1.5"
    },
    "o7_corners": {
        "key": "o7_corners",
        "description": "Over 7 Total Corners",
        "market": "Total Corners",
        "info": "Over 7"
    },
    "u7_corners": {
        "key": "u7_corners",
        "description": "Under 7 Total Corners",
        "market": "Total Corners",
        "info": "Under 7"
    },
    "e7_corners": {
        "key": "e7_corners",
        "description": "Exactly 7 Total Corners",
        "market": "Total Corners",
        "info": "Exactly 7"
    },
    "o8_corners": {
        "key": "o8_corners",
        "description": "Over 8 Total Corners",
        "market": "Total Corners",
        "info": "Over 8"
    },
    "u8_corners": {
        "key": "u8_corners",
        "description": "Under 8 Total Corners",
        "market": "Total Corners",
        "info": "Under 8"
    },
    "e8_corners": {
        "key": "e8_corners",
        "description": "Exactly 8 Total Corners",
        "market": "Total Corners",
        "info": "Exactly 8"
    },
    "o9_corners": {
        "key": "o9_corners",
        "description": "Over 9 Total Corners",
        "market": "Total Corners",
        "info": "Over 9"
    },
    "u9_corners": {
        "key": "u9_corners",
        "description": "Under 9 Total Corners",
        "market": "Total Corners",
        "info": "Under 9"
    },
    "e9_corners": {
        "key": "e9_corners",
        "description": "Exactly 9 Total Corners",
        "market": "Total Corners",
        "info": "Exactly 9"
    },
    "o10_corners": {
        "key": "o10_corners",
        "description": "Over 10 Total Corners",
        "market": "Total Corners",
        "info": "Over 10"
    },
    "u10_corners": {
        "key": "u10_corners",
        "description": "Under 10 Total Corners",
        "market": "Total Corners",
        "info": "Under 10"
    },
    "e10_corners": {
        "key": "e10_corners",
        "description": "Exactly 10 Total Corners",
        "market": "Total Corners",
        "info": "Exactly 10"
    },
    "o11_corners": {
        "key": "o11_corners",
        "description": "Over 11 Total Corners",
        "market": "Total Corners",
        "info": "Over 11"
    },
    "u11_corners": {
        "key": "u11_corners",
        "description": "Under 11 Total Corners",
        "market": "Total Corners",
        "info": "Under 11"
    },
    "e11_corners": {
        "key": "e11_corners",
        "description": "Exactly 11 Total Corners",
        "market": "Total Corners",
        "info": "Exactly 11"
    },
    "o12_corners": {
        "key": "o12_corners",
        "description": "Over 12 Total Corners",
        "market": "Total Corners",
        "info": "Over 12"
    },
    "u12_corners": {
        "key": "u12_corners",
        "description": "Under 12 Total Corners",
        "market": "Total Corners",
        "info": "Under 12"
    },
    "e12_corners": {
        "key": "e12_corners",
        "description": "Exactly 12 Total Corners",
        "market": "Total Corners",
        "info": "Exactly 12"
    }
}

IN_PLAY_ODDS_MAP = {
    "home_win": {
        "key": "home_win",
        "description": "1X2 [Home Win]",
        "market": "3Way Result",
        "info": "Home"
    },
    "draw": {
        "key": "draw",
        "description": "1X2 [Draw]",
        "market": "3Way Result",
        "info": "Draw"
    },
    "away_win": {
        "key": "away_win",
        "description": "1X2 [Away Win]",
        "market": "3Way Result",
        "info": "Away"
    },
    "home_win_ht": {
        "key": "home_win_ht",
        "description": "Half Time Result [Home Win]",
        "market": "Half Time Result",
        "info": "Home"
    },
    "draw_ht": {
        "key": "draw_ht",
        "description": "Half Time Result [Draw]",
        "market": "Half Time Result",
        "info": "Draw"
    },
    "away_win_ht": {
        "key": "away_win_ht",
        "description": "Half Time Result [Away Win]",
        "market": "Half Time Result",
        "info": "Away"
    },
    "home_win_or_draw": {
        "key": "home_win_or_draw",
        "description": "Double Chance [Home Draw]",
        "market": "Double Chance",
        "info": "Home or Draw"
    },
    "away_win_or_draw": {
        "key": "away_win_or_draw",
        "description": "Double Chance [Draw Away]",
        "market": "Double Chance",
        "info": "Draw or Away"
    },
    "home_win_or_away_win": {
        "key": "home_win_or_away_win",
        "description": "Double Chance [Home Away]",
        "market": "Double Chance",
        "info": "Home or Away"
    },
    "dnb_home": {
        "key": "dnb_home",
        "description": "Draw No Bet [Home]",
        "market": "Draw No Bet",
        "info": "Home"
    },
    "dnb_away": {
        "key": "dnb_away",
        "description": "Draw No Bet [Away]",
        "market": "Draw No Bet",
        "info": "Away"
    },
    "o05_goals": {
        "key": "o05_goals",
        "description": "Match Goals Over 0.5",
        "market": "Match Goals",
        "info": "Over - 0.5"
    },
    "u05_goals": {
        "key": "u05_goals",
        "description": "Match Goals Under 0.5",
        "market": "Match Goals",
        "info": "Under - 0.5"
    },
    "o15_goals": {
        "key": "o15_goals",
        "description": "Match Goals Over 1.5",
        "market": "Match Goals",
        "info": "Over - 1.5"
    },
    "u15_goals": {
        "key": "u15_goals",
        "description": "Match Goals Under 1.5",
        "market": "Match Goals",
        "info": "Under - 1.5"
    },
    "o25_goals": {
        "key": "o25_goals",
        "description": "Match Goals Over 2.5",
        "market": "Match Goals",
        "info": "Over - 2.5"
    },
    "u25_goals": {
        "key": "u25_goals",
        "description": "Match Goals Under 2.5",
        "market": "Match Goals",
        "info": "Under - 2.5"
    },
    "o35_goals": {
        "key": "o35_goals",
        "description": "Match Goals Over 3.5",
        "market": "Match Goals",
        "info": "Over - 3.5"
    },
    "u35_goals": {
        "key": "u35_goals",
        "description": "Match Goals Under 3.5",
        "market": "Match Goals",
        "info": "Under - 3.5"
    },
    "o45_goals": {
        "key": "o45_goals",
        "description": "Match Goals Over 4.5",
        "market": "Match Goals",
        "info": "Over - 4.5"
    },
    "u45_goals": {
        "key": "u45_goals",
        "description": "Match Goals Under 4.5",
        "market": "Match Goals",
        "info": "Under - 4.5"
    },
    "o55_goals": {
        "key": "o55_goals",
        "description": "Match Goals Over 5.5",
        "market": "Match Goals",
        "info": "Over - 5.5"
    },
    "u55_goals": {
        "key": "u55_goals",
        "description": "Match Goals Under 5.5",
        "market": "Match Goals",
        "info": "Under - 5.5"
    },
    "o65_goals": {
        "key": "o65_goals",
        "description": "Match Goals Over 6.5",
        "market": "Match Goals",
        "info": "Over - 6.5"
    },
    "u65_goals": {
        "key": "u65_goals",
        "description": "Match Goals Under 6.5",
        "market": "Match Goals",
        "info": "Under - 6.5"
    },
    "o75_goals": {
        "key": "o75_goals",
        "description": "Match Goals Over 7.5",
        "market": "Match Goals",
        "info": "Over - 7.5"
    },
    "u75_goals": {
        "key": "u75_goals",
        "description": "Match Goals Under 7.5",
        "market": "Match Goals",
        "info": "Under - 7.5"
    },
    "o85_goals": {
        "key": "o85_goals",
        "description": "Match Goals Over 8.5",
        "market": "Match Goals",
        "info": "Over - 8.5"
    },
    "u85_goals": {
        "key": "u85_goals",
        "description": "Match Goals Under 8.5",
        "market": "Match Goals",
        "info": "Under - 8.5"
    },
    "o05_goals_1h": {
        "key": "o05_goals_1h",
        "description": "1st Half Goals Over 0.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over - 0.5"
    },
    "u05_goals_1h": {
        "key": "u05_goals_1h",
        "description": "1st Half Goals Under 0.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under - 0.5"
    },
    "o15_goals_1h": {
        "key": "o15_goals_1h",
        "description": "1st Half Goals Over 1.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over - 1.5"
    },
    "u15_goals_1h": {
        "key": "u15_goals_1h",
        "description": "1st Half Goals Under 1.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under - 1.5"
    },
    "o25_goals_1h": {
        "key": "o25_goals_1h",
        "description": "1st Half Goals Over 2.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over - 2.5"
    },
    "u25_goals_1h": {
        "key": "u25_goals_1h",
        "description": "1st Half Goals Under 2.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under - 2.5"
    },
    "o35_goals_1h": {
        "key": "o35_goals_1h",
        "description": "1st Half Goals Over 3.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over - 3.5"
    },
    "u35_goals_1h": {
        "key": "u35_goals_1h",
        "description": "1st Half Goals Under 3.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under - 3.5"
    },
    "o45_goals_1h": {
        "key": "o45_goals_1h",
        "description": "1st Half Goals Over 4.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over - 4.5"
    },
    "u45_goals_1h": {
        "key": "u45_goals_1h",
        "description": "1st Half Goals Under 4.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under - 4.5"
    },
    "o55_goals_1h": {
        "key": "o55_goals_1h",
        "description": "1st Half Goals Over 5.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Over - 5.5"
    },
    "u55_goals_1h": {
        "key": "u55_goals_1h",
        "description": "1st Half Goals Under 5.5",
        "market": "Goals Over/Under 1st Half",
        "info": "Under - 5.5"
    },
    "btts": {
        "key": "btts",
        "description": "Both Teams to Score (Yes)",
        "market": "Both Teams To Score",
        "info": "Yes"
    },
    "btts_no": {
        "key": "btts_no",
        "description": "Both Teams to Score (No)",
        "market": "Both Teams To Score",
        "info": "No"
    },
    "btts_1h": {
        "key": "btts_1h",
        "description": "Both Teams to Score in 1st Half (Yes)",
        "market": "Both Teams to Score in 1st Half",
        "info": "Yes"
    },
    "btts_1h_no": {
        "key": "btts_1h_no",
        "description": "Both Teams to Score in 1st Half (No)",
        "market": "Both Teams to Score in 1st Half",
        "info": "No"
    },
    "btts_2h": {
        "key": "btts_2h",
        "description": "Both Teams to Score in 2nd Half (Yes)",
        "market": "Both Teams To Score in 2nd Half",
        "info": "Yes"
    },
    "btts_2h_no": {
        "key": "btts_2h_no",
        "description": "Both Teams to Score in 2nd Half (No)",
        "market": "Both Teams To Score in 2nd Half",
        "info": "No"
    },
    "o5_asian_corners": {
        "key": "o5_asian_corners",
        "description": "Over 5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 5"
    },
    "u5_asian_corners": {
        "key": "u5_asian_corners",
        "description": "Under 5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 5"
    },
    "o1_asian_corners": {
        "key": "o1_asian_corners",
        "description": "Over 1 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 1"
    },
    "u1_asian_corners": {
        "key": "u1_asian_corners",
        "description": "Under 1 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 1"
    },
    "o15_asian_corners": {
        "key": "o15_asian_corners",
        "description": "Over 1.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 1.5"
    },
    "u15_asian_corners": {
        "key": "u15_asian_corners",
        "description": "Under 1.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 1.5"
    },
    "o2_asian_corners": {
        "key": "o2_asian_corners",
        "description": "Over 2 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 2"
    },
    "u2_asian_corners": {
        "key": "u2_asian_corners",
        "description": "Under 2 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 2"
    },
    "o25_asian_corners": {
        "key": "o25_asian_corners",
        "description": "Over 2.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 2.5"
    },
    "u25_asian_corners": {
        "key": "u25_asian_corners",
        "description": "Under 2.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 2.5"
    },
    "o3_asian_corners": {
        "key": "o3_asian_corners",
        "description": "Over 3 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 3"
    },
    "u3_asian_corners": {
        "key": "u3_asian_corners",
        "description": "Under 3 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 3"
    },
    "o35_asian_corners": {
        "key": "o35_asian_corners",
        "description": "Over 3.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 3.5"
    },
    "u35_asian_corners": {
        "key": "u35_asian_corners",
        "description": "Under 3.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 3.5"
    },
    "o4_asian_corners": {
        "key": "o4_asian_corners",
        "description": "Over 4 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 4"
    },
    "u4_asian_corners": {
        "key": "u4_asian_corners",
        "description": "Under 4 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 4"
    },
    "o45_asian_corners": {
        "key": "o45_asian_corners",
        "description": "Over 4.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 4.5"
    },
    "u45_asian_corners": {
        "key": "u45_asian_corners",
        "description": "Under 4.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 4.5"
    },
    "o55_asian_corners": {
        "key": "o55_asian_corners",
        "description": "Over 5.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 5.5"
    },
    "u55_asian_corners": {
        "key": "u55_asian_corners",
        "description": "Under 5.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 5.5"
    },
    "o6_asian_corners": {
        "key": "o6_asian_corners",
        "description": "Over 6 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 6"
    },
    "u6_asian_corners": {
        "key": "u6_asian_corners",
        "description": "Under 6 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 6"
    },
    "o65_asian_corners": {
        "key": "o65_asian_corners",
        "description": "Over 6.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 6.5"
    },
    "u65_asian_corners": {
        "key": "u65_asian_corners",
        "description": "Under 6.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 6.5"
    },
    "o7_asian_corners": {
        "key": "o7_asian_corners",
        "description": "Over 7 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 7"
    },
    "u7_asian_corners": {
        "key": "u7_asian_corners",
        "description": "Under 7 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 7"
    },
    "o75_asian_corners": {
        "key": "o75_asian_corners",
        "description": "Over 7.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 7.5"
    },
    "u75_asian_corners": {
        "key": "u75_asian_corners",
        "description": "Under 7.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 7.5"
    },
    "o8_asian_corners": {
        "key": "o8_asian_corners",
        "description": "Over 8 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 8"
    },
    "u8_asian_corners": {
        "key": "u8_asian_corners",
        "description": "Under 8 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 8"
    },
    "o85_asian_corners": {
        "key": "o85_asian_corners",
        "description": "Over 8.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 8.5"
    },
    "u85_asian_corners": {
        "key": "u85_asian_corners",
        "description": "Under 8.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 8.5"
    },
    "o9_asian_corners": {
        "key": "o9_asian_corners",
        "description": "Over 9 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 9"
    },
    "u9_asian_corners": {
        "key": "u9_asian_corners",
        "description": "Under 9 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 9"
    },
    "o95_asian_corners": {
        "key": "o95_asian_corners",
        "description": "Over 9.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 9.5"
    },
    "u95_asian_corners": {
        "key": "u95_asian_corners",
        "description": "Under 9.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 9.5"
    },
    "o10_asian_corners": {
        "key": "o10_asian_corners",
        "description": "Over 10 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 10"
    },
    "u10_asian_corners": {
        "key": "u10_asian_corners",
        "description": "Under 10 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 10"
    },
    "o105_asian_corners": {
        "key": "o105_asian_corners",
        "description": "Over 10.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 10.5"
    },
    "u105_asian_corners": {
        "key": "u105_asian_corners",
        "description": "Under 10.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 10.5"
    },
    "o11_asian_corners": {
        "key": "o11_asian_corners",
        "description": "Over 11 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 11"
    },
    "u11_asian_corners": {
        "key": "u11_asian_corners",
        "description": "Under 11 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 11"
    },
    "o115_asian_corners": {
        "key": "o115_asian_corners",
        "description": "Over 11.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 11.5"
    },
    "u115_asian_corners": {
        "key": "u115_asian_corners",
        "description": "Under 11.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 11.5"
    },
    "o12_asian_corners": {
        "key": "o12_asian_corners",
        "description": "Over 12 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 12"
    },
    "u12_asian_corners": {
        "key": "u12_asian_corners",
        "description": "Under 12 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 12"
    },
    "o125_asian_corners": {
        "key": "o125_asian_corners",
        "description": "Over 12.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 12.5"
    },
    "u125_asian_corners": {
        "key": "u125_asian_corners",
        "description": "Under 12.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 12.5"
    },
    "o13_asian_corners": {
        "key": "o13_asian_corners",
        "description": "Over 13 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 13"
    },
    "u13_asian_corners": {
        "key": "u13_asian_corners",
        "description": "Under 13 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 13"
    },
    "o135_asian_corners": {
        "key": "o135_asian_corners",
        "description": "Over 13.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 13.5"
    },
    "u135_asian_corners": {
        "key": "u135_asian_corners",
        "description": "Under 13.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 13.5"
    },
    "o14_asian_corners": {
        "key": "o14_asian_corners",
        "description": "Over 14 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 14"
    },
    "u14_asian_corners": {
        "key": "u14_asian_corners",
        "description": "Under 14 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 14"
    },
    "o145_asian_corners": {
        "key": "o145_asian_corners",
        "description": "Over 14.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 14.5"
    },
    "u145_asian_corners": {
        "key": "u145_asian_corners",
        "description": "Under 14.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 14.5"
    },
    "o15_asian_corners": {
        "key": "o15_asian_corners",
        "description": "Over 15 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 15"
    },
    "u15_asian_corners": {
        "key": "u15_asian_corners",
        "description": "Under 15 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 15"
    },
    "o155_asian_corners": {
        "key": "o155_asian_corners",
        "description": "Over 15.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 15.5"
    },
    "u155_asian_corners": {
        "key": "u155_asian_corners",
        "description": "Under 15.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 15.5"
    },
    "o16_asian_corners": {
        "key": "o16_asian_corners",
        "description": "Over 16 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 16"
    },
    "u16_asian_corners": {
        "key": "u16_asian_corners",
        "description": "Under 16 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 16"
    },
    "o165_asian_corners": {
        "key": "o165_asian_corners",
        "description": "Over 16.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 16.5"
    },
    "u165_asian_corners": {
        "key": "u165_asian_corners",
        "description": "Under 16.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 16.5"
    },
    "o17_asian_corners": {
        "key": "o17_asian_corners",
        "description": "Over 17 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 17"
    },
    "u17_asian_corners": {
        "key": "u17_asian_corners",
        "description": "Under 17 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 17"
    },
    "o175_asian_corners": {
        "key": "o175_asian_corners",
        "description": "Over 17.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 17.5"
    },
    "u175_asian_corners": {
        "key": "u175_asian_corners",
        "description": "Under 17.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 17.5"
    },
    "o18_asian_corners": {
        "key": "o18_asian_corners",
        "description": "Over 18 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 18"
    },
    "u18_asian_corners": {
        "key": "u18_asian_corners",
        "description": "Under 18 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 18"
    },
    "o185_asian_corners": {
        "key": "o185_asian_corners",
        "description": "Over 18.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 18.5"
    },
    "u185_asian_corners": {
        "key": "u185_asian_corners",
        "description": "Under 18.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 18.5"
    },
    "o19_asian_corners": {
        "key": "o19_asian_corners",
        "description": "Over 19 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 19"
    },
    "u19_asian_corners": {
        "key": "u19_asian_corners",
        "description": "Under 19 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 19"
    },
    "o195_asian_corners": {
        "key": "o195_asian_corners",
        "description": "Over 19.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 19.5"
    },
    "u195_asian_corners": {
        "key": "u195_asian_corners",
        "description": "Under 19.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 19.5"
    },
    "o20_asian_corners": {
        "key": "o20_asian_corners",
        "description": "Over 20 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 20"
    },
    "u20_asian_corners": {
        "key": "u20_asian_corners",
        "description": "Under 20 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 20"
    },
    "o205_asian_corners": {
        "key": "o205_asian_corners",
        "description": "Over 20.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 20.5"
    },
    "u205_asian_corners": {
        "key": "u205_asian_corners",
        "description": "Under 20.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 20.5"
    },
    "o21_asian_corners": {
        "key": "o21_asian_corners",
        "description": "Over 21 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 21"
    },
    "u21_asian_corners": {
        "key": "u21_asian_corners",
        "description": "Under 21 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 21"
    },
    "o215_asian_corners": {
        "key": "o215_asian_corners",
        "description": "Over 21.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 21.5"
    },
    "u215_asian_corners": {
        "key": "u215_asian_corners",
        "description": "Under 21.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 21.5"
    },
    "o22_asian_corners": {
        "key": "o22_asian_corners",
        "description": "Over 22 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 22"
    },
    "u22_asian_corners": {
        "key": "u22_asian_corners",
        "description": "Under 22 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 22"
    },
    "o225_asian_corners": {
        "key": "o225_asian_corners",
        "description": "Over 22.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 22.5"
    },
    "u225_asian_corners": {
        "key": "u225_asian_corners",
        "description": "Under 22.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 22.5"
    },
    "o23_asian_corners": {
        "key": "o23_asian_corners",
        "description": "Over 23 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 23"
    },
    "u23_asian_corners": {
        "key": "u23_asian_corners",
        "description": "Under 23 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 23"
    },
    "o235_asian_corners": {
        "key": "o235_asian_corners",
        "description": "Over 23.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 23.5"
    },
    "u235_asian_corners": {
        "key": "u235_asian_corners",
        "description": "Under 23.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 23.5"
    },
    "o24_asian_corners": {
        "key": "o24_asian_corners",
        "description": "Over 24 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 24"
    },
    "u24_asian_corners": {
        "key": "u24_asian_corners",
        "description": "Under 24 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 24"
    },
    "o245_asian_corners": {
        "key": "o245_asian_corners",
        "description": "Over 24.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 24.5"
    },
    "u245_asian_corners": {
        "key": "u245_asian_corners",
        "description": "Under 24.5 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 24.5"
    },
    "o25_asian_corners": {
        "key": "o25_asian_corners",
        "description": "Over 25 Asian Corners",
        "market": "Asian Corners",
        "info": "Over - 25"
    },
    "u25_asian_corners": {
        "key": "u25_asian_corners",
        "description": "Under 25 Asian Corners",
        "market": "Asian Corners",
        "info": "Under - 25"
    },
    "o5_asian_corners_1h": {
        "key": "o5_asian_corners_1h",
        "description": "Over 5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 5"
    },
    "u5_asian_corners_1h": {
        "key": "u5_asian_corners_1h",
        "description": "Under 5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 5"
    },
    "o1_asian_corners_1h": {
        "key": "o1_asian_corners_1h",
        "description": "Over 1 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 1"
    },
    "u1_asian_corners_1h": {
        "key": "u1_asian_corners_1h",
        "description": "Under 1 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 1"
    },
    "o15_asian_corners_1h": {
        "key": "o15_asian_corners_1h",
        "description": "Over 1.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 1.5"
    },
    "u15_asian_corners_1h": {
        "key": "u15_asian_corners_1h",
        "description": "Under 1.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 1.5"
    },
    "o2_asian_corners_1h": {
        "key": "o2_asian_corners_1h",
        "description": "Over 2 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 2"
    },
    "u2_asian_corners_1h": {
        "key": "u2_asian_corners_1h",
        "description": "Under 2 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 2"
    },
    "o25_asian_corners_1h": {
        "key": "o25_asian_corners_1h",
        "description": "Over 2.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 2.5"
    },
    "u25_asian_corners_1h": {
        "key": "u25_asian_corners_1h",
        "description": "Under 2.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 2.5"
    },
    "o3_asian_corners_1h": {
        "key": "o3_asian_corners_1h",
        "description": "Over 3 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 3"
    },
    "u3_asian_corners_1h": {
        "key": "u3_asian_corners_1h",
        "description": "Under 3 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 3"
    },
    "o35_asian_corners_1h": {
        "key": "o35_asian_corners_1h",
        "description": "Over 3.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 3.5"
    },
    "u35_asian_corners_1h": {
        "key": "u35_asian_corners_1h",
        "description": "Under 3.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 3.5"
    },
    "o4_asian_corners_1h": {
        "key": "o4_asian_corners_1h",
        "description": "Over 4 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 4"
    },
    "u4_asian_corners_1h": {
        "key": "u4_asian_corners_1h",
        "description": "Under 4 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 4"
    },
    "o45_asian_corners_1h": {
        "key": "o45_asian_corners_1h",
        "description": "Over 4.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 4.5"
    },
    "u45_asian_corners_1h": {
        "key": "u45_asian_corners_1h",
        "description": "Under 4.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 4.5"
    },
    "o55_asian_corners_1h": {
        "key": "o55_asian_corners_1h",
        "description": "Over 5.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 5.5"
    },
    "u55_asian_corners_1h": {
        "key": "u55_asian_corners_1h",
        "description": "Under 5.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 5.5"
    },
    "o6_asian_corners_1h": {
        "key": "o6_asian_corners_1h",
        "description": "Over 6 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 6"
    },
    "u6_asian_corners_1h": {
        "key": "u6_asian_corners_1h",
        "description": "Under 6 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 6"
    },
    "o65_asian_corners_1h": {
        "key": "o65_asian_corners_1h",
        "description": "Over 6.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 6.5"
    },
    "u65_asian_corners_1h": {
        "key": "u65_asian_corners_1h",
        "description": "Under 6.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 6.5"
    },
    "o7_asian_corners_1h": {
        "key": "o7_asian_corners_1h",
        "description": "Over 7 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 7"
    },
    "u7_asian_corners_1h": {
        "key": "u7_asian_corners_1h",
        "description": "Under 7 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 7"
    },
    "o75_asian_corners_1h": {
        "key": "o75_asian_corners_1h",
        "description": "Over 7.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 7.5"
    },
    "u75_asian_corners_1h": {
        "key": "u75_asian_corners_1h",
        "description": "Under 7.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 7.5"
    },
    "o8_asian_corners_1h": {
        "key": "o8_asian_corners_1h",
        "description": "Over 8 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 8"
    },
    "u8_asian_corners_1h": {
        "key": "u8_asian_corners_1h",
        "description": "Under 8 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 8"
    },
    "o85_asian_corners_1h": {
        "key": "o85_asian_corners_1h",
        "description": "Over 8.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 8.5"
    },
    "u85_asian_corners_1h": {
        "key": "u85_asian_corners_1h",
        "description": "Under 8.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 8.5"
    },
    "o9_asian_corners_1h": {
        "key": "o9_asian_corners_1h",
        "description": "Over 9 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 9"
    },
    "u9_asian_corners_1h": {
        "key": "u9_asian_corners_1h",
        "description": "Under 9 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 9"
    },
    "o95_asian_corners_1h": {
        "key": "o95_asian_corners_1h",
        "description": "Over 9.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 9.5"
    },
    "u95_asian_corners_1h": {
        "key": "u95_asian_corners_1h",
        "description": "Under 9.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 9.5"
    },
    "o10_asian_corners_1h": {
        "key": "o10_asian_corners_1h",
        "description": "Over 10 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 10"
    },
    "u10_asian_corners_1h": {
        "key": "u10_asian_corners_1h",
        "description": "Under 10 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 10"
    },
    "o105_asian_corners_1h": {
        "key": "o105_asian_corners_1h",
        "description": "Over 10.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 10.5"
    },
    "u105_asian_corners_1h": {
        "key": "u105_asian_corners_1h",
        "description": "Under 10.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 10.5"
    },
    "o11_asian_corners_1h": {
        "key": "o11_asian_corners_1h",
        "description": "Over 11 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 11"
    },
    "u11_asian_corners_1h": {
        "key": "u11_asian_corners_1h",
        "description": "Under 11 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 11"
    },
    "o115_asian_corners_1h": {
        "key": "o115_asian_corners_1h",
        "description": "Over 11.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 11.5"
    },
    "u115_asian_corners_1h": {
        "key": "u115_asian_corners_1h",
        "description": "Under 11.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 11.5"
    },
    "o12_asian_corners_1h": {
        "key": "o12_asian_corners_1h",
        "description": "Over 12 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 12"
    },
    "u12_asian_corners_1h": {
        "key": "u12_asian_corners_1h",
        "description": "Under 12 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 12"
    },
    "o125_asian_corners_1h": {
        "key": "o125_asian_corners_1h",
        "description": "Over 12.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 12.5"
    },
    "u125_asian_corners_1h": {
        "key": "u125_asian_corners_1h",
        "description": "Under 12.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 12.5"
    },
    "o13_asian_corners_1h": {
        "key": "o13_asian_corners_1h",
        "description": "Over 13 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 13"
    },
    "u13_asian_corners_1h": {
        "key": "u13_asian_corners_1h",
        "description": "Under 13 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 13"
    },
    "o135_asian_corners_1h": {
        "key": "o135_asian_corners_1h",
        "description": "Over 13.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 13.5"
    },
    "u135_asian_corners_1h": {
        "key": "u135_asian_corners_1h",
        "description": "Under 13.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 13.5"
    },
    "o14_asian_corners_1h": {
        "key": "o14_asian_corners_1h",
        "description": "Over 14 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 14"
    },
    "u14_asian_corners_1h": {
        "key": "u14_asian_corners_1h",
        "description": "Under 14 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 14"
    },
    "o145_asian_corners_1h": {
        "key": "o145_asian_corners_1h",
        "description": "Over 14.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 14.5"
    },
    "u1455_asian_corners_1h": {
        "key": "u145_asian_corners_1h",
        "description": "Under 14.5 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 14.5"
    },
    "o15_asian_corners_1h": {
        "key": "o15_asian_corners_1h",
        "description": "Over 15 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Over - 15"
    },
    "u15_asian_corners_1h": {
        "key": "u15_asian_corners_1h",
        "description": "Under 15 Asian Corners (1st Half)",
        "market": "1st Half Asian Corners",
        "info": "Under - 15"
    }
}

STATUS = {
    'NS': "Not Started",
    'LIVE': "Live",
    'HT': "Half-Time",
    'FT': "Full-Time",
    'ET': "Extra-Time",
    'PEN_LIVE': "Penalty Shootout",
    'AET': "Finished after extra time",
    'BREAK': "Regular time finished",
    'FT_PEN': "Full-Time after penalties",
    'CANCL': "Canceled",
    'POSTP': "PostPoned",
    'INT': "Interrupted",
    'ABAN': "Abandoned",
    'SUSP': "Suspended",
    'TBA': "To Be Announced",
    'AWARDED': "Awarded",
    'DELAYED': "Delayed",
    'WO': "Walk Over",
    'AU': "Awaiting Updates",
    'Deleted': "Deleted"
}

COUNTRIES = {2: {'id': 2, 'name': 'Poland', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/pl.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'POL', 'iso': 'POL', 'iso2': 'PL', 'longitude': '19.37775993347168', 'latitude': '52.147850036621094'}}, 5: {'id': 5, 'name': 'Brazil', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/br.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'BRA', 'iso': 'BRA', 'iso2': 'BR', 'longitude': '-52.97311782836914', 'latitude': '-10.81045150756836'}}, 11: {'id': 11, 'name': 'Germany', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/de.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'GER', 'iso': 'DEU', 'iso2': 'DE', 'longitude': '10.382203102111816', 'latitude': '51.20246505737305'}}, 17: {'id': 17, 'name': 'France', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/fr.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'FRA', 'iso': 'FRA', 'iso2': 'FR', 'longitude': '2.3382623195648193', 'latitude': '46.63727951049805'}}, 20: {'id': 20, 'name': 'Portugal', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/pt.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'POR', 'iso': 'PRT', 'iso2': 'PT', 'longitude': '-8.009422302246094', 'latitude': '39.64200973510742'}}, 23: {'id': 23, 'name': "Côte d'Ivoire", 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ci.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'CIV', 'iso': 'CIV', 'iso2': 'CI', 'longitude': '-5.552574634552002', 'latitude': '7.598755359649658'}}, 26: {'id': 26, 'name': 'Mali', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ml.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'MLI', 'iso': 'MLI', 'iso2': 'ML', 'longitude': '-3.5273818969726562', 'latitude': '17.35776710510254'}}, 32: {'id': 32, 'name': 'Spain', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/es.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'ESP', 'iso': 'ESP', 'iso2': 'ES', 'longitude': '-3.550692558288574', 'latitude': '40.396026611328125'}}, 38: {'id': 38, 'name': 'Netherlands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/nl.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'NED', 'iso': 'NLD', 'iso2': 'NL', 'longitude': '5.5281572341918945', 'latitude': '52.34225845336914'}}, 41: {'id': 41, 'name': 'Europe', 'image_path': None, 'extra': None}, 44: {'id': 44, 'name': 'Argentina', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ar.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'ARG', 'iso': 'ARG', 'iso2': 'AR', 'longitude': '-64.85450744628906', 'latitude': '-37.071964263916016'}}, 47: {'id': 47, 'name': 'Sweden', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/se.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'SWE', 'iso': 'SWE', 'iso2': 'SE', 'longitude': '16.798059463500977', 'latitude': '62.67497253417969'}}, 62: {'id': 62, 'name': 'Switzerland', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ch.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'SUI', 'iso': 'CHE', 'iso2': 'CH', 'longitude': '8.222854614257812', 'latitude': '46.80379867553711'}}, 80: {'id': 80, 'name': 'Chile', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cl.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'CHI', 'iso': 'CHL', 'iso2': 'CL', 'longitude': '-71.67467498779297', 'latitude': '-35.78622817993164'}}, 86: {'id': 86, 'name': 'Ukraine', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ua.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'UKR', 'iso': 'UKR', 'iso2': 'UA', 'longitude': '31.47578239440918', 'latitude': '48.92656326293945'}}, 98: {'id': 98, 'name': 'Australia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/au.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Australia and New Zealand', 'world_region': 'APAC', 'fifa': 'AUS', 'iso': 'AUS', 'iso2': 'AU', 'longitude': '134.50411987304688', 'latitude': '-25.585241317749023'}}, 107: {'id': 107, 'name': 'Iraq', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/iq.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'IRQ', 'iso': 'IRQ', 'iso2': 'IQ', 'longitude': '43.77495574951172', 'latitude': '33.044586181640625'}}, 116: {'id': 116, 'name': 'Cyprus', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cy.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'CYP', 'iso': 'CYP', 'iso2': 'CY', 'longitude': '33.486717224121094', 'latitude': '35.11473846435547'}}, 119: {'id': 119, 'name': 'Georgia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ge.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'GEO', 'iso': 'GEO', 'iso2': 'GE', 'longitude': '43.3713615', 'latitude': '42.3207845'}}, 122: {'id': 122, 'name': 'Kosovo', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/xk.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': None, 'fifa': None, 'iso': 'UNK', 'iso2': 'XK', 'longitude': None, 'latitude': None}}, 125: {'id': 125, 'name': 'Greece', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gr.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'GRE', 'iso': 'GRC', 'iso2': 'GR', 'longitude': '21.897409439086914', 'latitude': '39.68437194824219'}}, 143: {'id': 143, 'name': 'Austria', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/at.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'AUT', 'iso': 'AUT', 'iso2': 'AT', 'longitude': '14.14021110534668', 'latitude': '47.58843994140625'}}, 146: {'id': 146, 'name': 'South Africa', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/za.png', 'extra': {'continent': 'Africa', 'sub_region': 'Southern Africa', 'world_region': 'EMEA', 'fifa': 'RSA', 'iso': 'ZAF', 'iso2': 'ZA', 'longitude': '25.06287956237793', 'latitude': '-29.046184539794922'}}, 147: {'id': 147, 'name': 'Africa', 'image_path': None, 'extra': None}, 155: {'id': 155, 'name': 'Romania', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ro.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'ROU', 'iso': 'ROU', 'iso2': 'RO', 'longitude': '25.005935668945312', 'latitude': '45.83774185180664'}}, 158: {'id': 158, 'name': 'Uruguay', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/uy.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'URU', 'iso': 'URY', 'iso2': 'UY', 'longitude': '-56.055908203125', 'latitude': '-32.96965408325195'}}, 200: {'id': 200, 'name': 'Senegal', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sn.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'SEN', 'iso': 'SEN', 'iso2': 'SN', 'longitude': '-14.531643867492676', 'latitude': '14.36251163482666'}}, 212: {'id': 212, 'name': 'Belarus', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/by.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'BLR', 'iso': 'BLR', 'iso2': 'BY', 'longitude': '28.054094314575195', 'latitude': '53.54347229003906'}}, 224: {'id': 224, 'name': 'Bulgaria', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bg.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'BUL', 'iso': 'BGR', 'iso2': 'BG', 'longitude': '25.283733367919922', 'latitude': '42.7661018371582'}}, 227: {'id': 227, 'name': 'Russia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ru.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'RUS', 'iso': 'RUS', 'iso2': 'RU', 'longitude': '103.75398254394531', 'latitude': '63.125186920166016'}}, 245: {'id': 245, 'name': 'Czech Republic', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cz.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'CZE', 'iso': 'CZE', 'iso2': 'CZ', 'longitude': '15.331501007080078', 'latitude': '49.739105224609375'}}, 251: {'id': 251, 'name': 'Italy', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/it.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'ITA', 'iso': 'ITA', 'iso2': 'IT', 'longitude': '12.493823051452637', 'latitude': '42.7669792175293'}}, 266: {'id': 266, 'name': 'Croatia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/hr.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'CRO', 'iso': 'HRV', 'iso2': 'HR', 'longitude': '15.734503746032715', 'latitude': '45.444305419921875'}}, 275: {'id': 275, 'name': 'Venezuela', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ve.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'VEN', 'iso': 'VEN', 'iso2': 'VE', 'longitude': '-66.14541625976562', 'latitude': '7.665388584136963'}}, 296: {'id': 296, 'name': 'Serbia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/rs.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'SRB', 'iso': 'SRB', 'iso2': 'RS', 'longitude': '20.797958374023438', 'latitude': '44.23297119140625'}}, 311: {'id': 311, 'name': 'New Caledonia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/nc.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Melanesia', 'world_region': 'APAC', 'fifa': 'NCL', 'iso': 'NCL', 'iso2': 'NC', 'longitude': '165.298583984375', 'latitude': '-21.31782341003418'}}, 320: {'id': 320, 'name': 'Denmark', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/dk.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'DEN', 'iso': 'DNK', 'iso2': 'DK', 'longitude': '9.555907249450684', 'latitude': '56.10176086425781'}}, 338: {'id': 338, 'name': 'Peru', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/pe.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'PER', 'iso': 'PER', 'iso2': 'PE', 'longitude': '-74.422119140625', 'latitude': '-9.212532997131348'}}, 353: {'id': 353, 'name': 'Colombia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/co.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'COL', 'iso': 'COL', 'iso2': 'CO', 'longitude': '-73.27796936035156', 'latitude': '3.9976072311401367'}}, 401: {'id': 401, 'name': 'Slovakia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sk.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'SVK', 'iso': 'SVK', 'iso2': 'SK', 'longitude': '19.48488998413086', 'latitude': '48.70748519897461'}}, 404: {'id': 404, 'name': 'Turkey', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tr.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'TUR', 'iso': 'TUR', 'iso2': 'TR', 'longitude': '34.93033981323242', 'latitude': '39.05101013183594'}}, 455: {'id': 455, 'name': 'Republic of Ireland', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ie.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'IRL', 'iso': 'IRL', 'iso2': 'IE', 'longitude': '-8.196102142333984', 'latitude': '53.1827278137207'}}, 458: {'id': 458, 'name': 'Mexico', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mx.png', 'extra': {'continent': 'Americas', 'sub_region': 'Central America', 'world_region': 'AMER', 'fifa': 'MEX', 'iso': 'MEX', 'iso2': 'MX', 'longitude': '-102.6333999633789', 'latitude': '23.909093856811523'}}, 459: {'id': 459, 'name': 'Ecuador', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ec.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'ECU', 'iso': 'ECU', 'iso2': 'EC', 'longitude': '-78.87104034423828', 'latitude': '-1.421528935432434'}}, 462: {'id': 462, 'name': 'England', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gb.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'ENG,NIR,SCO,WAL', 'iso': 'GBR', 'iso2': 'GB', 'longitude': '-2.2125117778778076', 'latitude': '54.56088638305664'}}, 468: {'id': 468, 'name': 'Ghana', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gh.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'GHA', 'iso': 'GHA', 'iso2': 'GH', 'longitude': '-1.2043862342834473', 'latitude': '7.921330451965332'}}, 479: {'id': 479, 'name': 'Japan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/jp.png', 'extra': {'continent': 'Asia', 'sub_region': 'Eastern Asia', 'world_region': 'APAC', 'fifa': 'JPN', 'iso': 'JPN', 'iso2': 'JP', 'longitude': '139.0772705078125', 'latitude': '36.281646728515625'}}, 488: {'id': 488, 'name': 'Iran', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ir.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'EMEA', 'fifa': 'IRN', 'iso': 'IRN', 'iso2': 'IR', 'longitude': '54.2942008972168', 'latitude': '32.50077819824219'}}, 491: {'id': 491, 'name': 'Northern Ireland', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ie.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'IRL', 'iso': 'IRL', 'iso2': 'IE', 'longitude': '-8.196102142333984', 'latitude': '53.1827278137207'}}, 507: {'id': 507, 'name': 'Bosnia and Herzegovina', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ba.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'BIH', 'iso': 'BIH', 'iso2': 'BA', 'longitude': '17.790241241455078', 'latitude': '44.16533279418945'}}, 515: {'id': 515, 'name': 'Wales', 'image_path': None, 'extra': None}, 556: {'id': 556, 'name': 'Belgium', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/be.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'BEL', 'iso': 'BEL', 'iso2': 'BE', 'longitude': '4.641502380371094', 'latitude': '50.648963928222656'}}, 593: {'id': 593, 'name': 'Cameroon', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cm.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'CMR', 'iso': 'CMR', 'iso2': 'CM', 'longitude': '12.722877502441406', 'latitude': '5.685476779937744'}}, 607: {'id': 607, 'name': 'Burkina Faso', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bf.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'BFA', 'iso': 'BFA', 'iso2': 'BF', 'longitude': '-1.745560646057129', 'latitude': '12.284985542297363'}}, 614: {'id': 614, 'name': 'Algeria', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/dz.png', 'extra': {'continent': 'Africa', 'sub_region': 'Northern Africa', 'world_region': 'EMEA', 'fifa': 'ALG', 'iso': 'DZA', 'iso2': 'DZ', 'longitude': '2.6547281742095947', 'latitude': '28.213645935058594'}}, 674: {'id': 674, 'name': 'Hungary', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/hu.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'HUN', 'iso': 'HUN', 'iso2': 'HU', 'longitude': '19.416574478149414', 'latitude': '47.165733337402344'}}, 712: {'id': 712, 'name': 'Korea Republic', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/kr.png', 'extra': {'continent': 'Asia', 'sub_region': 'Eastern Asia', 'world_region': 'APAC', 'fifa': 'KOR', 'iso': 'KOR', 'iso2': 'KR', 'longitude': '127.13385009765625', 'latitude': '40.077640533447266'}}, 716: {'id': 716, 'name': 'Nigeria', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ng.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'NGA', 'iso': 'NGA', 'iso2': 'NG', 'longitude': '8.077880859375', 'latitude': '9.559505462646484'}}, 719: {'id': 719, 'name': 'Liberia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/lr.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'LBR', 'iso': 'LBR', 'iso2': 'LR', 'longitude': '-9.323492050170898', 'latitude': '6.411512851715088'}}, 748: {'id': 748, 'name': 'Latvia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/lv.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'LVA', 'iso': 'LVA', 'iso2': 'LV', 'longitude': '24.84024429321289', 'latitude': '56.86873245239258'}}, 772: {'id': 772, 'name': 'Cape Verde Islands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cv.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'CPV', 'iso': 'CPV', 'iso2': 'CV', 'longitude': '-23.70345115661621', 'latitude': '15.183002471923828'}}, 802: {'id': 802, 'name': 'Israel', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/il.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'ISR', 'iso': 'ISR', 'iso2': 'IL', 'longitude': '34.75337219238281', 'latitude': '31.814193725585938'}}, 821: {'id': 821, 'name': 'Burundi', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bi.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'BDI', 'iso': 'BDI', 'iso2': 'BI', 'longitude': '29.88650894165039', 'latitude': '-3.365208148956299'}}, 886: {'id': 886, 'name': 'Egypt', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/eg.png', 'extra': {'continent': 'Africa', 'sub_region': 'Northern Africa', 'world_region': 'EMEA', 'fifa': 'EGY', 'iso': 'EGY', 'iso2': 'EG', 'longitude': '29.86229705810547', 'latitude': '26.756103515625'}}, 911: {'id': 911, 'name': 'Angola', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ao.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'ANG', 'iso': 'AGO', 'iso2': 'AO', 'longitude': '17.539464950561523', 'latitude': '-12.333555221557617'}}, 919: {'id': 919, 'name': 'Armenia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/am.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'ARM', 'iso': 'ARM', 'iso2': 'AM', 'longitude': '44.93947219848633', 'latitude': '40.29266357421875'}}, 998: {'id': 998, 'name': 'Montenegro', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/me.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'MNE', 'iso': 'MNE', 'iso2': 'ME', 'longitude': '19.237918853759766', 'latitude': '42.752803802490234'}}, 1004: {'id': 1004, 'name': 'Canada', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ca.png', 'extra': {'continent': 'Americas', 'sub_region': 'Northern America', 'world_region': 'AMER', 'fifa': 'CAN', 'iso': 'CAN', 'iso2': 'CA', 'longitude': '-95.91332244873047', 'latitude': '62.832908630371094'}}, 1040: {'id': 1040, 'name': 'Réunion', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/re.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'REU', 'iso': 'REU', 'iso2': 'RE', 'longitude': '55.631248474121094', 'latitude': '-21.146299362182617'}}, 1161: {'id': 1161, 'name': 'Scotland', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/scotland.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'ENG,NIR,SCO,WAL', 'iso': 'GBR', 'iso2': 'GB', 'longitude': '-2.2125117778778076', 'latitude': '54.56088638305664'}}, 1176: {'id': 1176, 'name': 'Honduras', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/hn.png', 'extra': {'continent': 'Americas', 'sub_region': 'Central America', 'world_region': 'AMER', 'fifa': 'HON', 'iso': 'HND', 'iso2': 'HN', 'longitude': '-86.2647705078125', 'latitude': '14.975032806396484'}}, 1179: {'id': 1179, 'name': 'Kenya', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ke.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'KEN', 'iso': 'KEN', 'iso2': 'KE', 'longitude': '37.83988952636719', 'latitude': '0.5765031576156616'}}, 1190: {'id': 1190, 'name': 'Paraguay', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/py.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'PAR', 'iso': 'PRY', 'iso2': 'PY', 'longitude': '-58.395172119140625', 'latitude': '-23.24028968811035'}}, 1233: {'id': 1233, 'name': 'Finland', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/fi.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'FIN', 'iso': 'FIN', 'iso2': 'FI', 'longitude': '25.989402770996094', 'latitude': '64.28858184814453'}}, 1247: {'id': 1247, 'name': 'Central African Republic', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cf.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'CTA', 'iso': 'CAF', 'iso2': 'CF', 'longitude': '20.486923217773438', 'latitude': '6.574123382568359'}}, 1320: {'id': 1320, 'name': 'Congo DR', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cd.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'COD', 'iso': 'COD', 'iso2': 'CD', 'longitude': '23.6563777923584', 'latitude': '-2.879866123199463'}}, 1424: {'id': 1424, 'name': 'Morocco', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ma.png', 'extra': {'continent': 'Africa', 'sub_region': 'Northern Africa', 'world_region': 'EMEA', 'fifa': 'MAR', 'iso': 'MAR', 'iso2': 'MA', 'longitude': '-8.953388214111328', 'latitude': '29.14059066772461'}}, 1439: {'id': 1439, 'name': 'Tunisia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tn.png', 'extra': {'continent': 'Africa', 'sub_region': 'Northern Africa', 'world_region': 'EMEA', 'fifa': 'TUN', 'iso': 'TUN', 'iso2': 'TN', 'longitude': '9.245259284973145', 'latitude': '34.33528518676758'}}, 1560: {'id': 1560, 'name': 'Congo', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cg.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'CGO', 'iso': 'COG', 'iso2': 'CG', 'longitude': '23.6563777923584', 'latitude': '-2.879866123199463'}}, 1578: {'id': 1578, 'name': 'Norway', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/no.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'NOR', 'iso': 'NOR', 'iso2': 'NO', 'longitude': '14.899925231933594', 'latitude': '66.76667022705078'}}, 1638: {'id': 1638, 'name': 'Slovenia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/si.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'SVN', 'iso': 'SVN', 'iso2': 'SI', 'longitude': '14.820664405822754', 'latitude': '46.1202392578125'}}, 1640: {'id': 1640, 'name': 'Jamaica', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/jm.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'JAM', 'iso': 'JAM', 'iso2': 'JM', 'longitude': '-77.34654998779297', 'latitude': '18.143444061279297'}}, 1646: {'id': 1646, 'name': 'Madagascar', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mg.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'MAD', 'iso': 'MDG', 'iso2': 'MG', 'longitude': '46.69843292236328', 'latitude': '-19.27239418029785'}}, 1703: {'id': 1703, 'name': 'Guinea', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gn.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'GUI', 'iso': 'GIN', 'iso2': 'GN', 'longitude': '-10.98954963684082', 'latitude': '10.429302215576172'}}, 1707: {'id': 1707, 'name': 'Guinea-Bissau', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gw.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'GNB', 'iso': 'GNB', 'iso2': 'GW', 'longitude': '-14.748136520385742', 'latitude': '12.115862846374512'}}, 1739: {'id': 1739, 'name': 'Costa Rica', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cr.png', 'extra': {'continent': 'Americas', 'sub_region': 'Central America', 'world_region': 'AMER', 'fifa': 'CRC', 'iso': 'CRI', 'iso2': 'CR', 'longitude': '-84.22723388671875', 'latitude': '9.884991645812988'}}, 1796: {'id': 1796, 'name': 'Iceland', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/is.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'ISL', 'iso': 'ISL', 'iso2': 'IS', 'longitude': '-18.961700439453125', 'latitude': '64.9285659790039'}}, 1985: {'id': 1985, 'name': 'Guyana', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gy.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'GUY', 'iso': 'GUY', 'iso2': 'GY', 'longitude': '-58.94346237182617', 'latitude': '4.917311191558838'}}, 2079: {'id': 2079, 'name': 'Lithuania', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/lt.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'LTU', 'iso': 'LTU', 'iso2': 'LT', 'longitude': '23.87092399597168', 'latitude': '55.33871841430664'}}, 2088: {'id': 2088, 'name': 'Suriname', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sr.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'SUR', 'iso': 'SUR', 'iso2': 'SR', 'longitude': '-55.889217376708984', 'latitude': '4.216928958892822'}}, 2154: {'id': 2154, 'name': 'Faroe Islands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/fo.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'FRO', 'iso': 'FRO', 'iso2': 'FO', 'longitude': '-6.818255424499512', 'latitude': '62.009559631347656'}}, 2177: {'id': 2177, 'name': 'Haiti', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ht.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'HAI', 'iso': 'HTI', 'iso2': 'HT', 'longitude': '-72.24127960205078', 'latitude': '19.0732421875'}}, 2228: {'id': 2228, 'name': 'Trinidad and Tobago', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tt.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'TRI', 'iso': 'TTO', 'iso2': 'TT', 'longitude': '-61.1640625', 'latitude': '10.68574047088623'}}, 2325: {'id': 2325, 'name': 'Zimbabwe', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/zw.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'ZIM', 'iso': 'ZWE', 'iso2': 'ZW', 'longitude': '29.86876106262207', 'latitude': '-19.000280380249023'}}, 2345: {'id': 2345, 'name': 'Moldova', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/md.png', 'extra': {'continent': 'Europe', 'sub_region': 'Eastern Europe', 'world_region': 'EMEA', 'fifa': 'MDA', 'iso': 'MDA', 'iso2': 'MD', 'longitude': '28.46834373474121', 'latitude': '47.203704833984375'}}, 2405: {'id': 2405, 'name': 'Estonia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ee.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'EST', 'iso': 'EST', 'iso2': 'EE', 'longitude': '25.24162483215332', 'latitude': '58.69374465942383'}}, 2426: {'id': 2426, 'name': 'Uzbekistan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/uz.png', 'extra': {'continent': 'Asia', 'sub_region': 'Central Asia', 'world_region': 'EMEA', 'fifa': 'UZB', 'iso': 'UZB', 'iso2': 'UZ', 'longitude': '63.14588928222656', 'latitude': '41.77239227294922'}}, 2427: {'id': 2427, 'name': 'Kazakhstan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/kz.png', 'extra': {'continent': 'Asia', 'sub_region': 'Central Asia', 'world_region': 'EMEA', 'fifa': 'KAZ', 'iso': 'KAZ', 'iso2': 'KZ', 'longitude': '67.17916870117188', 'latitude': '48.14600372314453'}}, 2453: {'id': 2453, 'name': 'Azerbaijan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/az.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'AZE', 'iso': 'AZE', 'iso2': 'AZ', 'longitude': '47.80820083618164', 'latitude': '40.33100509643555'}}, 2454: {'id': 2454, 'name': 'Albania', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/al.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'ALB', 'iso': 'ALB', 'iso2': 'AL', 'longitude': '20.02745246887207', 'latitude': '41.11113357543945'}}, 2493: {'id': 2493, 'name': 'Mauritania', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mr.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'MTN', 'iso': 'MRT', 'iso2': 'MR', 'longitude': '-10.364437103271484', 'latitude': '20.258995056152344'}}, 2507: {'id': 2507, 'name': 'Gambia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gm.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'GAM', 'iso': 'GMB', 'iso2': 'GM', 'longitude': '-15.490884780883789', 'latitude': '13.440265655517578'}}, 2568: {'id': 2568, 'name': 'Zambia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/zm.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'ZAM', 'iso': 'ZMB', 'iso2': 'ZM', 'longitude': '27.788097381591797', 'latitude': '-13.458845138549805'}}, 2756: {'id': 2756, 'name': 'Malta', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mt.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'MLT', 'iso': 'MLT', 'iso2': 'MT', 'longitude': '14.381033897399902', 'latitude': '35.93336486816406'}}, 2802: {'id': 2802, 'name': 'United Arab Emirates', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ae.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'UAE', 'iso': 'ARE', 'iso2': 'AE', 'longitude': '54.536643981933594', 'latitude': '23.684776306152344'}}, 2817: {'id': 2817, 'name': 'New Zealand', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/nz.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Australia and New Zealand', 'world_region': 'APAC', 'fifa': 'NZL', 'iso': 'NZL', 'iso2': 'NZ', 'longitude': '170.35415649414062', 'latitude': '-44.05629348754883'}}, 2931: {'id': 2931, 'name': 'Andorra', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ad.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'AND', 'iso': 'AND', 'iso2': 'AD', 'longitude': '1.5762332677841187', 'latitude': '42.5506591796875'}}, 3039: {'id': 3039, 'name': 'Togo', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tg.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'TOG', 'iso': 'TGO', 'iso2': 'TG', 'longitude': '0.9800975322723389', 'latitude': '8.513226509094238'}}, 3126: {'id': 3126, 'name': 'Luxembourg', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/lu.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'LUX', 'iso': 'LUX', 'iso2': 'LU', 'longitude': '6.094746112823486', 'latitude': '49.77788162231445'}}, 3347: {'id': 3347, 'name': 'San Marino', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sm.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'SMR', 'iso': 'SMR', 'iso2': 'SM', 'longitude': '12.463393211364746', 'latitude': '43.938133239746094'}}, 3374: {'id': 3374, 'name': 'Gibraltar', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gi.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'GBZ', 'iso': 'GIB', 'iso2': 'GI', 'longitude': '-5.349248886108398', 'latitude': '36.135841369628906'}}, 3483: {'id': 3483, 'name': 'USA', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/us.png', 'extra': {'continent': 'Americas', 'sub_region': 'Northern America', 'world_region': 'AMER', 'fifa': 'USA', 'iso': 'USA', 'iso2': 'US', 'longitude': '-98.95733642578125', 'latitude': '39.44325637817383'}}, 3569: {'id': 3569, 'name': 'French Guiana', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gf.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'GUF', 'iso': 'GUF', 'iso2': 'GF', 'longitude': '-53.16830825805664', 'latitude': '4.069991111755371'}}, 3662: {'id': 3662, 'name': 'Gabon', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ga.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'GAB', 'iso': 'GAB', 'iso2': 'GA', 'longitude': '11.738608360290527', 'latitude': '-0.6345400810241699'}}, 3677: {'id': 3677, 'name': 'Syria', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sy.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'SYR', 'iso': 'SYR', 'iso2': 'SY', 'longitude': '38.473472595214844', 'latitude': '35.03312683105469'}}, 3779: {'id': 3779, 'name': 'Guadeloupe', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gp.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'GLP', 'iso': 'GLP', 'iso2': 'GP', 'longitude': '-61.56741714477539', 'latitude': '16.256731033325195'}}, 3990: {'id': 3990, 'name': 'Nicaragua', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ni.png', 'extra': {'continent': 'Americas', 'sub_region': 'Central America', 'world_region': 'AMER', 'fifa': 'NCA', 'iso': 'NIC', 'iso2': 'NI', 'longitude': '-84.92182159423828', 'latitude': '12.903773307800293'}}, 3995: {'id': 3995, 'name': 'Malaysia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/my.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'MAS', 'iso': 'MYS', 'iso2': 'MY', 'longitude': '102.96261596679688', 'latitude': '2.5490005016326904'}}, 4125: {'id': 4125, 'name': 'Uganda', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ug.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'UGA', 'iso': 'UGA', 'iso2': 'UG', 'longitude': '32.389984130859375', 'latitude': '1.2773280143737793'}}, 4829: {'id': 4829, 'name': 'Mayotte', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/yt.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'MYT', 'iso': 'MYT', 'iso2': 'YT', 'longitude': '45.14227294921875', 'latitude': '-12.79636001586914'}}, 5120: {'id': 5120, 'name': 'Martinique', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mq.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'MTQ', 'iso': 'MTQ', 'iso2': 'MQ', 'longitude': '-60.97755432128906', 'latitude': '14.642807960510254'}}, 5618: {'id': 5618, 'name': 'China PR', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cn.png', 'extra': {'continent': 'Asia', 'sub_region': 'Eastern Asia', 'world_region': 'APAC', 'fifa': 'CHN', 'iso': 'CHN', 'iso2': 'CN', 'longitude': '103.97543334960938', 'latitude': '36.55308532714844'}}, 5724: {'id': 5724, 'name': 'Sierra Leone', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sl.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'SLE', 'iso': 'SLE', 'iso2': 'SL', 'longitude': '-11.843890190124512', 'latitude': '8.521441459655762'}}, 5790: {'id': 5790, 'name': 'Namibia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/na.png', 'extra': {'continent': 'Africa', 'sub_region': 'Southern Africa', 'world_region': 'EMEA', 'fifa': 'NAM', 'iso': 'NAM', 'iso2': 'NA', 'longitude': '17.177526473999023', 'latitude': '-22.150699615478516'}}, 6783: {'id': 6783, 'name': 'Mozambique', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mz.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'MOZ', 'iso': 'MOZ', 'iso2': 'MZ', 'longitude': '35.955692291259766', 'latitude': '-17.555864334106445'}}, 7091: {'id': 7091, 'name': 'Oman', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/om.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'OMA', 'iso': 'OMN', 'iso2': 'OM', 'longitude': '56.157962799072266', 'latitude': '20.566621780395508'}}, 7437: {'id': 7437, 'name': 'Curaçao', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cw.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 0, 'iso': 'CUW', 'iso2': 'CW', 'longitude': '-68.94505310058594', 'latitude': '12.163220405578613'}}, 7563: {'id': 7563, 'name': 'Somalia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/so.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'SOM', 'iso': 'SOM', 'iso2': 'SO', 'longitude': '47.47360610961914', 'latitude': '5.948267459869385'}}, 7598: {'id': 7598, 'name': 'Bolivia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bo.png', 'extra': {'continent': 'Americas', 'sub_region': 'South America', 'world_region': 'AMER', 'fifa': 'BOL', 'iso': 'BOL', 'iso2': 'BO', 'longitude': '-64.6666488647461', 'latitude': '-16.713054656982422'}}, 7830: {'id': 7830, 'name': 'Benin', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bj.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'BEN', 'iso': 'BEN', 'iso2': 'BJ', 'longitude': '2.3377387523651123', 'latitude': '9.624112129211426'}}, 11256: {'id': 11256, 'name': 'Swaziland', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sz.png', 'extra': {'continent': 'Africa', 'sub_region': 'Southern Africa', 'world_region': 'EMEA', 'fifa': 'SWZ', 'iso': 'SWZ', 'iso2': 'SZ', 'longitude': '31.49811363220215', 'latitude': '-26.565134048461914'}}, 12095: {'id': 12095, 'name': 'St. Lucia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/lc.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'LCA', 'iso': 'LCA', 'iso2': 'LC', 'longitude': '-60.9665641784668', 'latitude': '13.86330509185791'}}, 14837: {'id': 14837, 'name': 'Montserrat', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ms.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'EMEA', 'fifa': 'MSR', 'iso': 'MSR', 'iso2': 'MS', 'longitude': '-62.188819885253906', 'latitude': '16.735998153686523'}}, 15326: {'id': 15326, 'name': 'Bermuda', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bm.png', 'extra': {'continent': 'Americas', 'sub_region': 'Northern America', 'world_region': 'AMER', 'fifa': 'BER', 'iso': 'BMU', 'iso2': 'BM', 'longitude': '-64.7516860961914', 'latitude': '32.302669525146484'}}, 16175: {'id': 16175, 'name': 'Libya', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ly.png', 'extra': {'continent': 'Africa', 'sub_region': 'Northern Africa', 'world_region': 'EMEA', 'fifa': 'LBY', 'iso': 'LBY', 'iso2': 'LY', 'longitude': '18.043556213378906', 'latitude': '27.23609733581543'}}, 20802: {'id': 20802, 'name': 'Malawi', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mw.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'MWI', 'iso': 'MWI', 'iso2': 'MW', 'longitude': '33.83546447753906', 'latitude': '-13.523577690124512'}}, 21462: {'id': 21462, 'name': 'Kuwait', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/kw.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'KUW', 'iso': 'KWT', 'iso2': 'KW', 'longitude': '47.60246658325195', 'latitude': '29.321941375732422'}}, 21795: {'id': 21795, 'name': 'Liechtenstein', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/li.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'LIE', 'iso': 'LIE', 'iso2': 'LI', 'longitude': '9.552783012390137', 'latitude': '47.14126968383789'}}, 26833: {'id': 26833, 'name': 'Grenada', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gd.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'GRN', 'iso': 'GRD', 'iso2': 'GD', 'longitude': '-61.64693069458008', 'latitude': '12.178866386413574'}}, 33497: {'id': 33497, 'name': 'Barbados', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bb.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'BRB', 'iso': 'BRB', 'iso2': 'BB', 'longitude': '-59.5485954284668', 'latitude': '13.178098678588867'}}, 35008: {'id': 35008, 'name': 'El Salvador', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sv.png', 'extra': {'continent': 'Americas', 'sub_region': 'Central America', 'world_region': 'AMER', 'fifa': 'SLV', 'iso': 'SLV', 'iso2': 'SV', 'longitude': '-88.86363220214844', 'latitude': '13.671636581420898'}}, 35185: {'id': 35185, 'name': 'Jersey', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/je.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'GBJ', 'iso': 'JEY', 'iso2': 'JE', 'longitude': '-2.1228928565979004', 'latitude': '49.2285041809082'}}, 35210: {'id': 35210, 'name': 'Tanzania', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tz.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'TAN', 'iso': 'TZA', 'iso2': 'TZ', 'longitude': '34.85392761230469', 'latitude': '-6.306897163391113'}}, 35376: {'id': 35376, 'name': 'Saudi Arabia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sa.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'KSA', 'iso': 'SAU', 'iso2': 'SA', 'longitude': '44.4013557434082', 'latitude': '23.994726181030273'}}, 37528: {'id': 37528, 'name': 'Cayman Islands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ky.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'CAY', 'iso': 'CYM', 'iso2': 'KY', 'longitude': '-81.25680541992188', 'latitude': '19.308862686157227'}}, 38404: {'id': 38404, 'name': 'Sri Lanka', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/lk.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'APAC', 'fifa': 'SRI', 'iso': 'LKA', 'iso2': 'LK', 'longitude': '80.68072509765625', 'latitude': '7.789133548736572'}}, 39214: {'id': 39214, 'name': 'St. Vincent and the Grenadines', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/vc.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'VIN', 'iso': 'VCT', 'iso2': 'VC', 'longitude': '-61.19344711303711', 'latitude': '13.217251777648926'}}, 41302: {'id': 41302, 'name': 'British Virgin Islands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/vg.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'VGB', 'iso': 'VGB', 'iso2': 'VG', 'longitude': '-64.57130432128906', 'latitude': '18.443071365356445'}}, 43321: {'id': 43321, 'name': 'Eritrea', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/er.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'ERI', 'iso': 'ERI', 'iso2': 'ER', 'longitude': '39.087188720703125', 'latitude': '15.397199630737305'}}, 43444: {'id': 43444, 'name': 'Afghanistan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/af.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'APAC', 'fifa': 'AFG', 'iso': 'AFG', 'iso2': 'AF', 'longitude': '66.02528381347656', 'latitude': '33.833248138427734'}}, 44569: {'id': 44569, 'name': 'Aruba', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/aw.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'ARU', 'iso': 'ABW', 'iso2': 'AW', 'longitude': '-69.96931457519531', 'latitude': '12.506523132324219'}}, 44983: {'id': 44983, 'name': 'Ethiopia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/et.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'ETH', 'iso': 'ETH', 'iso2': 'ET', 'longitude': '39.63755416870117', 'latitude': '8.626703262329102'}}, 45412: {'id': 45412, 'name': 'Lebanon', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/lb.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'LIB', 'iso': 'LBN', 'iso2': 'LB', 'longitude': '35.89972686767578', 'latitude': '33.925411224365234'}}, 47329: {'id': 47329, 'name': 'Bonaire', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bq.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'APAC', 'fifa': 'ANT', 'iso': 'BES', 'iso2': 'BQ', 'longitude': '-68.238534', 'latitude': '12.178361'}}, 48946: {'id': 48946, 'name': 'Palestine', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ps.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'PLE', 'iso': 'PSE', 'iso2': 'PS', 'longitude': '35.259735107421875', 'latitude': '31.946392059326172'}}, 49438: {'id': 49438, 'name': 'Kyrgyzstan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/kg.png', 'extra': {'continent': 'Asia', 'sub_region': 'Central Asia', 'world_region': 'EMEA', 'fifa': 'KGZ', 'iso': 'KGZ', 'iso2': 'KG', 'longitude': '74.55522155761719', 'latitude': '41.46435546875'}}, 49477: {'id': 49477, 'name': 'Thailand', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/th.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'THA', 'iso': 'THA', 'iso2': 'TH', 'longitude': '100.85191345214844', 'latitude': '14.48458194732666'}}, 50809: {'id': 50809, 'name': 'Philippines', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ph.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'PHI', 'iso': 'PHL', 'iso2': 'PH', 'longitude': '122.50947570800781', 'latitude': '11.112666130065918'}}, 52126: {'id': 52126, 'name': 'Pakistan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/pk.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'APAC', 'fifa': 'PAK', 'iso': 'PAK', 'iso2': 'PK', 'longitude': '69.35774230957031', 'latitude': '29.923219680786133'}}, 53128: {'id': 53128, 'name': 'Guatemala', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gt.png', 'extra': {'continent': 'Americas', 'sub_region': 'Central America', 'world_region': 'AMER', 'fifa': 'GUA', 'iso': 'GTM', 'iso2': 'GT', 'longitude': '-90.3486557006836', 'latitude': '15.670565605163574'}}, 55408: {'id': 55408, 'name': 'Papua New Guinea', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/pg.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Melanesia', 'world_region': 'APAC', 'fifa': 'PNG', 'iso': 'PNG', 'iso2': 'PG', 'longitude': '146.21444702148438', 'latitude': '-6.889159679412842'}}, 56518: {'id': 56518, 'name': 'Sudan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sd.png', 'extra': {'continent': 'Africa', 'sub_region': 'Northern Africa', 'world_region': 'EMEA', 'fifa': 'SUD', 'iso': 'SDN', 'iso2': 'SD', 'longitude': '30.087390899658203', 'latitude': '16.085784912109375'}}, 57142: {'id': 57142, 'name': 'Macedonia FYR', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mk.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'MKD', 'iso': 'MKD', 'iso2': 'MK', 'longitude': '21.700895309448242', 'latitude': '41.60045623779297'}}, 57160: {'id': 57160, 'name': 'Tajikistan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tj.png', 'extra': {'continent': 'Asia', 'sub_region': 'Central Asia', 'world_region': 'EMEA', 'fifa': 'TJK', 'iso': 'TJK', 'iso2': 'TJ', 'longitude': '70.89906311035156', 'latitude': '38.879764556884766'}}, 63604: {'id': 63604, 'name': 'Cuba', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/cu.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'CUB', 'iso': 'CUB', 'iso2': 'CU', 'longitude': '-79.4531478881836', 'latitude': '22.066335678100586'}}, 64306: {'id': 64306, 'name': 'Hong Kong', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/hk.png', 'extra': {'continent': 'Asia', 'sub_region': 'Eastern Asia', 'world_region': 'APAC', 'fifa': 'HKG', 'iso': 'HKG', 'iso2': 'HK', 'longitude': '114.18696594238281', 'latitude': '22.336156845092773'}}, 65053: {'id': 65053, 'name': 'Niger', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ne.png', 'extra': {'continent': 'Africa', 'sub_region': 'Western Africa', 'world_region': 'EMEA', 'fifa': 'NIG', 'iso': 'NER', 'iso2': 'NE', 'longitude': '9.400633811950684', 'latitude': '17.424074172973633'}}, 65437: {'id': 65437, 'name': 'Panama', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/pa.png', 'extra': {'continent': 'Americas', 'sub_region': 'Central America', 'world_region': 'AMER', 'fifa': 'PAN', 'iso': 'PAN', 'iso2': 'PA', 'longitude': '-80.50607299804688', 'latitude': '8.646247863769531'}}, 69697: {'id': 69697, 'name': 'Vietnam', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/vn.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'VIE', 'iso': 'VNM', 'iso2': 'VN', 'longitude': '106.8164291381836', 'latitude': '16.9404296875'}}, 74505: {'id': 74505, 'name': 'Qatar', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/qa.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'QAT', 'iso': 'QAT', 'iso2': 'QA', 'longitude': '51.2602653503418', 'latitude': '25.413625717163086'}}, 75285: {'id': 75285, 'name': 'Monaco', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mc.png', 'extra': {'continent': 'Europe', 'sub_region': 'Western Europe', 'world_region': 'EMEA', 'fifa': 'MON', 'iso': 'MCO', 'iso2': 'MC', 'longitude': '7.425483226776123', 'latitude': '43.738929748535156'}}, 77505: {'id': 77505, 'name': 'Timor-Leste', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tl.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'TLS', 'iso': 'TLS', 'iso2': 'TL', 'longitude': '126.07902526855469', 'latitude': '-8.804786682128906'}}, 77580: {'id': 77580, 'name': 'Puerto Rico', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/pr.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'PUR', 'iso': 'PRI', 'iso2': 'PR', 'longitude': '-66.62803649902344', 'latitude': '18.2491397857666'}}, 79146: {'id': 79146, 'name': 'Dominican Republic', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/do.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'DOM', 'iso': 'DOM', 'iso2': 'DO', 'longitude': '-70.79285430908203', 'latitude': '19.019824981689453'}}, 80919: {'id': 80919, 'name': 'Bahamas', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bs.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'BAH', 'iso': 'BHS', 'iso2': 'BS', 'longitude': '-77.39512634277344', 'latitude': '25.035648345947266'}}, 83175: {'id': 83175, 'name': 'Turkmenistan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tm.png', 'extra': {'continent': 'Asia', 'sub_region': 'Central Asia', 'world_region': 'EMEA', 'fifa': 'TKM', 'iso': 'TKM', 'iso2': 'TM', 'longitude': '59.082252502441406', 'latitude': '39.2012825012207'}}, 86958: {'id': 86958, 'name': 'Tahiti', 'image_path': None, 'extra': None}, 88137: {'id': 88137, 'name': 'Rwanda', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/rw.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'RWA', 'iso': 'RWA', 'iso2': 'RW', 'longitude': '29.926057815551758', 'latitude': '-1.9999498128890991'}}, 88407: {'id': 88407, 'name': 'Indonesia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/id.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'IDN', 'iso': 'IDN', 'iso2': 'ID', 'longitude': '115.41899871826172', 'latitude': '-1.248089075088501'}}, 97374: {'id': 97374, 'name': 'Jordan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/jo.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'JOR', 'iso': 'JOR', 'iso2': 'JO', 'longitude': '36.82838821411133', 'latitude': '31.2757625579834'}}, 97434: {'id': 97434, 'name': 'Saint Martin', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sx.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 0, 'iso': 'SXM', 'iso2': 'SX', 'longitude': '-63.06623458862305', 'latitude': '18.042224884033203'}}, 98799: {'id': 98799, 'name': 'Chad', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/td.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'CHA', 'iso': 'TCD', 'iso2': 'TD', 'longitude': '18.66758155822754', 'latitude': '15.367652893066406'}}, 99474: {'id': 99474, 'name': 'World', 'image_path': None, 'extra': None}, 137919: {'id': 137919, 'name': 'Antigua and Barbuda', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ag.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'ATG', 'iso': 'ATG', 'iso2': 'AG', 'longitude': '-61.81040954589844', 'latitude': '17.09273910522461'}}, 144816: {'id': 144816, 'name': 'Belize', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bz.png', 'extra': {'continent': 'Americas', 'sub_region': 'Central America', 'world_region': 'AMER', 'fifa': 'BLZ', 'iso': 'BLZ', 'iso2': 'BZ', 'longitude': '-88.66973876953125', 'latitude': '17.225292205810547'}}, 153732: {'id': 153732, 'name': 'India', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/in.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'APAC', 'fifa': 'IND', 'iso': 'IND', 'iso2': 'IN', 'longitude': '79.45809173583984', 'latitude': '23.4060115814209'}}, 155043: {'id': 155043, 'name': 'Bangladesh', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bd.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'APAC', 'fifa': 'BAN', 'iso': 'BGD', 'iso2': 'BD', 'longitude': '90.30652618408203', 'latitude': '23.730104446411133'}}, 160047: {'id': 160047, 'name': 'St. Kitts and Nevis', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/kn.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'SKN', 'iso': 'KNA', 'iso2': 'KN', 'longitude': '-62.643184661865234', 'latitude': '17.24447250366211'}}, 179748: {'id': 179748, 'name': 'São Tomé e Príncipe', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/st.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'STP', 'iso': 'STP', 'iso2': 'ST', 'longitude': '6.631628036499023', 'latitude': '0.275555282831192'}}, 190317: {'id': 190317, 'name': 'South Sudan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ss.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 0, 'iso': 'SSD', 'iso2': 'SS', 'longitude': '30.280752182006836', 'latitude': '7.303858280181885'}}, 190318: {'id': 190318, 'name': 'Yemen', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ye.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'YEM', 'iso': 'YEM', 'iso2': 'YE', 'longitude': '47.48988723754883', 'latitude': '15.888387680053711'}}, 190321: {'id': 190321, 'name': 'Bahrain', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bh.png', 'extra': {'continent': 'Asia', 'sub_region': 'Western Asia', 'world_region': 'EMEA', 'fifa': 'BHR', 'iso': 'BHR', 'iso2': 'BH', 'longitude': '50.54299545288086', 'latitude': '26.094240188598633'}}, 190324: {'id': 190324, 'name': 'International', 'image_path': None, 'extra': None}, 191038: {'id': 191038, 'name': 'Botswana', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bw.png', 'extra': {'continent': 'Africa', 'sub_region': 'Southern Africa', 'world_region': 'EMEA', 'fifa': 'BOT', 'iso': 'BWA', 'iso2': 'BW', 'longitude': '23.81494140625', 'latitude': '-22.186752319335938'}}, 201580: {'id': 201580, 'name': 'Maldives', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mv.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'APAC', 'fifa': 'MDV', 'iso': 'MDV', 'iso2': 'MV', 'longitude': '73.53071594238281', 'latitude': '4.185884952545166'}}, 211975: {'id': 211975, 'name': 'Equatorial Guinea', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gq.png', 'extra': {'continent': 'Africa', 'sub_region': 'Middle Africa', 'world_region': 'EMEA', 'fifa': 'EQG', 'iso': 'GNQ', 'iso2': 'GQ', 'longitude': '10.372581481933594', 'latitude': '1.5331259965896606'}}, 213370: {'id': 213370, 'name': 'Chinese Taipei', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tw.png', 'extra': {'continent': 'Asia', 'sub_region': 'Eastern Asia', 'world_region': 'APAC', 'fifa': 'TPE', 'iso': 'TWN', 'iso2': 'TW', 'longitude': '120.89749145507812', 'latitude': '23.685789108276367'}}, 213955: {'id': 213955, 'name': 'Singapore', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sg.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'SIN', 'iso': 'SGP', 'iso2': 'SG', 'longitude': '103.8205337524414', 'latitude': '1.3219958543777466'}}, 344167: {'id': 344167, 'name': 'N/C America', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/us.png', 'extra': {'continent': 'Americas', 'sub_region': 'Northern America', 'world_region': 'AMER', 'fifa': 'USA', 'iso': 'USA', 'iso2': 'US', 'longitude': '-98.95733642578125', 'latitude': '39.44325637817383'}}, 360931: {'id': 360931, 'name': 'Mauritius', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mu.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'MRI', 'iso': 'MUS', 'iso2': 'MU', 'longitude': '57.589378356933594', 'latitude': '-20.220409393310547'}}, 364678: {'id': 364678, 'name': 'Comoros', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/km.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'COM', 'iso': 'COM', 'iso2': 'KM', 'longitude': '43.432640075683594', 'latitude': '-11.86610221862793'}}, 380155: {'id': 380155, 'name': 'Dominica', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/dm.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'DMA', 'iso': 'DMA', 'iso2': 'DM', 'longitude': '-61.33945846557617', 'latitude': '15.3991060256958'}}, 390940: {'id': 390940, 'name': 'Isle of Man', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/im.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'GBM', 'iso': 'IMN', 'iso2': 'IM', 'longitude': '-4.562133312225342', 'latitude': '54.22451400756836'}}, 453172: {'id': 453172, 'name': 'Macao', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mo.png', 'extra': {'continent': 'Asia', 'sub_region': 'Eastern Asia', 'world_region': 'APAC', 'fifa': 'MAC', 'iso': 'MAC', 'iso2': 'MO', 'longitude': '113.56034088134766', 'latitude': '22.140748977661133'}}, 482134: {'id': 482134, 'name': 'Lesotho', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ls.png', 'extra': {'continent': 'Africa', 'sub_region': 'Southern Africa', 'world_region': 'EMEA', 'fifa': 'LES', 'iso': 'LSO', 'iso2': 'LS', 'longitude': '28.246612548828125', 'latitude': '-29.58175277709961'}}, 705616: {'id': 705616, 'name': 'Turks and Caicos Islands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tc.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'APAC', 'fifa': 'TCA', 'iso': 'TCA', 'iso2': 'TC', 'longitude': '-71.71514892578125', 'latitude': '21.758726119995117'}}, 862868: {'id': 862868, 'name': 'Nepal', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/np.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'APAC', 'fifa': 'NEP', 'iso': 'NPL', 'iso2': 'NP', 'longitude': '83.94416046142578', 'latitude': '28.259138107299805'}}, 866998: {'id': 866998, 'name': 'Fiji', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/fj.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Melanesia', 'world_region': 'APAC', 'fifa': 'FIJ', 'iso': 'FJI', 'iso2': 'FJ', 'longitude': '178.1472625732422', 'latitude': '-17.658161163330078'}}, 867004: {'id': 867004, 'name': 'Solomon Islands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sb.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Melanesia', 'world_region': 'APAC', 'fifa': 'SOL', 'iso': 'SLB', 'iso2': 'SB', 'longitude': '160.01930236816406', 'latitude': '-9.548112869262695'}}, 867012: {'id': 867012, 'name': 'Vanuatu', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/vu.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Melanesia', 'world_region': 'APAC', 'fifa': 'VAN', 'iso': 'VUT', 'iso2': 'VU', 'longitude': '167.5625', 'latitude': '-16.376684188842773'}}, 867334: {'id': 867334, 'name': 'Samoa', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ws.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Polynesia', 'world_region': 'APAC', 'fifa': 'SAM', 'iso': 'WSM', 'iso2': 'WS', 'longitude': '-172.322021484375', 'latitude': '-13.668972969055176'}}, 867648: {'id': 867648, 'name': 'Cook Islands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ck.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Polynesia', 'world_region': 'APAC', 'fifa': 'COK', 'iso': 'COK', 'iso2': 'CK', 'longitude': '-159.7405548095703', 'latitude': '-21.22330665588379'}}, 868876: {'id': 868876, 'name': 'Zanzibar', 'image_path': None, 'extra': None}, 869895: {'id': 869895, 'name': 'Laos', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/la.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'LAO', 'iso': 'LAO', 'iso2': 'LA', 'longitude': '104.15293884277344', 'latitude': '18.65074920654297'}}, 870092: {'id': 870092, 'name': 'Anguilla', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/ai.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'AIA', 'iso': 'AIA', 'iso2': 'AI', 'longitude': '-63.0473518371582', 'latitude': '18.22646713256836'}}, 870106: {'id': 870106, 'name': 'US Virgin Islands', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/vg.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 'VGB', 'iso': 'VGB', 'iso2': 'VG', 'longitude': '-64.57130432128906', 'latitude': '18.443071365356445'}}, 870933: {'id': 870933, 'name': 'Myanmar', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mm.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'MYA', 'iso': 'MMR', 'iso2': 'MM', 'longitude': '96.52182006835938', 'latitude': '20.330142974853516'}}, 908783: {'id': 908783, 'name': 'Djibouti', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/dj.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'DJI', 'iso': 'DJI', 'iso2': 'DJ', 'longitude': '42.63182830810547', 'latitude': '11.742591857910156'}}, 908860: {'id': 908860, 'name': 'Seychelles', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sc.png', 'extra': {'continent': 'Africa', 'sub_region': 'Eastern Africa', 'world_region': 'EMEA', 'fifa': 'SEY', 'iso': 'SYC', 'iso2': 'SC', 'longitude': '55.47166061401367', 'latitude': '-4.669795036315918'}}, 909440: {'id': 909440, 'name': 'Cambodia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/kh.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'CAM', 'iso': 'KHM', 'iso2': 'KH', 'longitude': '104.81391143798828', 'latitude': '12.570423126220703'}}, 909526: {'id': 909526, 'name': 'Mongolia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mn.png', 'extra': {'continent': 'Asia', 'sub_region': 'Eastern Asia', 'world_region': 'APAC', 'fifa': 'MNG', 'iso': 'MNG', 'iso2': 'MN', 'longitude': '103.06689453125', 'latitude': '46.83647918701172'}}, 909582: {'id': 909582, 'name': 'American Samoa', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/as.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Polynesia', 'world_region': 'APAC', 'fifa': 'ASA', 'iso': 'ASM', 'iso2': 'AS', 'longitude': '-170.7403564453125', 'latitude': '-14.31956672668457'}}, 909585: {'id': 909585, 'name': 'Tonga', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/to.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Polynesia', 'world_region': 'APAC', 'fifa': 'TGA', 'iso': 'TON', 'iso2': 'TO', 'longitude': '-175.25067138671875', 'latitude': '-21.147611618041992'}}, 910036: {'id': 910036, 'name': 'Guam', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gu.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Micronesia', 'world_region': 'APAC', 'fifa': 'GUM', 'iso': 'GUM', 'iso2': 'GU', 'longitude': '144.73971557617188', 'latitude': '13.42112922668457'}}, 911987: {'id': 911987, 'name': 'Bhutan', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bt.png', 'extra': {'continent': 'Asia', 'sub_region': 'Southern Asia', 'world_region': 'APAC', 'fifa': 'BHU', 'iso': 'BTN', 'iso2': 'BT', 'longitude': '90.43476104736328', 'latitude': '27.416879653930664'}}, 913469: {'id': 913469, 'name': 'Brunei Darussalam', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/bn.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'BRU', 'iso': 'BRN', 'iso2': 'BN', 'longitude': '114.74818420410156', 'latitude': '4.5703840255737305'}}, 1114524: {'id': 1114524, 'name': 'Sint Maarten', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sx.png', 'extra': {'continent': 'Americas', 'sub_region': 'Caribbean', 'world_region': 'AMER', 'fifa': 0, 'iso': 'SXM', 'iso2': 'SX', 'longitude': '-63.06623458862305', 'latitude': '18.042224884033203'}}, 1442002: {'id': 1442002, 'name': 'Korea DPR', 'image_path': None, 'extra': None}, 1884978: {'id': 1884978, 'name': 'Guernsey', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gg.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'GBG', 'iso': 'GGY', 'iso2': 'GG', 'longitude': '-2.1999685764312744', 'latitude': '49.72008514404297'}}, 3499960: {'id': 3499960, 'name': 'Northern Mariana Islands', 'image_path': None, 'extra': None}, 9374632: {'id': 9374632, 'name': 'Great Britain', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/gb.png', 'extra': {'continent': 'Europe', 'sub_region': 'Northern Europe', 'world_region': 'EMEA', 'fifa': 'ENG,NIR,SCO,WAL', 'iso': 'GBR', 'iso2': 'GB', 'longitude': '-2.2125117778778076', 'latitude': '54.56088638305664'}}, 10203129: {'id': 10203129, 'name': 'East Timor', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tl.png', 'extra': {'continent': 'Asia', 'sub_region': 'South-Eastern Asia', 'world_region': 'APAC', 'fifa': 'TLS', 'iso': 'TLS', 'iso2': 'TL', 'longitude': '126.07902526855469', 'latitude': '-8.804786682128906'}}, 11240938: {'id': 11240938, 'name': 'Asia', 'image_path': None, 'extra': None}, 11555657: {'id': 11555657, 'name': 'South America', 'image_path': None, 'extra': None}, 12444275: {'id': 12444275, 'name': 'Niuē', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/nu.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Polynesia', 'world_region': 'APAC', 'fifa': 'NIU', 'iso': 'NIU', 'iso2': 'NU', 'longitude': '-169.8302459716797', 'latitude': '-19.03806495666504'}}, 14566098: {'id': 14566098, 'name': 'Ireland Republic', 'image_path': None, 'extra': None}, 15288356: {'id': 15288356, 'name': 'Northern Cyprus', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/nc.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Melanesia', 'world_region': 'APAC', 'fifa': 'NCL', 'iso': 'NCL', 'iso2': 'NC', 'longitude': '165.298583984375', 'latitude': '-21.31782341003418'}}, 15629849: {'id': 15629849, 'name': 'Federated States of Micronesia', 'image_path': None, 'extra': None}, 24143344: {'id': 24143344, 'name': 'North & Central America', 'image_path': None, 'extra': None}, 24150873: {'id': 24150873, 'name': 'West Indies', 'image_path': None, 'extra': None}, 32396817: {'id': 32396817, 'name': 'North Macedonia', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/mk.png', 'extra': {'continent': 'Europe', 'sub_region': 'Southern Europe', 'world_region': 'EMEA', 'fifa': 'MKD', 'iso': 'MKD', 'iso2': 'MK', 'longitude': '21.700895309448242', 'latitude': '41.60045623779297'}}, 32533155: {'id': 32533155, 'name': 'Eswatini', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/sz.png', 'extra': {'continent': 'Africa', 'sub_region': 'Southern Africa', 'world_region': 'EMEA', 'fifa': 'SWZ', 'iso': 'SWZ', 'iso2': 'SZ', 'longitude': '31.49811363220215', 'latitude': '-26.565134048461914'}}, 34319255: {'id': 34319255, 'name': 'Falkland Islands (Malvinas)', 'image_path': None, 'extra': None}, 37176064: {'id': 37176064, 'name': 'Tuvalu', 'image_path': 'https://cdn.sportmonks.com/images/countries/png/short/tv.png', 'extra': {'continent': 'Oceania', 'sub_region': 'Polynesia', 'world_region': 'APAC', 'fifa': 'TUV', 'iso': 'TUV', 'iso2': 'TV', 'longitude': '178.6740264892578', 'latitude': '-7.471305847167969'}}, 37200394: {'id': 37200394, 'name': 'Kyrgyz Republic', 'image_path': None, 'extra': None}}
FLAGS = {'de': '🇩🇪', 'fr': '🇫🇷', 'pt': '🇵🇹', 'ci': '🇨🇮', 'ml': '🇲🇱', 'es': '🇪🇸', 'nl': '🇳🇱', 'ar': '🇦🇷', 'se': '🇸🇪', 'ch': '🇨🇭', 'cl': '🇨🇱', 'ua': '🇺🇦', 'au': '🇦🇺', 'iq': '🇮🇶', 'cy': '🇨🇾', 'ge': '🇬🇪', 'xk': '🇽🇰', 'gr': '🇬🇷', 'at': '🇦🇹', 'za': '🇿🇦', 'ro': '🇷🇴', 'uy': '🇺🇾', 'sn': '🇸🇳', 'by': '🇧🇾', 'bg': '🇧🇬', 'ru': '🇷🇺', 'cz': '🇨🇿', 'it': '🇮🇹', 'hr': '🇭🇷', 've': '🇻🇪', 'rs': '🇷🇸', 'nc': '🇳🇨', 'dk': '🇩🇰', 'pe': '🇵🇪', 'co': '🇨🇴', 'sk': '🇸🇰', 'tr': '🇹🇷', 'ie': '🇮🇪', 'mx': '🇲🇽', 'ec': '🇪🇨', 'gb': '🇬🇧', 'gh': '🇬🇭', 'jp': '🇯🇵', 'ir': '🇮🇷', 'ba': '🇧🇦', 'be': '🇧🇪', 'cm': '🇨🇲', 'bf': '🇧🇫', 'dz': '🇩🇿', 'hu': '🇭🇺', 'kr': '🇰🇷', 'ng': '🇳🇬', 'lr': '🇱🇷', 'lv': '🇱🇻', 'cv': '🇨🇻', 'il': '🇮🇱', 'bi': '🇧🇮', 'eg': '🇪🇬', 'ao': '🇦🇴', 'am': '🇦🇲', 'me': '🇲🇪', 'ca': '🇨🇦', 're': '🇷🇪', 'hn': '🇭🇳', 'ke': '🇰🇪', 'py': '🇵🇾', 'fi': '🇫🇮', 'cf': '🇨🇫', 'cd': '🇨🇩', 'ma': '🇲🇦', 'tn': '🇹🇳', 'cg': '🇨🇬', 'no': '🇳🇴', 'si': '🇸🇮', 'jm': '🇯🇲', 'mg': '🇲🇬', 'gn': '🇬🇳', 'gw': '🇬🇼', 'cr': '🇨🇷', 'is': '🇮🇸', 'gy': '🇬🇾', 'lt': '🇱🇹', 'sr': '🇸🇷', 'fo': '🇫🇴', 'ht': '🇭🇹', 'tt': '🇹🇹', 'zw': '🇿🇼', 'md': '🇲🇩', 'ee': '🇪🇪', 'uz': '🇺🇿', 'kz': '🇰🇿', 'az': '🇦🇿', 'al': '🇦🇱', 'mr': '🇲🇷', 'gm': '🇬🇲', 'zm': '🇿🇲', 'mt': '🇲🇹', 'ae': '🇦🇪', 'nz': '🇳🇿', 'ad': '🇦🇩', 'tg': '🇹🇬', 'lu': '🇱🇺', 'sm': '🇸🇲', 'gi': '🇬🇮', 'us': '🇺🇸', 'gf': '🇬🇫', 'ga': '🇬🇦', 'sy': '🇸🇾',
         'gp': '🇬🇵', 'ni': '🇳🇮', 'my': '🇲🇾', 'ug': '🇺🇬', 'yt': '🇾🇹', 'mq': '🇲🇶', 'cn': '🇨🇳', 'sl': '🇸🇱', 'na': '🇳🇦', 'mz': '🇲🇿', 'om': '🇴🇲', 'cw': '🇨🇼', 'so': '🇸🇴', 'bo': '🇧🇴', 'bj': '🇧🇯', 'sz': '🇸🇿', 'lc': '🇱🇨', 'ms': '🇲🇸', 'bm': '🇧🇲', 'ly': '🇱🇾', 'mw': '🇲🇼', 'kw': '🇰🇼', 'li': '🇱🇮', 'gd': '🇬🇩', 'bb': '🇧🇧', 'sv': '🇸🇻', 'je': '🇯🇪', 'tz': '🇹🇿', 'sa': '🇸🇦', 'ky': '🇰🇾', 'lk': '🇱🇰', 'vc': '🇻🇨', 'vg': '🇻🇬', 'er': '🇪🇷', 'af': '🇦🇫', 'aw': '🇦🇼', 'et': '🇪🇹', 'lb': '🇱🇧', 'bq': '🇧🇶', 'ps': '🇵🇸', 'kg': '🇰🇬', 'th': '🇹🇭', 'ph': '🇵🇭', 'pk': '🇵🇰', 'gt': '🇬🇹', 'pg': '🇵🇬', 'sd': '🇸🇩', 'mk': '🇲🇰', 'tj': '🇹🇯', 'cu': '🇨🇺', 'hk': '🇭🇰', 'ne': '🇳🇪', 'pa': '🇵🇦', 'vn': '🇻🇳', 'qa': '🇶🇦', 'mc': '🇲🇨', 'tl': '🇹🇱', 'pr': '🇵🇷', 'do': '🇩🇴', 'bs': '🇧🇸', 'tm': '🇹🇲', 'rw': '🇷🇼', 'id': '🇮🇩', 'jo': '🇯🇴', 'sx': '🇸🇽', 'td': '🇹🇩', 'ag': '🇦🇬', 'bz': '🇧🇿', 'in': '🇮🇳', 'bd': '🇧🇩', 'kn': '🇰🇳', 'st': '🇸🇹', 'ss': '🇸🇸', 'ye': '🇾🇪', 'bh': '🇧🇭', 'bw': '🇧🇼', 'mv': '🇲🇻', 'gq': '🇬🇶', 'tw': '🇹🇼', 'sg': '🇸🇬', 'mu': '🇲🇺', 'km': '🇰🇲', 'dm': '🇩🇲', 'im': '🇮🇲', 'mo': '🇲🇴', 'ls': '🇱🇸', 'tc': '🇹🇨', 'np': '🇳🇵', 'fj': '🇫🇯', 'sb': '🇸🇧', 'vu': '🇻🇺', 'ws': '🇼🇸', 'ck': '🇨🇰', 'la': '🇱🇦', 'ai': '🇦🇮', 'mm': '🇲🇲', 'dj': '🇩🇯', 'sc': '🇸🇨', 'kh': '🇰🇭', 'mn': '🇲🇳', 'as': '🇦🇸', 'to': '🇹🇴', 'gu': '🇬🇺', 'bt': '🇧🇹', 'bn': '🇧🇳', 'gg': '🇬🇬', 'nu': '🇳🇺', 'tv': '🇹🇻'}
